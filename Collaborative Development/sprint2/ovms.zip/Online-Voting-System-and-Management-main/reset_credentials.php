<?php
/**
 * OVMS - Reset Credentials & Database Diagnostic Tool
 * 
 * This script allows you to reset the admin password from the command line.
 * It also provides diagnostic information if the database connection fails.
 */

// 1. Initialize environment
define('BASE_PATH', __DIR__);
require_once BASE_PATH . '/core/Env.php';

// Check if .env exists and is readable
if (!file_exists(BASE_PATH . '/.env')) {
    die("<h2>Error</h2><p>.env file not found at " . BASE_PATH . "/.env. Please run setup.sh first.</p>\n");
}

if (!is_readable(BASE_PATH . '/.env')) {
    $owner = function_exists('posix_getpwuid') ? posix_getpwuid(fileowner(BASE_PATH . '/.env'))['name'] : fileowner(BASE_PATH . '/.env');
    $perms = substr(sprintf('%o', fileperms(BASE_PATH . '/.env')), -4);
    die("<h2>Error</h2><p>.env file is NOT readable by the current user (" . get_current_user() . ").</p>
         <p><strong>File Owner:</strong> $owner</p>
         <p><strong>Permissions:</strong> $perms</p>
         <p><strong>Fix:</strong> Run <code>sudo chmod 644 .env</code> on your server.</p>\n");
}

// Load .env
Env::load(BASE_PATH . '/.env');

// 2. Attempt Database Connection
require_once BASE_PATH . '/core/Database.php';

try {
    $db = Database::getInstance();
    echo "✅ Database connection successful.\n\n";
} catch (PDOException $e) {
    echo "<h2>Error</h2>";
    echo "<p>Database Connection Failed: " . $e->getMessage() . "</p>";
    
    echo "<h3>Diagnostic Info:</h3>";
    echo "<ul>";
    echo "<li><strong>DB_HOST:</strong> " . Env::get('DB_HOST', 'not set') . "</li>";
    echo "<li><strong>DB_USER:</strong> " . Env::get('DB_USER', 'not set') . "</li>";
    echo "<li><strong>DB_NAME:</strong> " . Env::get('DB_NAME', 'not set') . "</li>";
    echo "<li><strong>DB_PASS:</strong> " . (Env::get('DB_PASS') ? '********' : '(empty)') . "</li>";
    echo "</ul>";
    
    echo "<p><strong>Tip:</strong> If you are on an Ubuntu server, the 'root' user often requires a password. 
          Make sure your .env file matches your MySQL credentials.</p>";
    echo "<p>You can also run <code>php debug_db.php</code> for more details.</p>";
    exit(1);
}

// 3. Logic to reset admin password
$adminEmail = 'votingsystemadmin@gmail.com'; // Default admin email
$newPassword = 'password';
$hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);

echo "Attempting to reset password for: $adminEmail\n";

try {
    $stmt = $db->query("SELECT id FROM admins WHERE email = ?", [$adminEmail]);
    $admin = $stmt->fetch();

    if ($admin) {
        $db->query("UPDATE admins SET password = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?", [
            $hashedPassword,
            $admin['id']
        ]);
        echo "✅ SUCCESS! Password for $adminEmail has been reset to: $newPassword\n";
        echo "You can now log in at: " . Env::get('BASE_URL', '') . "/admin/login\n";
    } else {
        echo "❌ ERROR: Admin account with email $adminEmail not found.\n";
        
        // List existing admins to help
        $stmt = $db->query("SELECT email FROM admins");
        $admins = $stmt->fetchAll();
        if ($admins) {
            echo "Available admin emails:\n";
            foreach ($admins as $a) {
                echo " - " . $a['email'] . "\n";
            }
        }
    }
} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
}
