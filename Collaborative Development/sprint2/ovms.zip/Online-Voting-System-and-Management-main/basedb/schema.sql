-- ============================================================
--  Voting Management System — Final Schema
--  Stack : PHP + MySQL (XAMPP)
--  Fixed : TIMESTAMP NULL → DATETIME NULL (MySQL 5.7 compatible)
--  Run   : Import via phpMyAdmin or mysql CLI
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = '';

-- ============================================================
-- 1. CITIZENS
-- ============================================================
CREATE TABLE citizens (
    nid            VARCHAR(20)      PRIMARY KEY,
    full_name      VARCHAR(100)     NOT NULL,
    date_of_birth  DATE             NOT NULL,
    photo_url      VARCHAR(255)     NULL,
    citizenship_no VARCHAR(50)      NULL UNIQUE,
    district       VARCHAR(50)      NOT NULL,
    municipality   VARCHAR(50)      NOT NULL,
    ward_no        TINYINT UNSIGNED NOT NULL,
    tole           VARCHAR(100)     NULL,
    created_at     TIMESTAMP        DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 2. CONSTITUENCIES
-- ============================================================
CREATE TABLE constituencies (
    id         SMALLINT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(150)       NOT NULL,
    district   VARCHAR(50)        NOT NULL,
    province   VARCHAR(100)       NOT NULL,
    type       ENUM('fptp', 'pr') NOT NULL DEFAULT 'fptp',
    created_at TIMESTAMP          DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 3. PARTIES
-- ============================================================
CREATE TABLE parties (
    id           SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100)      NOT NULL UNIQUE,
    abbreviation VARCHAR(20)       NOT NULL UNIQUE,
    symbol_url   VARCHAR(255)      NULL,
    is_active    BOOLEAN           NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMP         DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 4. ADMINS
-- ============================================================
CREATE TABLE admins (
    id              INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(200)     NOT NULL,
    email           VARCHAR(255)     NOT NULL UNIQUE,
    password        VARCHAR(255)     NOT NULL,
    failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until    DATETIME         NULL,
    last_login      DATETIME         NULL,
    otp_code        VARCHAR(255)     NULL,
    otp_expires_at  DATETIME         NULL,
    role            VARCHAR(50)      NOT NULL DEFAULT 'Officer',
    remember_token  VARCHAR(100)     NULL,
    created_at      TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME         NULL
);

-- ============================================================
-- 5. USERS
-- ============================================================
CREATE TABLE users (
    id              BIGINT UNSIGNED   AUTO_INCREMENT PRIMARY KEY,
    nid             VARCHAR(20)       NOT NULL UNIQUE,
    voter_id        VARCHAR(30)       NOT NULL UNIQUE,
    password        VARCHAR(255)      NULL,
    constituency_id SMALLINT UNSIGNED NOT NULL,
    is_candidate    BOOLEAN           NOT NULL DEFAULT FALSE,
    failed_attempts TINYINT UNSIGNED  NOT NULL DEFAULT 0,
    blocked_until   DATETIME          NULL,
    last_login      DATETIME          NULL,
    remember_token  VARCHAR(100)      NULL,
    created_at      TIMESTAMP         DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME          NULL,
    FOREIGN KEY (nid)             REFERENCES citizens(nid),
    FOREIGN KEY (constituency_id) REFERENCES constituencies(id)
);

-- ============================================================
-- 6. CANDIDATES
-- ============================================================
CREATE TABLE candidates (
    id                INT UNSIGNED      AUTO_INCREMENT PRIMARY KEY,
    user_id           BIGINT UNSIGNED   NOT NULL UNIQUE,
    party_id          SMALLINT UNSIGNED NULL,
    constituency_id   SMALLINT UNSIGNED NOT NULL,
    election_type     ENUM('fptp', 'pr', 'both') NOT NULL DEFAULT 'fptp',
    ballot_number     TINYINT UNSIGNED  NULL,
    photo_path        VARCHAR(255)      NULL,
    manifesto         TEXT              NULL,
    nomination_status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    is_active         BOOLEAN           NOT NULL DEFAULT TRUE,
    created_at        TIMESTAMP         DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME          NULL,
    FOREIGN KEY (user_id)         REFERENCES users(id),
    FOREIGN KEY (party_id)        REFERENCES parties(id),
    FOREIGN KEY (constituency_id) REFERENCES constituencies(id)
);

-- ============================================================
-- 7. ELECTIONS
-- ============================================================
CREATE TABLE elections (
    id           INT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
    title        VARCHAR(255)  NOT NULL,
    status       ENUM('draft', 'active', 'upcoming', 'completed', 'cancelled') NOT NULL DEFAULT 'draft',
    voting_start DATETIME      NOT NULL,
    voting_end   DATETIME      NOT NULL,
    created_by   INT UNSIGNED  NOT NULL,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME      NULL,
    FOREIGN KEY (created_by) REFERENCES admins(id)
);

-- ============================================================
-- 8. POOLS
-- ============================================================
CREATE TABLE pools (
    id              INT UNSIGNED      AUTO_INCREMENT PRIMARY KEY,
    election_id     INT UNSIGNED      NOT NULL,
    constituency_id SMALLINT UNSIGNED NOT NULL,
    title           VARCHAR(255)      NOT NULL,
    pool_type       ENUM('fptp', 'pr') NOT NULL DEFAULT 'fptp',
    election_type   ENUM('national', 'local', 'by_election') NOT NULL DEFAULT 'national',
    status          ENUM('upcoming', 'active', 'closed') NOT NULL DEFAULT 'upcoming',
    description     TEXT              NULL,
    voting_start    DATETIME          NOT NULL,
    voting_end      DATETIME          NOT NULL,
    created_by      INT UNSIGNED      NOT NULL,
    created_at      TIMESTAMP         DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME          NULL,
    FOREIGN KEY (election_id)     REFERENCES elections(id),
    FOREIGN KEY (constituency_id) REFERENCES constituencies(id),
    FOREIGN KEY (created_by)      REFERENCES admins(id)
);

-- ============================================================
-- 9. POOL CANDIDATES
-- ============================================================
CREATE TABLE pool_candidates (
    id           INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
    pool_id      INT UNSIGNED     NOT NULL,
    candidate_id INT UNSIGNED     NOT NULL,
    ballot_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
    created_at   TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_pool_candidate (pool_id, candidate_id),
    FOREIGN KEY (pool_id)      REFERENCES pools(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
);

-- ============================================================
-- 9.5 POOL PARTIES (PR Voting)
-- ============================================================
CREATE TABLE IF NOT EXISTS pool_parties (
    id           INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
    pool_id      INT UNSIGNED     NOT NULL,
    party_id     SMALLINT UNSIGNED NOT NULL,
    ballot_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
    created_at   TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pool_id)      REFERENCES pools(id) ON DELETE CASCADE,
    FOREIGN KEY (party_id)     REFERENCES parties(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 10. VOTES
-- ============================================================
CREATE TABLE votes (
    id                BIGINT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
    pool_id           INT UNSIGNED     NOT NULL,
    pool_candidate_id INT UNSIGNED     NULL,
    party_id          SMALLINT UNSIGNED NULL,
    voter_hash        VARCHAR(64)      NOT NULL COMMENT 'SHA256(user_id+pool_id+secret) — no raw voter ID stored',
    receipt_code      VARCHAR(50)      NOT NULL UNIQUE,
    ip_address        VARCHAR(45)      NULL,
    cast_at           TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_voter_pool (voter_hash, pool_id),
    FOREIGN KEY (pool_id)           REFERENCES pools(id),
    FOREIGN KEY (pool_candidate_id) REFERENCES pool_candidates(id),
    FOREIGN KEY (party_id)          REFERENCES parties(id) ON DELETE SET NULL
);

-- ============================================================
-- SEED: Default admin  (password: "password")
-- ============================================================
INSERT INTO admins (full_name, email, role, password, updated_at)
VALUES (
    'System Administrator',
    'admin@votingsystem.com',
    'Admin',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    NULL
);

-- ============================================================
-- 11. ADMIN ACTIVITY LOG
-- ============================================================
CREATE TABLE admin_activity_log (
    id          BIGINT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
    admin_id    INT UNSIGNED     NOT NULL,
    action      VARCHAR(50)      NOT NULL,
    module      VARCHAR(50)      NOT NULL,
    description TEXT             NOT NULL,
    record_id   INT UNSIGNED     NULL,
    ip_address  VARCHAR(45)      NOT NULL,
    created_at  TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id),
    INDEX idx_al_admin    (admin_id),
    INDEX idx_al_action   (action),
    INDEX idx_al_module   (module),
    INDEX idx_al_created  (created_at)
);

SET FOREIGN_KEY_CHECKS = 1;