-- ============================================================
--  Voting Management System — Sample / Seed Data
--  Realistic Nepal election data for testing
--  Run AFTER voting_system_schema.sql
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- CITIZENS (NID Registry)
-- ============================================================
INSERT INTO citizens (nid, full_name, date_of_birth, photo_url, citizenship_no, district, municipality, ward_no, tole) VALUES
('1234567890123', 'Ram Prasad Sharma',     '1985-04-12', NULL, 'KTM-12345', 'Kathmandu',  'Kathmandu Metropolitan',    3,  'Baneshwor'),
('1234567890124', 'Sita Devi Thapa',       '1990-07-23', NULL, 'KTM-12346', 'Kathmandu',  'Kathmandu Metropolitan',    5,  'Koteshwor'),
('1234567890125', 'Hari Bahadur KC',       '1978-01-05', NULL, 'LTP-23456', 'Lalitpur',   'Lalitpur Metropolitan',     2,  'Pulchowk'),
('1234567890126', 'Gita Kumari Adhikari',  '1992-11-30', NULL, 'LTP-23457', 'Lalitpur',   'Lalitpur Metropolitan',     4,  'Jawalakhel'),
('1234567890127', 'Bikash Raj Poudel',     '1983-06-15', NULL, 'BKT-34567', 'Bhaktapur',  'Bhaktapur Municipality',    1,  'Suryabinayak'),
('1234567890128', 'Anita Karmacharya',     '1995-03-08', NULL, 'BKT-34568', 'Bhaktapur',  'Madhyapur Thimi',           6,  'Thimi'),
('1234567890129', 'Prakash Magar',         '1975-09-20', NULL, 'PKR-45678', 'Kaski',      'Pokhara Metropolitan',      7,  'Lakeside'),
('1234567890130', 'Sunita Gurung',         '1988-12-01', NULL, 'PKR-45679', 'Kaski',      'Pokhara Metropolitan',      8,  'Bagar'),
('1234567890131', 'Deepak Rijal',          '1970-02-14', NULL, 'PKR-45680', 'Kaski',      'Pokhara Metropolitan',      9,  'Chipledhunga'),
('1234567890132', 'Maya Tamang',           '1993-08-25', NULL, 'PKR-45681', 'Kaski',      'Pokhara Metropolitan',      10, 'Prithvichowk'),
('1234567890133', 'Narayan Prasad Tiwari', '1965-05-30', NULL, 'CHI-56789', 'Chitwan',    'Bharatpur Metropolitan',    1,  'Bharatpur-10'),
('1234567890134', 'Kamala Shrestha',       '1987-10-17', NULL, 'CHI-56790', 'Chitwan',    'Bharatpur Metropolitan',    3,  'Narayangadh'),
('1234567890135', 'Suresh Kumar Yadav',    '1980-03-22', NULL, 'JNK-67890', 'Janakpur',   'Janakpurdham Sub-Metro',    2,  'Ramanand Chowk'),
('1234567890136', 'Priya Laxmi Joshi',     '1997-06-11', NULL, 'KTM-12348', 'Kathmandu',  'Kirtipur Municipality',     1,  'Kirtipur'),
('1234567890137', 'Arun Basnet',           '1972-11-03', NULL, 'KTM-12349', 'Kathmandu',  'Kathmandu Metropolitan',    15, 'Chabahil');

-- ============================================================
-- CONSTITUENCIES
-- ============================================================
INSERT INTO constituencies (name, district, province, type) VALUES
('Kathmandu-1',       'Kathmandu', 'Bagmati',   'fptp'),
('Kathmandu-2',       'Kathmandu', 'Bagmati',   'fptp'),
('Kathmandu-3',       'Kathmandu', 'Bagmati',   'fptp'),
('Lalitpur-1',        'Lalitpur',  'Bagmati',   'fptp'),
('Lalitpur-2',        'Lalitpur',  'Bagmati',   'fptp'),
('Bhaktapur-1',       'Bhaktapur', 'Bagmati',   'fptp'),
('Kaski-1',           'Kaski',     'Gandaki',   'fptp'),
('Kaski-2',           'Kaski',     'Gandaki',   'fptp'),
('Chitwan-1',         'Chitwan',   'Bagmati',   'fptp'),
('Janakpur-1',        'Janakpur',  'Madhesh',   'fptp'),
('Bagmati PR List',   'Bagmati',   'Bagmati',   'pr'),
('Gandaki PR List',   'Gandaki',   'Gandaki',   'pr');

-- ============================================================
-- PARTIES
-- ============================================================
INSERT INTO parties (name, abbreviation, symbol_url, is_active) VALUES
('Nepal Communist Party (UML)',              'CPN-UML',  NULL, TRUE),
('Nepali Congress',                          'NC',       NULL, TRUE),
('CPN (Maoist Centre)',                      'Maoist',   NULL, TRUE),
('Rastriya Swatantra Party',                 'RSP',      NULL, TRUE),
('Rastriya Prajatantra Party',               'RPP',      NULL, TRUE),
('Janajati Party Nepal',                     'JPN',      NULL, TRUE);

-- ============================================================
-- ADMINS (password: "password" for all)
-- ============================================================
INSERT INTO admins (full_name, email, password, updated_at) VALUES
('System Administrator',  'admin@ovms.gov.np',          '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL),
('Election Officer Raju', 'officer.raju@ovms.gov.np',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL);

-- ============================================================
-- USERS (Voters)
-- Voter IDs follow format: VTR-YYYY-XXXXXX
-- ============================================================
INSERT INTO users (nid, voter_id, constituency_id, is_candidate, created_at) VALUES
('1234567890123', 'VTR-2081-000001', 1,  FALSE, NOW()),
('1234567890124', 'VTR-2081-000002', 2,  FALSE, NOW()),
('1234567890125', 'VTR-2081-000003', 4,  FALSE, NOW()),
('1234567890126', 'VTR-2081-000004', 4,  FALSE, NOW()),
('1234567890127', 'VTR-2081-000005', 6,  FALSE, NOW()),
('1234567890128', 'VTR-2081-000006', 6,  FALSE, NOW()),
('1234567890129', 'VTR-2081-000007', 7,  TRUE,  NOW()),
('1234567890130', 'VTR-2081-000008', 7,  FALSE, NOW()),
('1234567890131', 'VTR-2081-000009', 7,  TRUE,  NOW()),
('1234567890132', 'VTR-2081-000010', 8,  FALSE, NOW()),
('1234567890133', 'VTR-2081-000011', 9,  TRUE,  NOW()),
('1234567890134', 'VTR-2081-000012', 9,  FALSE, NOW()),
('1234567890135', 'VTR-2081-000013', 10, TRUE,  NOW()),
('1234567890136', 'VTR-2081-000014', 1,  FALSE, NOW()),
('1234567890137', 'VTR-2081-000015', 3,  TRUE,  NOW());

-- ============================================================
-- CANDIDATES
-- Users with is_candidate=TRUE get a candidate record
-- ============================================================
INSERT INTO candidates (user_id, party_id, constituency_id, election_type, ballot_number, manifesto, nomination_status, updated_at) VALUES
(7,  1, 7,  'both', 1, 'I will focus on road infrastructure, clean water supply, and youth employment in Kaski district. My priority is to bring development funds for Pokhara Metropolitan.',  'approved', NULL),
(9,  2, 7,  'fptp', 2, 'Education and healthcare are the pillars of development. I pledge to open 3 new health posts and upgrade the Pokhara school curriculum within my first term.',             'approved', NULL),
(11, 3, 9,  'fptp', 1, 'Chitwan is the gateway to the Terai. I will work on flood control, farmer subsidies, and improving the highway connecting Bharatpur to Kathmandu.',                   'approved', NULL),
(13, 1, 10, 'pr',   1, 'Madhesh needs proportional representation and equal rights. I will champion federalism and ensure Janakpur receives its fair share of national budget.',              'approved', NULL),
(15, 4, 3,  'fptp', 1, 'As a young leader I represent the new generation of Nepal. Anti-corruption, digital governance, and startup ecosystem development will be my main agenda.',          'approved', NULL);

-- ============================================================
-- ELECTIONS
-- ============================================================
INSERT INTO elections (title, status, voting_start, voting_end, created_by) VALUES
('House of Representatives Election 2081', 'active',    '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
('Provincial Assembly Election 2081',      'upcoming',  '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
('Local By-Election 2081',                 'draft',     '2081-12-15 07:00:00', '2081-12-15 17:00:00', 2);

-- ============================================================
-- POOLS
-- ============================================================
INSERT INTO pools (election_id, constituency_id, title, pool_type, election_type, status, description, voting_start, voting_end, created_by) VALUES
(1, 7,  'Kaski-1 FPTP',             'fptp', 'national', 'active',   'House of Representatives — Kaski Constituency 1',              '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(1, 9,  'Chitwan-1 FPTP',           'fptp', 'national', 'active',   'House of Representatives — Chitwan Constituency 1',            '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(1, 10, 'Janakpur-1 FPTP',          'fptp', 'national', 'active',   'House of Representatives — Janakpur Constituency 1',           '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(1, 3,  'Kathmandu-3 FPTP',         'fptp', 'national', 'active',   'House of Representatives — Kathmandu Constituency 3',          '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(2, 11, 'Bagmati Province PR',      'pr',   'national', 'upcoming', 'Provincial Assembly — Bagmati Proportional Representation',    '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(2, 12, 'Gandaki Province PR',      'pr',   'national', 'upcoming', 'Provincial Assembly — Gandaki Proportional Representation',    '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(3, 1,  'Kathmandu-1 By-Election',  'fptp', 'local',    'upcoming', 'By-election for vacant seat in Kathmandu-1',                   '2081-12-15 07:00:00', '2081-12-15 17:00:00', 2);

-- ============================================================
-- POOL CANDIDATES (ballot entries)
-- ============================================================
INSERT INTO pool_candidates (pool_id, candidate_id, ballot_order) VALUES
(1, 1, 1),
(1, 2, 2),
(2, 3, 1),
(3, 4, 1),
(4, 5, 1);

-- ============================================================
-- VOTES (sample cast votes — secret ballot)
-- voter_hash is SHA256(user_id + pool_id + 'test_secret')
-- In production this is generated by the application
-- ============================================================
INSERT INTO votes (pool_id, pool_candidate_id, voter_hash, receipt_code, ip_address) VALUES
(1, 1, SHA2(CONCAT('1', '1', 'test_secret'), 256), 'RCP-2081-000001', '192.168.1.10'),
(1, 2, SHA2(CONCAT('8', '1', 'test_secret'), 256), 'RCP-2081-000002', '192.168.1.11'),
(2, 3, SHA2(CONCAT('12','2', 'test_secret'), 256), 'RCP-2081-000003', '192.168.1.12'),
(3, 4, SHA2(CONCAT('13','3', 'test_secret'), 256), 'RCP-2081-000004', '192.168.1.13'),
(4, 5, SHA2(CONCAT('15','4', 'test_secret'), 256), 'RCP-2081-000005', '192.168.1.14');

SET FOREIGN_KEY_CHECKS = 1;