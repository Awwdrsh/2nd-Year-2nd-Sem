-- ============================================================
--  OVMS Migration: Add last_login column to admins table
--  Run once on any database that was created from the
--  original schema.sql (which lacked this column).
-- ============================================================

ALTER TABLE admins
    ADD COLUMN last_login DATETIME NULL
        COMMENT 'Timestamp of most recent successful login'
        AFTER otp_expires_at;
