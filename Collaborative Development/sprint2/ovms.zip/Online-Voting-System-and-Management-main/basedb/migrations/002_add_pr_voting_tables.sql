-- ============================================================
--  OVMS Migration: Add pool_parties and Update votes for PR
--  Author: Antigravity
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Create pool_parties table if it doesn't exist
CREATE TABLE IF NOT EXISTS pool_parties (
    id           INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
    pool_id      INT UNSIGNED     NOT NULL,
    party_id     SMALLINT UNSIGNED NOT NULL,
    ballot_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
    created_at   TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pool_id)      REFERENCES pools(id) ON DELETE CASCADE,
    FOREIGN KEY (party_id)     REFERENCES parties(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Update votes table
-- Add party_id column
ALTER TABLE votes 
    ADD COLUMN party_id SMALLINT UNSIGNED NULL 
    AFTER pool_candidate_id;

-- Make pool_candidate_id nullable (required for PR voting)
ALTER TABLE votes 
    MODIFY COLUMN pool_candidate_id INT UNSIGNED NULL;

-- Add foreign key for party_id in votes
ALTER TABLE votes 
    ADD CONSTRAINT fk_votes_party 
    FOREIGN KEY (party_id) REFERENCES parties(id) ON DELETE SET NULL;

SET FOREIGN_KEY_CHECKS = 1;
