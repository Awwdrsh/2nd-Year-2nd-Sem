<?php
define('BASE_PATH', __DIR__);
require_once BASE_PATH . '/core/Env.php';
Env::load();

$config = require BASE_PATH . '/config/config.php';
$baseUrl = $config['base_url'] ?? '';

// Auto-detect BASE_URL logic from index.php
$scriptName = $_SERVER['SCRIPT_NAME'];
$scriptDir = str_replace('\\', '/', dirname($scriptName));
$detectedBaseUrl = ($scriptDir === '/') ? '' : $scriptDir;

echo "<h1>Asset Diagnostic</h1>";
echo "<pre>";
echo "URL Requested: " . $_SERVER['REQUEST_URI'] . "\n";
echo "SCRIPT_NAME: " . $scriptName . "\n";
echo "Detected Base URL: " . $detectedBaseUrl . "\n";
echo "Config Base URL: " . $baseUrl . "\n";
echo "\n--- File Checks ---\n";

$files = [
    '/public/assets/css/style.css',
    '/public/assets/css/admin.css',
    '/public/assets/css/voter.css'
];

foreach ($files as $file) {
    $fullPath = BASE_PATH . $file;
    echo "Checking: $file\n";
    echo "  System Path: $fullPath\n";
    if (file_exists($fullPath)) {
        echo "  ✅ EXISTS (Size: " . filesize($fullPath) . " bytes)\n";
    } else {
        echo "  ❌ NOT FOUND\n";
    }
}

echo "\n--- Suggested Links ---\n";
$finalBase = $baseUrl ?: $detectedBaseUrl;
echo "Current BASE_URL: '$finalBase'\n";
foreach ($files as $file) {
    echo "Link: <link href=\"" . $finalBase . $file . "\" rel=\"stylesheet\">\n";
}

echo "</pre>";
