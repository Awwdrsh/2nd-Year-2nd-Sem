<?php
/**
 * Purge Election Data
 * Deletes all votes, pool_candidates, pools, and elections.
 */
// 1. Initialize environment
define('BASE_PATH', __DIR__);
require_once BASE_PATH . '/core/Env.php';

// Check if .env exists and is readable
if (!file_exists(BASE_PATH . '/.env')) {
    die("❌ ERROR: .env file not found at " . BASE_PATH . "/.env\n");
}

if (!is_readable(BASE_PATH . '/.env')) {
    $owner = function_exists('posix_getpwuid') ? posix_getpwuid(fileowner(BASE_PATH . '/.env'))['name'] : fileowner(BASE_PATH . '/.env');
    $perms = substr(sprintf('%o', fileperms(BASE_PATH . '/.env')), -4);
    die("❌ ERROR: .env file is NOT readable by the current user (" . get_current_user() . ").
   File Owner: $owner
   Permissions: $perms
   Fix: Run 'sudo chmod 644 .env' on your server.\n");
}

// Load .env
Env::load(BASE_PATH . '/.env');

// 2. Attempt Database Connection
require_once BASE_PATH . '/core/Database.php';

try {
    $db = Database::getInstance();
    echo "✅ Database connection successful.\n\n";
} catch (PDOException $e) {
    die("❌ ERROR: Database Connection Failed: " . $e->getMessage() . "\n");
}

try {
    echo "⚠️  Purging all election data...\n";
    
    // Disable foreign key checks to allow truncation
    $db->query("SET FOREIGN_KEY_CHECKS = 0");
    
    // Order matters if we weren't using FOREIGN_KEY_CHECKS = 0, but truncate is safer here
    $tables = ['votes', 'pool_candidates', 'pools', 'elections', 'candidates'];
    
    foreach ($tables as $table) {
        $db->query("TRUNCATE TABLE $table");
        echo "✅ Table '$table' cleared.\n";
    }
    
    // Reset candidate flags in users table
    $db->query("UPDATE users SET is_candidate = 0");
    echo "✅ User candidate flags reset.\n";

    $db->query("SET FOREIGN_KEY_CHECKS = 1");
    
    echo "\n🚀 All election data has been purged successfully!\n";
    echo "You can now create fresh elections from the Admin panel.\n";

} catch (Exception $e) {
    die("❌ ERROR: " . $e->getMessage() . "\n");
}
