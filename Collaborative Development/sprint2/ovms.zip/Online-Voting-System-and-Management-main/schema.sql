-- ============================================================
--  Voting Management System — Consolidated Database Dump
--  Contains: Schema + Sample Data
--  Compatibility: MySQL / MariaDB (XAMPP friendly)
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET NAMES utf8mb4;

-- ============================================================
-- 1. CITIZENS
-- ============================================================
DROP TABLE IF EXISTS citizens;
CREATE TABLE citizens (
    nid            VARCHAR(20)      PRIMARY KEY,
    full_name      VARCHAR(100)     NOT NULL,
    date_of_birth  DATE             NOT NULL,
    photo_url      VARCHAR(255)     NULL,
    citizenship_no VARCHAR(50)      NULL UNIQUE,
    district       VARCHAR(50)      NOT NULL,
    municipality   VARCHAR(50)      NOT NULL,
    ward_no        TINYINT UNSIGNED NOT NULL,
    tole           VARCHAR(100)     NULL,
    created_at     TIMESTAMP        DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO citizens (nid, full_name, date_of_birth, photo_url, citizenship_no, district, municipality, ward_no, tole) VALUES
('1234567890123', 'Ram Prasad Sharma',     '1985-04-12', NULL, 'KTM-12345', 'Kathmandu',  'Kathmandu Metropolitan',    3,  'Baneshwor'),
('1234567890124', 'Sita Devi Thapa',       '1990-07-23', NULL, 'KTM-12346', 'Kathmandu',  'Kathmandu Metropolitan',    5,  'Koteshwor'),
('1234567890125', 'Hari Bahadur KC',       '1978-01-05', NULL, 'LTP-23456', 'Lalitpur',   'Lalitpur Metropolitan',     2,  'Pulchowk'),
('1234567890126', 'Gita Kumari Adhikari',  '1992-11-30', NULL, 'LTP-23457', 'Lalitpur',   'Lalitpur Metropolitan',     4,  'Jawalakhel'),
('1234567890127', 'Bikash Raj Poudel',     '1983-06-15', NULL, 'BKT-34567', 'Bhaktapur',  'Bhaktapur Municipality',    1,  'Suryabinayak'),
('1234567890128', 'Anita Karmacharya',     '1995-03-08', NULL, 'BKT-34568', 'Bhaktapur',  'Madhyapur Thimi',           6,  'Thimi'),
('1234567890129', 'Prakash Magar',         '1975-09-20', NULL, 'PKR-45678', 'Kaski',      'Pokhara Metropolitan',      7,  'Lakeside'),
('1234567890130', 'Sunita Gurung',         '1988-12-01', NULL, 'PKR-45679', 'Kaski',      'Pokhara Metropolitan',      8,  'Bagar'),
('1234567890131', 'Deepak Rijal',          '1970-02-14', NULL, 'PKR-45680', 'Kaski',      'Pokhara Metropolitan',      9,  'Chipledhunga'),
('1234567890132', 'Maya Tamang',           '1993-08-25', NULL, 'PKR-45681', 'Kaski',      'Pokhara Metropolitan',      10, 'Prithvichowk'),
('1234567890133', 'Narayan Prasad Tiwari', '1965-05-30', NULL, 'CHI-56789', 'Chitwan',    'Bharatpur Metropolitan',    1,  'Bharatpur-10'),
('1234567890134', 'Kamala Shrestha',       '1987-10-17', NULL, 'CHI-56790', 'Chitwan',    'Bharatpur Metropolitan',    3,  'Narayangadh'),
('1234567890135', 'Suresh Kumar Yadav',    '1980-03-22', NULL, 'JNK-67890', 'Janakpur',   'Janakpurdham Sub-Metro',    2,  'Ramanand Chowk'),
('1234567890136', 'Priya Laxmi Joshi',     '1997-06-11', NULL, 'KTM-12348', 'Kathmandu',  'Kirtipur Municipality',     1,  'Kirtipur'),
('1234567890137', 'Arun Basnet',           '1972-11-03', NULL, 'KTM-12349', 'Kathmandu',  'Kathmandu Metropolitan',    15, 'Chabahil');

-- ============================================================
-- 2. CONSTITUENCIES
-- ============================================================
DROP TABLE IF EXISTS constituencies;
CREATE TABLE constituencies (
    id         SMALLINT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(150)       NOT NULL,
    district   VARCHAR(50)        NOT NULL,
    province   VARCHAR(100)       NOT NULL,
    type       ENUM('fptp', 'pr') NOT NULL DEFAULT 'fptp',
    created_at TIMESTAMP          DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO constituencies (id, name, district, province, type) VALUES
(1, 'Kathmandu-1',       'Kathmandu', 'Bagmati',   'fptp'),
(2, 'Kathmandu-2',       'Kathmandu', 'Bagmati',   'fptp'),
(3, 'Kathmandu-3',       'Kathmandu', 'Bagmati',   'fptp'),
(4, 'Lalitpur-1',        'Lalitpur',  'Bagmati',   'fptp'),
(5, 'Lalitpur-2',        'Lalitpur',  'Bagmati',   'fptp'),
(6, 'Bhaktapur-1',       'Bhaktapur', 'Bagmati',   'fptp'),
(7, 'Kaski-1',           'Kaski',     'Gandaki',   'fptp'),
(8, 'Kaski-2',           'Kaski',     'Gandaki',   'fptp'),
(9, 'Chitwan-1',         'Chitwan',   'Bagmati',   'fptp'),
(10,'Janakpur-1',        'Janakpur',  'Madhesh',   'fptp'),
(11,'Bagmati PR List',   'Bagmati',   'Bagmati',   'pr'),
(12,'Gandaki PR List',   'Gandaki',   'Gandaki',   'pr');

-- ============================================================
-- 3. PARTIES
-- ============================================================
DROP TABLE IF EXISTS parties;
CREATE TABLE parties (
    id           SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100)      NOT NULL UNIQUE,
    abbreviation VARCHAR(20)       NOT NULL UNIQUE,
    symbol_url   VARCHAR(255)      NULL,
    is_active    BOOLEAN           NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMP         DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO parties (id, name, abbreviation, symbol_url, is_active) VALUES
(1, 'Nepal Communist Party (UML)',              'CPN-UML',  NULL, TRUE),
(2, 'Nepali Congress',                          'NC',       NULL, TRUE),
(3, 'CPN (Maoist Centre)',                      'Maoist',   NULL, TRUE),
(4, 'Rastriya Swatantra Party',                 'RSP',      NULL, TRUE),
(5, 'Rastriya Prajatantra Party',               'RPP',      NULL, TRUE),
(6, 'Janajati Party Nepal',                     'JPN',      NULL, TRUE);

-- ============================================================
-- 4. ADMINS
-- ============================================================
DROP TABLE IF EXISTS admins;
CREATE TABLE admins (
    id              INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(200)     NOT NULL,
    email           VARCHAR(255)     NOT NULL UNIQUE,
    password        VARCHAR(255)     NOT NULL,
    failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until    DATETIME         NULL,
    last_login      DATETIME         NULL,
    otp_code        VARCHAR(255)     NULL,
    otp_expires_at  DATETIME         NULL,
    role            VARCHAR(50)      NOT NULL DEFAULT 'Officer',
    remember_token  VARCHAR(100)     NULL,
    created_at      TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME         NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO admins (id, full_name, email, password, role) VALUES
(1, 'System Administrator',  'admin@ovms.gov.np',          '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin'),
(2, 'Election Officer Raju', 'officer.raju@ovms.gov.np',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Officer');

-- ============================================================
-- 5. USERS
-- ============================================================
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id              BIGINT UNSIGNED   AUTO_INCREMENT PRIMARY KEY,
    nid             VARCHAR(20)       NOT NULL UNIQUE,
    voter_id        VARCHAR(30)       NOT NULL UNIQUE,
    password        VARCHAR(255)      NULL,
    constituency_id SMALLINT UNSIGNED NOT NULL,
    is_candidate    BOOLEAN           NOT NULL DEFAULT FALSE,
    failed_attempts TINYINT UNSIGNED  NOT NULL DEFAULT 0,
    blocked_until   DATETIME          NULL,
    last_login      DATETIME          NULL,
    remember_token  VARCHAR(100)      NULL,
    created_at      TIMESTAMP         DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME          NULL,
    FOREIGN KEY (nid)             REFERENCES citizens(nid),
    FOREIGN KEY (constituency_id) REFERENCES constituencies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users (id, nid, voter_id, constituency_id, is_candidate) VALUES
(1, '1234567890123', 'VTR-2081-000001', 1,  FALSE),
(2, '1234567890124', 'VTR-2081-000002', 2,  FALSE),
(3, '1234567890125', 'VTR-2081-000003', 4,  FALSE),
(4, '1234567890126', 'VTR-2081-000004', 4,  FALSE),
(5, '1234567890127', 'VTR-2081-000005', 6,  FALSE),
(6, '1234567890128', 'VTR-2081-000006', 6,  FALSE),
(7, '1234567890129', 'VTR-2081-000007', 7,  TRUE),
(8, '1234567890130', 'VTR-2081-000008', 7,  FALSE),
(9, '1234567890131', 'VTR-2081-000009', 7,  TRUE),
(10, '1234567890132', 'VTR-2081-000010', 8,  FALSE),
(11, '1234567890133', 'VTR-2081-000011', 9,  TRUE),
(12, '1234567890134', 'VTR-2081-000012', 9,  FALSE),
(13, '1234567890135', 'VTR-2081-000013', 10, TRUE),
(14, '1234567890136', 'VTR-2081-000014', 1,  FALSE),
(15, '1234567890137', 'VTR-2081-000015', 3,  TRUE);

-- ============================================================
-- 6. CANDIDATES
-- ============================================================
DROP TABLE IF EXISTS candidates;
CREATE TABLE candidates (
    id                INT UNSIGNED      AUTO_INCREMENT PRIMARY KEY,
    user_id           BIGINT UNSIGNED   NOT NULL UNIQUE,
    party_id          SMALLINT UNSIGNED NULL,
    constituency_id   SMALLINT UNSIGNED NOT NULL,
    election_type     ENUM('fptp', 'pr', 'both') NOT NULL DEFAULT 'fptp',
    ballot_number     TINYINT UNSIGNED  NULL,
    photo_path        VARCHAR(255)      NULL,
    manifesto         TEXT              NULL,
    nomination_status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    is_active         BOOLEAN           NOT NULL DEFAULT TRUE,
    created_at        TIMESTAMP         DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME          NULL,
    FOREIGN KEY (user_id)         REFERENCES users(id),
    FOREIGN KEY (party_id)        REFERENCES parties(id),
    FOREIGN KEY (constituency_id) REFERENCES constituencies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO candidates (id, user_id, party_id, constituency_id, election_type, ballot_number, manifesto, nomination_status) VALUES
(1, 7,  1, 7,  'both', 1, 'I will focus on road infrastructure, clean water supply, and youth employment in Kaski district.',  'approved'),
(2, 9,  2, 7,  'fptp', 2, 'Education and healthcare are the pillars of development.',             'approved'),
(3, 11, 3, 9,  'fptp', 1, 'Chitwan is the gateway to the Terai. I will work on flood control.',                   'approved'),
(4, 13, 1, 10, 'pr',   1, 'Madhesh needs proportional representation and equal rights.',              'approved'),
(5, 15, 4, 3,  'fptp', 1, 'As a young leader I represent the new generation of Nepal.',          'approved');

-- ============================================================
-- 7. ELECTIONS
-- ============================================================
DROP TABLE IF EXISTS elections;
CREATE TABLE elections (
    id           INT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
    title        VARCHAR(255)  NOT NULL,
    status       ENUM('draft', 'active', 'upcoming', 'completed', 'cancelled') NOT NULL DEFAULT 'draft',
    voting_start DATETIME      NOT NULL,
    voting_end   DATETIME      NOT NULL,
    created_by   INT UNSIGNED  NOT NULL,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME      NULL,
    FOREIGN KEY (created_by) REFERENCES admins(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO elections (id, title, status, voting_start, voting_end, created_by) VALUES
(1, 'House of Representatives Election 2081', 'active',    '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(2, 'Provincial Assembly Election 2081',      'upcoming',  '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(3, 'Local By-Election 2081',                 'draft',     '2081-12-15 07:00:00', '2081-12-15 17:00:00', 2);

-- ============================================================
-- 8. POOLS
-- ============================================================
DROP TABLE IF EXISTS pools;
CREATE TABLE pools (
    id              INT UNSIGNED      AUTO_INCREMENT PRIMARY KEY,
    election_id     INT UNSIGNED      NOT NULL,
    constituency_id SMALLINT UNSIGNED NOT NULL,
    title           VARCHAR(255)      NOT NULL,
    pool_type       ENUM('fptp', 'pr') NOT NULL DEFAULT 'fptp',
    election_type   ENUM('national', 'local', 'by_election') NOT NULL DEFAULT 'national',
    status          ENUM('upcoming', 'active', 'closed') NOT NULL DEFAULT 'upcoming',
    description     TEXT              NULL,
    voting_start    DATETIME          NOT NULL,
    voting_end      DATETIME          NOT NULL,
    created_by      INT UNSIGNED      NOT NULL,
    created_at      TIMESTAMP         DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME          NULL,
    FOREIGN KEY (election_id)     REFERENCES elections(id),
    FOREIGN KEY (constituency_id) REFERENCES constituencies(id),
    FOREIGN KEY (created_by)      REFERENCES admins(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO pools (id, election_id, constituency_id, title, pool_type, election_type, status, description, voting_start, voting_end, created_by) VALUES
(1, 1, 7,  'Kaski-1 FPTP',             'fptp', 'national', 'active',   'House of Representatives — Kaski Constituency 1',              '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(2, 1, 9,  'Chitwan-1 FPTP',           'fptp', 'national', 'active',   'House of Representatives — Chitwan Constituency 1',            '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(3, 1, 10, 'Janakpur-1 FPTP',          'fptp', 'national', 'active',   'House of Representatives — Janakpur Constituency 1',           '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(4, 1, 3,  'Kathmandu-3 FPTP',         'fptp', 'national', 'active',   'House of Representatives — Kathmandu Constituency 3',          '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(5, 2, 11, 'Bagmati Province PR',      'pr',   'national', 'upcoming', 'Provincial Assembly — Bagmati Proportional Representation',    '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(6, 2, 12, 'Gandaki Province PR',      'pr',   'national', 'upcoming', 'Provincial Assembly — Gandaki Proportional Representation',    '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(7, 3, 1,  'Kathmandu-1 By-Election',  'fptp', 'local',    'upcoming', 'By-election for vacant seat in Kathmandu-1',                   '2081-12-15 07:00:00', '2081-12-15 17:00:00', 2);

-- ============================================================
-- 9. POOL CANDIDATES
-- ============================================================
DROP TABLE IF EXISTS pool_candidates;
CREATE TABLE pool_candidates (
    id           INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
    pool_id      INT UNSIGNED     NOT NULL,
    candidate_id INT UNSIGNED     NOT NULL,
    ballot_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
    created_at   TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_candidate (candidate_id),
    FOREIGN KEY (pool_id)      REFERENCES pools(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 9.5 POOL PARTIES (PR Voting)
-- ============================================================
CREATE TABLE IF NOT EXISTS pool_parties (
    id           INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
    pool_id      INT UNSIGNED     NOT NULL,
    party_id     SMALLINT UNSIGNED NOT NULL,
    ballot_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
    created_at   TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pool_id)      REFERENCES pools(id) ON DELETE CASCADE,
    FOREIGN KEY (party_id)     REFERENCES parties(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO pool_candidates (id, pool_id, candidate_id, ballot_order) VALUES
(1, 1, 1, 1),
(2, 1, 2, 2),
(3, 2, 3, 1),
(4, 3, 4, 1),
(5, 4, 5, 1);

-- ============================================================
-- 10. VOTES
-- ============================================================
DROP TABLE IF EXISTS votes;
CREATE TABLE votes (
    id                BIGINT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
    pool_id           INT UNSIGNED     NOT NULL,
    pool_candidate_id INT UNSIGNED     NULL,
    party_id          SMALLINT UNSIGNED NULL,
    voter_hash        VARCHAR(64)      NOT NULL COMMENT 'SHA256(user_id+pool_id+secret) — no raw voter ID stored',
    receipt_code      VARCHAR(50)      NOT NULL UNIQUE,
    ip_address        VARCHAR(45)      NULL,
    cast_at           TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_voter_pool (voter_hash, pool_id),
    FOREIGN KEY (pool_id)           REFERENCES pools(id),
    FOREIGN KEY (pool_candidate_id) REFERENCES pool_candidates(id),
    FOREIGN KEY (party_id)          REFERENCES parties(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 11. ADMIN ACTIVITY LOG
-- ============================================================
DROP TABLE IF EXISTS admin_activity_log;
CREATE TABLE admin_activity_log (
    id          BIGINT UNSIGNED  AUTO_INCREMENT PRIMARY KEY,
    admin_id    INT UNSIGNED     NOT NULL,
    action      VARCHAR(50)      NOT NULL,
    module      VARCHAR(50)      NOT NULL,
    description TEXT             NOT NULL,
    record_id   INT UNSIGNED     NULL,
    ip_address  VARCHAR(45)      NOT NULL,
    created_at  TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id),
    INDEX idx_al_admin    (admin_id),
    INDEX idx_al_action   (action),
    INDEX idx_al_module   (module),
    INDEX idx_al_created  (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
