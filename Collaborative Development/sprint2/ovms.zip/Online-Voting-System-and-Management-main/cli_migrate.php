<?php
/**
 * OVMS CLI Migration Script
 * 
 * Usage from terminal:
 * php cli_migrate.php
 */

if (php_sapi_name() !== 'cli') {
    die("This script can only be run from the command line.\n");
}

define('BASE_PATH', __DIR__);

require_once BASE_PATH . '/core/Env.php';
require_once BASE_PATH . '/core/Database.php';

// Load env
Env::load(BASE_PATH . '/.env');

echo "========================================\n";
echo " OVMS Database Migration (Azure Sync)   \n";
echo "========================================\n\n";

try {
    $db = Database::getInstance();
    
    echo "[1/5] Adding 'password' column to 'users' table... ";
    try {
        $db->query("ALTER TABLE users ADD COLUMN password VARCHAR(255) NULL AFTER voter_id");
        echo "Done.\n";
    } catch (Exception $e) {
        echo "Skipped (Already exists or error: " . $e->getMessage() . ").\n";
    }

    echo "[2/5] Adding 'is_active' column to 'candidates' table... ";
    try {
        $db->query("ALTER TABLE candidates ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER nomination_status");
        echo "Done.\n";
    } catch (Exception $e) {
        echo "Skipped (Already exists).\n";
    }

    echo "[3/5] Adding 'election_type' column to 'candidates' table... ";
    try {
        $db->query("ALTER TABLE candidates ADD COLUMN election_type ENUM('fptp', 'pr', 'both') NOT NULL DEFAULT 'fptp' AFTER constituency_id");
        echo "Done.\n";
    } catch (Exception $e) {
        echo "Skipped (Already exists).\n";
    }

    echo "[4/5] Adding 'pool_type' column to 'pools' table... ";
    try {
        $db->query("ALTER TABLE pools ADD COLUMN pool_type ENUM('fptp', 'pr') NOT NULL DEFAULT 'fptp' AFTER title");
        echo "Done.\n";
    } catch (Exception $e) {
        echo "Skipped (Already exists).\n";
    }

    echo "[5/5] Migrating missing voter passwords... ";
    $users = $db->query("SELECT id, nid FROM users WHERE password IS NULL OR password = ''")->fetchAll();
    
    if (count($users) > 0) {
        $count = 0;
        foreach ($users as $u) {
            $hash = password_hash('pwd' . $u['nid'], PASSWORD_DEFAULT);
            $db->query("UPDATE users SET password = ? WHERE id = ?", [$hash, $u['id']]);
            $count++;
        }
        echo "Updated $count voters.\n";
    } else {
        echo "No voters needed updating.\n";
    }

    echo "[6/7] Creating 'pool_parties' table... ";
    try {
        $db->query("CREATE TABLE IF NOT EXISTS pool_parties (
            id           INT UNSIGNED     AUTO_INCREMENT PRIMARY KEY,
            pool_id      INT UNSIGNED     NOT NULL,
            party_id     SMALLINT UNSIGNED NOT NULL,
            ballot_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
            created_at   TIMESTAMP        DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (pool_id)      REFERENCES pools(id) ON DELETE CASCADE,
            FOREIGN KEY (party_id)     REFERENCES parties(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        echo "Done.\n";
    } catch (Exception $e) {
        echo "Error creating pool_parties: " . $e->getMessage() . "\n";
    }

    echo "[7/7] Updating 'votes' table for PR support... ";
    try {
        // Add party_id if not exists
        try {
            $db->query("ALTER TABLE votes ADD COLUMN party_id SMALLINT UNSIGNED NULL AFTER pool_candidate_id");
            $db->query("ALTER TABLE votes ADD CONSTRAINT fk_votes_party FOREIGN KEY (party_id) REFERENCES parties(id) ON DELETE SET NULL");
            echo "Column party_id added. ";
        } catch (Exception $e) {
            echo "party_id already exists or error. ";
        }

        // Make pool_candidate_id nullable
        $db->query("ALTER TABLE votes MODIFY COLUMN pool_candidate_id INT UNSIGNED NULL");
        echo "pool_candidate_id made nullable.\n";
    } catch (Exception $e) {
        echo "Error updating votes table: " . $e->getMessage() . "\n";
    }

    echo "\n[SUCCESS] Migration completed successfully.\n";

} catch (Exception $e) {
    echo "\n[ERROR] Migration failed: " . $e->getMessage() . "\n";
}
