<?php
/**
 * Database Connection Diagnostic Tool
 * Run this from your browser to see what's wrong with the connection.
 */

define('BASE_PATH', __DIR__);
require_once BASE_PATH . '/core/Env.php';

echo "<h1>OVMS Database Diagnostic</h1>";
echo "<pre>";

$envPath = BASE_PATH . '/.env';
echo "Checking .env file at: $envPath\n";

if (file_exists($envPath)) {
    echo "✅ .env file exists.\n";
    if (is_readable($envPath)) {
        echo "✅ .env file is readable.\n";
        $permissions = substr(sprintf('%o', fileperms($envPath)), -4);
        echo "   Permissions: $permissions\n";
        echo "   Owner: " . (function_exists('posix_getpwuid') ? posix_getpwuid(fileowner($envPath))['name'] : fileowner($envPath)) . "\n";
    } else {
        echo "❌ .env file is NOT readable by the web server user.\n";
    }
} else {
    echo "❌ .env file does NOT exist at this path.\n";
}

echo "\nLoading Environment Variables...\n";
Env::load($envPath);

$db_host = Env::get('DB_HOST', 'NOT SET');
$db_user = Env::get('DB_USER', 'NOT SET');
$db_pass = Env::get('DB_PASS', 'NOT SET');
$db_name = Env::get('DB_NAME', 'NOT SET');

echo "DB_HOST: $db_host\n";
echo "DB_USER: $db_user\n";
echo "DB_PASS: " . ($db_pass === 'NOT SET' ? 'NOT SET' : (empty($db_pass) ? '(EMPTY STRING)' : '******** (Length: ' . strlen($db_pass) . ')')) . "\n";
echo "DB_NAME: $db_name\n";

echo "\nAttempting PDO Connection...\n";
$dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";
try {
    $start = microtime(true);
    $pdo = new PDO($dsn, $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_TIMEOUT => 5
    ]);
    $end = microtime(true);
    echo "✅ SUCCESS! Connected in " . round(($end - $start) * 1000, 2) . "ms\n";
    echo "Server Info: " . $pdo->getAttribute(PDO::ATTR_SERVER_INFO) . "\n";
} catch (PDOException $e) {
    echo "❌ CONNECTION FAILED!\n";
    echo "Error Code: " . $e->getCode() . "\n";
    echo "Error Message: " . $e->getMessage() . "\n";
    
    if ($db_host === 'localhost' || $db_host === '127.0.0.1') {
        echo "\nTip: If you are on Ubuntu, make sure the 'root' user is allowed to connect via password.\n";
        echo "Run this in MySQL: ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'your_password';\n";
    }
}

echo "</pre>";
?>
