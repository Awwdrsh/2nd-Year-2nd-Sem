# Online Voting Management System (OVMS)

A secure, web-based voting management platform built with PHP and MySQL. Supports election management, candidate registration, voter authentication, and anonymous ballot casting.

---

## Table of Contents

- [Requirements](#requirements)
- [Quick Setup](#quick-setup)
  - [Mac (XAMPP)](#mac-xampp)
  - [Windows (XAMPP)](#windows-xampp)
- [Manual Setup (No Script)](#manual-setup-no-script)
- [Login Credentials](#login-credentials)
- [Project Structure](#project-structure)
- [Troubleshooting](#troubleshooting)

---

## Requirements

| Requirement | Version |
|-------------|---------|
| PHP | 7.4 or higher |
| MySQL | 5.7 or higher |
| Apache | 2.4+ with `mod_rewrite` enabled |
| XAMPP | Any recent version |

---

## Quick Setup

> ⚠️ **Important:** After cloning, you **must rename the folder to `ovms`**. The app routing depends on this exact folder name.

---

### Mac (XAMPP)

**Step 1 — Open Terminal and navigate to XAMPP's web root:**
```bash
cd /Applications/XAMPP/xamppfiles/htdocs
```

**Step 2 — Clone the repository and rename the folder to `ovms`:**
```bash
git clone https://github.com/Awwdrsh/Online-Voting-System-and-Management.git ovms
cd ovms
```

**Step 3 — Start Apache and MySQL from the XAMPP Control Panel.**

**Step 4 — Run the setup script:**
```bash
bash setup.sh
```

The script will ask you for:
- DB Host → press Enter for default (`127.0.0.1`)
- DB Name → press Enter for default (`voting_system`)
- DB User → press Enter for default (`root`)
- DB Password → press Enter if none (XAMPP default has no password)
- BASE_URL → press Enter to confirm `/ovms`

The script automatically creates the database, imports the schema, and loads sample data.

**Step 5 — Open the app in your browser:**
```
http://localhost/ovms
```

---

### Windows (XAMPP)

**Step 1 — Open Command Prompt and navigate to XAMPP's web root:**
```cmd
cd C:\xampp\htdocs
```

**Step 2 — Clone the repository and rename the folder to `ovms`:**
```cmd
git clone https://github.com/Awwdrsh/Online-Voting-System-and-Management.git ovms
cd ovms
```

**Step 3 — Start Apache and MySQL from the XAMPP Control Panel.**

**Step 4 — Copy the environment file:**
```cmd
copy .env.example .env
```

**Step 5 — Open `.env` in a text editor and set your database credentials:**
```env
DB_HOST=127.0.0.1
DB_NAME=voting_system
DB_USER=root
DB_PASS=
BASE_URL=/ovms
```

**Step 6 — Set up the database manually via phpMyAdmin:**
1. Open `http://localhost/phpmyadmin`
2. Create a new database named `voting_system`
3. Select `voting_system` → click **Import**
4. Import `schema.sql` (located in the project root directory)

**Step 7 — Open the app in your browser:**
```
http://localhost/ovms
```

---

## Manual Setup (No Script)

If you prefer to set things up manually without running `setup.sh`:

**1. Copy the environment file:**
```bash
cp .env.example .env
```

**2. Edit `.env` with your database credentials:**
```env
DB_HOST=127.0.0.1
DB_NAME=voting_system
DB_USER=root
DB_PASS=
BASE_URL=/ovms
```

**3. Create the database and import the schema:**
```bash
mysql -u root -e "CREATE DATABASE IF NOT EXISTS voting_system;"
mysql -u root voting_system < schema.sql
```

If your MySQL has a password:
```bash
mysql -u root -p voting_system < schema.sql
```

**4. Open the app:**
```
http://localhost/ovms
```

---

## Login Credentials

> All default passwords are `password`. Change these in a production environment.

### Admin Accounts

Access the admin portal at: `http://localhost/ovms/login`

| Name | Email | Password | Role |
|------|-------|----------|------|
| System Administrator | `admin@ovms.gov.np` | `password` | Super Admin |
| Election Officer Raju | `officer.raju@ovms.gov.np` | `password` | Officer |

### Voter Accounts

Access the voter portal at: `http://localhost/ovms/voter/login`

Voters log in using their **NID** and **Voter ID**.

| Full Name | NID | Voter ID | Constituency |
|-----------|-----|----------|--------------|
| Ram Prasad Sharma | `1234567890123` | `VTR-2081-000001` | Kathmandu-1 |
| Sita Devi Thapa | `1234567890124` | `VTR-2081-000002` | Kathmandu-2 |
| Hari Bahadur KC | `1234567890125` | `VTR-2081-000003` | Lalitpur-1 |
| Gita Kumari Adhikari | `1234567890126` | `VTR-2081-000004` | Lalitpur-1 |
| Bikash Raj Poudel | `1234567890127` | `VTR-2081-000005` | Bhaktapur-1 |
| Anita Karmacharya | `1234567890128` | `VTR-2081-000006` | Bhaktapur-1 |
| Prakash Magar | `1234567890129` | `VTR-2081-000007` | Kaski-1 |
| Sunita Gurung | `1234567890130` | `VTR-2081-000008` | Kaski-1 |
| Deepak Rijal | `1234567890131` | `VTR-2081-000009` | Kaski-1 |
| Maya Tamang | `1234567890132` | `VTR-2081-000010` | Kaski-2 |
| Narayan Prasad Tiwari | `1234567890133` | `VTR-2081-000011` | Chitwan-1 |
| Kamala Shrestha | `1234567890134` | `VTR-2081-000012` | Chitwan-1 |
| Suresh Kumar Yadav | `1234567890135` | `VTR-2081-000013` | Janakpur-1 |
| Priya Laxmi Joshi | `1234567890136` | `VTR-2081-000014` | Kathmandu-1 |
| Arun Basnet | `1234567890137` | `VTR-2081-000015` | Kathmandu-3 |

---

## Project Structure

```
ovms/
├── app/
│   ├── controllers/
│   │   ├── admin/          # Admin-side controllers
│   │   ├── auth/           # Voter authentication
│   │   └── voter/          # Voter-side controllers
│   ├── models/             # Business logic
│   └── views/
│       ├── admin/          # Admin templates
│       ├── auth/           # Login pages
│       ├── layouts/        # Shared layouts & partials
│       └── voter/          # Voter templates
├── basedb/
│   ├── schema.sql          # Database structure
│   ├── sampledata.sql      # Test data
│   └── migrations/         # Schema updates
├── config/
│   └── config.php          # Loads settings from .env
├── core/
│   ├── Auth.php            # Session auth guards
│   ├── Controller.php      # Base controller
│   ├── Database.php        # PDO database wrapper
│   ├── Session.php         # Secure session handler
│   ├── ActivityLog.php     # Admin audit trail
│   ├── Env.php             # .env file loader
│   └── Helpers.php         # Utility functions
├── public/
│   └── assets/css/         # Compiled CSS
├── .env.example            # Environment template
├── .htaccess               # Apache routing rules
├── index.php               # Entry point & router
└── setup.sh                # Automated setup script
```

---

## Troubleshooting

### Blank page or 404 on all routes

Apache `mod_rewrite` is not enabled. Run:
```bash
# Linux/Mac
sudo a2enmod rewrite
sudo systemctl restart apache2
```
On XAMPP for Windows, open `xampp/apache/conf/httpd.conf`, find `#LoadModule rewrite_module` and remove the `#`.

---

### "Database connection failed" error

1. Make sure MySQL is running in XAMPP Control Panel
2. Check your `.env` credentials match your MySQL setup
3. Test the connection manually:
```bash
mysql -h 127.0.0.1 -u root voting_system
```

---

### Routing works but pages show errors

Make sure the folder is named exactly `ovms`. If it's named anything else (e.g. `Online-Voting-System-and-Management`), the `BASE_URL` will break.

```bash
# Rename it
mv Online-Voting-System-and-Management ovms
```

---

### CSS not loading

The compiled CSS file is included in the repo at `public/assets/css/style.css` and should load automatically. No build step required.

---

### Session keeps expiring quickly

The default session timeout is 30 minutes. You can change it in `.env`:
```env
SESSION_TIMEOUT=3600
```

---

## Security Notes

- All passwords are hashed with BCrypt (cost 12)
- Accounts lock for 15 minutes after 5 failed login attempts
- Sessions expire after 30 minutes of inactivity
- All votes are anonymous — stored as `SHA256(voter_id + pool_id + secret)`
- All database queries use prepared statements
- Complete admin activity log is maintained

---

## License

ISC License