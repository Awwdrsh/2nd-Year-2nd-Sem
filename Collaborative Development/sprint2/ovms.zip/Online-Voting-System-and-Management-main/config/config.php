<?php
/**
 * Application Configuration
 * Loads from .env file if present, otherwise uses defaults
 */

// Load environment variables from .env
require_once __DIR__ . '/../core/Env.php';
Env::load(__DIR__ . '/../.env');

return [
    // Database configuration
    'db_host'     => Env::get('DB_HOST', '127.0.0.1'),
    'db_port'     => Env::get('DB_PORT', '3306'),
    'db_name'     => Env::get('DB_NAME', 'voting_system'),
    'db_user'     => Env::get('DB_USER', 'root'),
    'db_pass'     => Env::get('DB_PASS', ''),

    // Application
    'base_url'    => Env::get('BASE_URL', ''),
    'asset_url'   => Env::get('ASSET_URL', null),
    'app_env'     => Env::get('APP_ENV', 'development'),
    'app_debug'   => Env::get('APP_DEBUG', 'false') === 'true',

    // Security
    'vote_secret' => Env::get('VOTE_SECRET', 'ovms_secret_key_2083'),
    'session_timeout' => (int) Env::get('SESSION_TIMEOUT', '1800'),

    // Timezone
    'app_timezone' => Env::get('APP_TIMEZONE', 'Asia/Kathmandu'),
];