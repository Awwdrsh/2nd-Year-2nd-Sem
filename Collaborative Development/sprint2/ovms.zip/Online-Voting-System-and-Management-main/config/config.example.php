<?php
/**
 * Database Configuration
 * Copy this file to config.php and fill in your local credentials.
 * config.php is git-ignored — never commit it.
 */
return [
    'db_host' => 'localhost',
    'db_name' => 'voting_system',
    'db_user' => 'root',
    'db_pass' => '',
];
