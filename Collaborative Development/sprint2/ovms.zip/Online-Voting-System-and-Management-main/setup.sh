#!/bin/bash

# ==============================================================================
#  OVMS – Online Voting Management System
#  Complete Setup Script  (v3.2)
#
#  Works on:  Ubuntu / Debian (Apache or Nginx), Azure App Service, XAMPP,
#             any Linux server where PHP + MySQL/MariaDB are installed.
#
#  Usage:   chmod +x setup.sh && sudo ./setup.sh
#           (Must be run from the project root directory)
# ==============================================================================

set -euo pipefail

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "${GREEN}✓${NC} $*"; }
warn() { echo -e "${YELLOW}⚠${NC}  $*"; }
fail() { echo -e "${RED}✗  ERROR:${NC} $*" >&2; exit 1; }
info() { echo -e "${CYAN}→${NC} $*"; }
hr()   { echo -e "${BOLD}──────────────────────────────────────────────────────${NC}"; }

# ── Banner ────────────────────────────────────────────────────────────────────
clear
echo ""
echo -e "${BOLD}${CYAN}"
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║   OVMS – Online Voting Management System Setup  ║"
echo "  ║              Full Installation v3.2             ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""

# ── Sanity: must run from project root ────────────────────────────────────────
[[ -f "index.php" ]] || fail "Run this script from the project root (where index.php lives)."

PROJECT_ROOT="$(pwd)"

# ==============================================================================
# STEP 1 — Detect environment
# ==============================================================================
hr
echo -e "${BOLD}[1/8] Detecting environment…${NC}"

OS="unknown"
WEB_SERVER="unknown"
PHP_BIN=""
MYSQL_BIN=""
WEB_USER=""
WEB_GROUP=""
IS_AZURE=false

# Detect OS
if [[ -f /etc/os-release ]]; then
    . /etc/os-release
    OS="${ID:-unknown}"
fi

# Detect Azure App Service
if [[ -n "${WEBSITE_SITE_NAME:-}" ]] || \
   [[ -n "${APPSETTING_WEBSITE_SITE_NAME:-}" ]] || \
   id "webadmin" &>/dev/null 2>&1; then
    IS_AZURE=true
    ok "Azure App Service environment detected."
fi

# Detect web server
if systemctl is-active --quiet apache2 2>/dev/null; then
    WEB_SERVER="apache2"
elif command -v apache2 &>/dev/null; then
    WEB_SERVER="apache2"
elif systemctl is-active --quiet nginx 2>/dev/null; then
    WEB_SERVER="nginx"
elif command -v nginx &>/dev/null; then
    WEB_SERVER="nginx"
elif command -v httpd &>/dev/null; then
    WEB_SERVER="httpd"
fi

# Web user
for u in webadmin www-data apache nginx nobody; do
    if id -u "$u" &>/dev/null 2>&1; then WEB_USER="$u"; break; fi
done
WEB_GROUP="${WEB_USER:-www-data}"

# PHP binary
for p in php php8.3 php8.2 php8.1 php8.0 php7.4; do
    if command -v "$p" &>/dev/null; then PHP_BIN="$p"; break; fi
done
[[ -n "$PHP_BIN" ]] || fail "PHP not found. Install PHP before running this script."
PHP_VERSION=$($PHP_BIN -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")

# MySQL/MariaDB binary
for m in mysql mariadb; do
    if command -v "$m" &>/dev/null; then MYSQL_BIN="$m"; break; fi
done
[[ -n "$MYSQL_BIN" ]] || fail "mysql/mariadb client not found. Install MySQL or MariaDB."

ok "OS          : ${OS}"
ok "PHP         : ${PHP_BIN} (${PHP_VERSION})"
ok "MySQL client: ${MYSQL_BIN}"
ok "Web server  : ${WEB_SERVER}"
ok "Web user    : ${WEB_USER:-unknown}"
ok "Azure mode  : ${IS_AZURE}"

# ==============================================================================
# STEP 2 — Check required PHP extensions
# ==============================================================================
hr
echo -e "${BOLD}[2/8] Checking PHP extensions…${NC}"

REQUIRED_EXTS=(pdo pdo_mysql mbstring gd json session openssl)
MISSING_EXTS=()
for ext in "${REQUIRED_EXTS[@]}"; do
    if $PHP_BIN -m 2>/dev/null | grep -qi "^${ext}$"; then
        ok "php-${ext}"
    else
        warn "php-${ext} — MISSING"
        MISSING_EXTS+=("$ext")
    fi
done

if [[ ${#MISSING_EXTS[@]} -gt 0 ]]; then
    echo ""
    warn "Missing extensions detected: ${MISSING_EXTS[*]}"
    warn "Please install them manually using your package manager."
fi

# ==============================================================================
# STEP 3 — Composer / PHPMailer
# ==============================================================================
hr
echo -e "${BOLD}[3/8] Composer / PHPMailer…${NC}"

if [[ ! -d "vendor" ]]; then
    if command -v composer &>/dev/null; then
        info "Running composer install…"
        composer install --no-dev --no-interaction --quiet
        ok "Composer dependencies installed."
    else
        warn "Composer not found and vendor/ directory missing."
        warn "PHPMailer (OTP email) will NOT work until you run: composer install"
        warn "Install Composer: https://getcomposer.org/download/"
    fi
else
    ok "vendor/ directory already present — skipping composer install."
fi

# ==============================================================================
# STEP 4 — Collect / detect configuration
# ==============================================================================
hr
echo -e "${BOLD}[4/8] Configuration…${NC}"
echo ""

# ── Load existing .env values as defaults if present ─────────────────────────
_env_get() {
    local key="$1" default="${2:-}"
    if [[ -f ".env" ]]; then
        local val
        val=$(grep -E "^${key}=" .env 2>/dev/null | head -1 | cut -d= -f2- | tr -d '\r')
        echo "${val:-$default}"
    else
        echo "$default"
    fi
}

DEFAULT_DB_HOST=$(_env_get DB_HOST "127.0.0.1")
DEFAULT_DB_PORT=$(_env_get DB_PORT "3306")
DEFAULT_DB_NAME=$(_env_get DB_NAME "voting_system")
DEFAULT_DB_USER=$(_env_get DB_USER "root")
DEFAULT_DB_PASS=$(_env_get DB_PASS "")
DEFAULT_MAIL_HOST=$(_env_get MAIL_HOST "smtp-relay.brevo.com")
DEFAULT_MAIL_PORT=$(_env_get MAIL_PORT "587")
DEFAULT_MAIL_USER=$(_env_get MAIL_USER "")
DEFAULT_MAIL_PASS=$(_env_get MAIL_PASS "")
DEFAULT_MAIL_FROM=$(_env_get MAIL_FROM "votingsystemadmin@gmail.com")
DEFAULT_MAIL_FROM_NAME=$(_env_get MAIL_FROM_NAME "Nepal E-Voting OVMS")
DEFAULT_TZ=$(_env_get APP_TIMEZONE "Asia/Kathmandu")

# ── On Azure, pre-fill DB_HOST from env var if set ───────────────────────────
if [[ "$IS_AZURE" == "true" ]]; then
    info "Azure detected — pre-filling from environment where available."
    [[ -n "${DATABASE_URL:-}" ]] && info "DATABASE_URL detected in environment."
fi

# ── Database ──────────────────────────────────────────────────────────────────
echo -e "${BOLD}Database Settings${NC}"
read -p "  DB Host     [${DEFAULT_DB_HOST}]: "        DB_HOST;  DB_HOST="${DB_HOST:-$DEFAULT_DB_HOST}"
read -p "  DB Port     [${DEFAULT_DB_PORT}]: "        DB_PORT;  DB_PORT="${DB_PORT:-$DEFAULT_DB_PORT}"
read -p "  DB Name     [${DEFAULT_DB_NAME}]: "        DB_NAME;  DB_NAME="${DB_NAME:-$DEFAULT_DB_NAME}"
read -p "  DB User     [${DEFAULT_DB_USER}]: "        DB_USER;  DB_USER="${DB_USER:-$DEFAULT_DB_USER}"
read -sp "  DB Password (blank = keep/none): "        DB_PASS;  echo ""
[[ -z "$DB_PASS" ]] && DB_PASS="$DEFAULT_DB_PASS"

echo ""

# ── BASE_URL ──────────────────────────────────────────────────────────────────
if [[ "$IS_AZURE" == "true" ]]; then
    AUTO_URL="/"
elif [[ "$PROJECT_ROOT" == "/var/www/html" ]] || \
     [[ "$PROJECT_ROOT" == "/var/www/html/" ]]; then
    AUTO_URL=""
else
    FOLDER=$(basename "$PROJECT_ROOT")
    AUTO_URL="/${FOLDER}"
fi

echo -e "${BOLD}Application Settings${NC}"
echo "  Detected BASE_URL: '${AUTO_URL}'"
read -p "  Press Enter to confirm or type a different path: " CUSTOM_URL
[[ -n "$CUSTOM_URL" ]] && AUTO_URL="$CUSTOM_URL"
BASE_URL="$AUTO_URL"

# ── Mail / OTP ────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}Mail / OTP Settings${NC}"
echo "  (Press Enter to keep existing values shown in brackets)"
read -p "  SMTP Host   [${DEFAULT_MAIL_HOST}]: "       MAIL_HOST_IN
MAIL_HOST="${MAIL_HOST_IN:-$DEFAULT_MAIL_HOST}"
read -p "  SMTP Port   [${DEFAULT_MAIL_PORT}]: "       MAIL_PORT_IN
MAIL_PORT="${MAIL_PORT_IN:-$DEFAULT_MAIL_PORT}"
read -p "  SMTP User   [${DEFAULT_MAIL_USER}]: "       MAIL_USER_IN
MAIL_USER="${MAIL_USER_IN:-$DEFAULT_MAIL_USER}"
read -sp "  SMTP Pass   (blank = keep existing): "     MAIL_PASS_IN; echo ""
MAIL_PASS="${MAIL_PASS_IN:-$DEFAULT_MAIL_PASS}"
read -p "  Mail From   [${DEFAULT_MAIL_FROM}]: "       MAIL_FROM_IN
MAIL_FROM="${MAIL_FROM_IN:-$DEFAULT_MAIL_FROM}"
read -p "  From Name   [${DEFAULT_MAIL_FROM_NAME}]: "  MAIL_FROM_NAME_IN
MAIL_FROM_NAME="${MAIL_FROM_NAME_IN:-$DEFAULT_MAIL_FROM_NAME}"

echo ""
read -p "  Timezone    [${DEFAULT_TZ}]: " APP_TZ_IN
APP_TZ="${APP_TZ_IN:-$DEFAULT_TZ}"

# Fixed vote secret (keep stable across re-runs)
EXISTING_SECRET=$(_env_get VOTE_SECRET "")
if [[ -n "$EXISTING_SECRET" ]]; then
    VOTE_SECRET="$EXISTING_SECRET"
else
    VOTE_SECRET="ovms_secret_$(date +%s | sha256sum | head -c 16)"
fi

# ==============================================================================
# STEP 5 — Write .env
# ==============================================================================
hr
echo -e "${BOLD}[5/8] Writing .env…${NC}"

cat > .env << ENVEOF
# Database Configuration
DB_HOST=${DB_HOST}
DB_PORT=${DB_PORT}
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASS=${DB_PASS}

# Application Configuration
BASE_URL=${BASE_URL}
APP_ENV=production
APP_DEBUG=false

# Security
VOTE_SECRET=${VOTE_SECRET}
SESSION_TIMEOUT=1800

# Mail — Brevo SMTP relay (used for OTP delivery)
# MAIL_USER = your Brevo account login email
# MAIL_PASS = your Brevo SMTP key
MAIL_HOST=${MAIL_HOST}
MAIL_PORT=${MAIL_PORT}
MAIL_USER=${MAIL_USER}
MAIL_PASS=${MAIL_PASS}
MAIL_FROM=${MAIL_FROM}
MAIL_FROM_NAME=${MAIL_FROM_NAME}

# Timezone
APP_TIMEZONE=${APP_TZ}
ENVEOF

chmod 640 .env
ok ".env written (permissions: 640)"

# ==============================================================================
# STEP 6 — Database Setup
# ==============================================================================
hr
echo -e "${BOLD}[6/8] Database setup (clean install)…${NC}"

mysql_cmd() {
    if [[ -n "$DB_PASS" ]]; then
        "$MYSQL_BIN" -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASS" "$@"
    else
        "$MYSQL_BIN" -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" "$@"
    fi
}

mysql_cmd -e "SELECT 1;" &>/dev/null || fail "Cannot connect to MySQL. Check your credentials."
ok "MySQL connection verified."

info "Dropping '${DB_NAME}' (if exists) and recreating clean…"
mysql_cmd -e "DROP DATABASE IF EXISTS \`${DB_NAME}\`;"
mysql_cmd -e "CREATE DATABASE \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
ok "Database '${DB_NAME}' created (clean slate)."

# Import schema
if [[ -f "basedb/schema.sql" ]]; then
    info "Importing basedb/schema.sql…"
    mysql_cmd "$DB_NAME" < basedb/schema.sql
    ok "Schema imported from basedb/schema.sql."
elif [[ -f "database/backup.sql" ]]; then
    info "No schema.sql found — importing database/backup.sql as base schema…"
    mysql_cmd "$DB_NAME" < database/backup.sql
    ok "Schema imported from database/backup.sql."
else
    fail "No schema found. Expected basedb/schema.sql or database/backup.sql."
fi

# Run any migration files
if [[ -d "basedb/migrations" ]]; then
    for f in basedb/migrations/*.sql; do
        [[ -f "$f" ]] || continue
        mysql_cmd "$DB_NAME" < "$f" 2>/dev/null \
            && ok "Migration: $(basename "$f")" \
            || warn "Migration skipped (already applied): $(basename "$f")"
    done
fi

# ==============================================================================
# STEP 7 — Insert Demo Seed Data
# ==============================================================================
hr
echo -e "${BOLD}[7/8] Inserting seed data…${NC}"

HASH_PASSWORD='$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'

mysql_cmd "$DB_NAME" << SQLEOF

SET FOREIGN_KEY_CHECKS = 0;

-- ── Truncate all tables ───────────────────────────────────────────────────────
TRUNCATE TABLE votes;
TRUNCATE TABLE pool_candidates;
TRUNCATE TABLE pools;
TRUNCATE TABLE elections;
TRUNCATE TABLE candidates;
TRUNCATE TABLE users;
TRUNCATE TABLE admins;
TRUNCATE TABLE parties;
TRUNCATE TABLE constituencies;
TRUNCATE TABLE citizens;
TRUNCATE TABLE admin_activity_log;

-- ── Citizens ──────────────────────────────────────────────────────────────────
INSERT INTO citizens (nid, full_name, date_of_birth, photo_url, citizenship_no, district, municipality, ward_no, tole) VALUES
('1234567890123', 'Ram Prasad Sharma',      '1985-04-12', NULL, 'KTM-12345', 'Kathmandu', 'Kathmandu Metropolitan', 3,  'Baneshwor'),
('1234567890124', 'Sita Devi Thapa',        '1990-07-23', NULL, 'KTM-12346', 'Kathmandu', 'Kathmandu Metropolitan', 5,  'Koteshwor'),
('1234567890125', 'Hari Bahadur KC',        '1978-01-05', NULL, 'LTP-23456', 'Lalitpur',  'Lalitpur Metropolitan',  2,  'Pulchowk'),
('1234567890126', 'Gita Kumari Adhikari',   '1992-11-30', NULL, 'LTP-23457', 'Lalitpur',  'Lalitpur Metropolitan',  4,  'Jawalakhel'),
('1234567890127', 'Bikash Raj Poudel',      '1983-06-15', NULL, 'BKT-34567', 'Bhaktapur', 'Bhaktapur Municipality', 1,  'Suryabinayak'),
('1234567890128', 'Anita Karmacharya',      '1995-03-08', NULL, 'BKT-34568', 'Bhaktapur', 'Madhyapur Thimi',        6,  'Thimi'),
('1234567890129', 'Prakash Magar',          '1975-09-20', NULL, 'PKR-45678', 'Kaski',     'Pokhara Metropolitan',   7,  'Lakeside'),
('1234567890130', 'Sunita Gurung',          '1988-12-01', NULL, 'PKR-45679', 'Kaski',     'Pokhara Metropolitan',   8,  'Bagar'),
('1234567890131', 'Deepak Rijal',           '1970-02-14', NULL, 'PKR-45680', 'Kaski',     'Pokhara Metropolitan',   9,  'Chipledhunga'),
('1234567890132', 'Maya Tamang',            '1993-08-25', NULL, 'PKR-45681', 'Kaski',     'Pokhara Metropolitan',   10, 'Prithvichowk'),
('1234567890133', 'Narayan Prasad Tiwari',  '1965-05-30', NULL, 'CHI-56789', 'Chitwan',   'Bharatpur Metropolitan', 1,  'Bharatpur-10'),
('1234567890134', 'Kamala Shrestha',        '1987-10-17', NULL, 'CHI-56790', 'Chitwan',   'Bharatpur Metropolitan', 3,  'Narayangadh'),
('1234567890135', 'Suresh Kumar Yadav',     '1980-03-22', NULL, 'JNK-67890', 'Janakpur',  'Janakpurdham Sub-Metro', 2,  'Ramanand Chowk'),
('1234567890136', 'Priya Laxmi Joshi',      '1997-06-11', NULL, 'KTM-12348', 'Kathmandu', 'Kirtipur Municipality',  1,  'Kirtipur'),
('1234567890137', 'Arun Basnet',            '1972-11-03', NULL, 'KTM-12349', 'Kathmandu', 'Kathmandu Metropolitan', 15, 'Chabahil');

-- ── Constituencies ────────────────────────────────────────────────────────────
INSERT INTO constituencies (name, district, province, type) VALUES
('Kathmandu-1',     'Kathmandu', 'Bagmati',  'fptp'),
('Kathmandu-2',     'Kathmandu', 'Bagmati',  'fptp'),
('Kathmandu-3',     'Kathmandu', 'Bagmati',  'fptp'),
('Lalitpur-1',      'Lalitpur',  'Bagmati',  'fptp'),
('Lalitpur-2',      'Lalitpur',  'Bagmati',  'fptp'),
('Bhaktapur-1',     'Bhaktapur', 'Bagmati',  'fptp'),
('Kaski-1',         'Kaski',     'Gandaki',  'fptp'),
('Kaski-2',         'Kaski',     'Gandaki',  'fptp'),
('Chitwan-1',       'Chitwan',   'Bagmati',  'fptp'),
('Janakpur-1',      'Janakpur',  'Madhesh',  'fptp'),
('Bagmati PR List', 'Bagmati',   'Bagmati',  'pr'),
('Gandaki PR List', 'Gandaki',   'Gandaki',  'pr');

-- ── Parties ───────────────────────────────────────────────────────────────────
INSERT INTO parties (name, abbreviation, symbol_url, is_active) VALUES
('Nepal Communist Party (UML)', 'CPN-UML', NULL, TRUE),
('Nepali Congress',             'NC',      NULL, TRUE),
('CPN (Maoist Centre)',         'Maoist',  NULL, TRUE),
('Rastriya Swatantra Party',    'RSP',     NULL, TRUE),
('Rastriya Prajatantra Party',  'RPP',     NULL, TRUE),
('Janajati Party Nepal',        'JPN',     NULL, TRUE);

-- ── Admins ────────────────────────────────────────────────────────────────────
INSERT INTO admins (full_name, email, role, password, updated_at) VALUES
('System Administrator',   'votingsystemadmin@gmail.com', 'Admin',   '${HASH_PASSWORD}', NULL),
('Election Officer Raju',  'officer.raju@ovms.gov.np',    'Officer', '${HASH_PASSWORD}', NULL),
('System Officer Sunita',  'officer.sunita@ovms.gov.np',  'Officer', '${HASH_PASSWORD}', NULL);

-- ── Users / Voters ────────────────────────────────────────────────────────────
INSERT INTO users (nid, voter_id, constituency_id, is_candidate, created_at) VALUES
('1234567890123', 'VTR-2081-000001', 1,  FALSE, NOW()),
('1234567890124', 'VTR-2081-000002', 2,  FALSE, NOW()),
('1234567890125', 'VTR-2081-000003', 4,  FALSE, NOW()),
('1234567890126', 'VTR-2081-000004', 4,  FALSE, NOW()),
('1234567890127', 'VTR-2081-000005', 6,  FALSE, NOW()),
('1234567890128', 'VTR-2081-000006', 6,  FALSE, NOW()),
('1234567890129', 'VTR-2081-000007', 7,  TRUE,  NOW()),
('1234567890130', 'VTR-2081-000008', 7,  FALSE, NOW()),
('1234567890131', 'VTR-2081-000009', 7,  TRUE,  NOW()),
('1234567890132', 'VTR-2081-000010', 8,  FALSE, NOW()),
('1234567890133', 'VTR-2081-000011', 9,  TRUE,  NOW()),
('1234567890134', 'VTR-2081-000012', 9,  FALSE, NOW()),
('1234567890135', 'VTR-2081-000013', 10, TRUE,  NOW()),
('1234567890136', 'VTR-2081-000014', 1,  FALSE, NOW()),
('1234567890137', 'VTR-2081-000015', 3,  TRUE,  NOW());

-- ── Candidates ────────────────────────────────────────────────────────────────
INSERT INTO candidates (user_id, party_id, constituency_id, election_type, ballot_number, manifesto, nomination_status, updated_at) VALUES
(7,  1, 7,  'both', 1, 'Road infrastructure, clean water supply, and youth employment in Kaski district.',        'approved', NULL),
(9,  2, 7,  'fptp', 2, 'Education and healthcare are the pillars of development. Three new health posts.',        'approved', NULL),
(11, 3, 9,  'fptp', 1, 'Chitwan flood control, farmer subsidies, and improving the Bharatpur-Kathmandu highway.', 'approved', NULL),
(13, 1, 10, 'pr',   1, 'Madhesh proportional representation and equal rights under federalism.',                  'approved', NULL),
(15, 4, 3,  'fptp', 1, 'Anti-corruption, digital governance, and startup ecosystem for the new generation.',      'approved', NULL);

-- ── Elections ─────────────────────────────────────────────────────────────────
INSERT INTO elections (title, status, voting_start, voting_end, created_by) VALUES
('House of Representatives Election 2081', 'active',   '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
('Provincial Assembly Election 2081',      'upcoming', '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
('Local By-Election 2081',                 'draft',    '2081-12-15 07:00:00', '2081-12-15 17:00:00', 2);

-- ── Pools ─────────────────────────────────────────────────────────────────────
INSERT INTO pools (election_id, constituency_id, title, pool_type, election_type, status, description, voting_start, voting_end, created_by) VALUES
(1, 7,  'Kaski-1 FPTP',            'fptp', 'national', 'active',   'House of Representatives — Kaski Constituency 1',           '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(1, 9,  'Chitwan-1 FPTP',          'fptp', 'national', 'active',   'House of Representatives — Chitwan Constituency 1',         '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(1, 10, 'Janakpur-1 FPTP',         'fptp', 'national', 'active',   'House of Representatives — Janakpur Constituency 1',        '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(1, 3,  'Kathmandu-3 FPTP',        'fptp', 'national', 'active',   'House of Representatives — Kathmandu Constituency 3',       '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(2, 11, 'Bagmati Province PR',     'pr',   'national', 'upcoming', 'Provincial Assembly — Bagmati Proportional Representation',  '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(2, 12, 'Gandaki Province PR',     'pr',   'national', 'upcoming', 'Provincial Assembly — Gandaki Proportional Representation',  '2081-11-04 07:00:00', '2081-11-04 17:00:00', 1),
(3, 1,  'Kathmandu-1 By-Election', 'fptp', 'local',    'upcoming', 'By-election for vacant seat in Kathmandu-1',                '2081-12-15 07:00:00', '2081-12-15 17:00:00', 2);

-- ── Pool Candidates ───────────────────────────────────────────────────────────
INSERT INTO pool_candidates (pool_id, candidate_id, ballot_order) VALUES
(1, 1, 1),
(1, 2, 2),
(2, 3, 1),
(3, 4, 1),
(4, 5, 1);

-- ── Sample Votes ──────────────────────────────────────────────────────────────
INSERT INTO votes (pool_id, pool_candidate_id, voter_hash, receipt_code, ip_address) VALUES
(1, 1, SHA2(CONCAT('1',  '1', '${VOTE_SECRET}'), 256), 'RCP-2081-000001', '192.168.1.10'),
(1, 2, SHA2(CONCAT('8',  '1', '${VOTE_SECRET}'), 256), 'RCP-2081-000002', '192.168.1.11'),
(2, 3, SHA2(CONCAT('12', '2', '${VOTE_SECRET}'), 256), 'RCP-2081-000003', '192.168.1.12'),
(3, 4, SHA2(CONCAT('13', '3', '${VOTE_SECRET}'), 256), 'RCP-2081-000004', '192.168.1.13'),
(4, 5, SHA2(CONCAT('15', '4', '${VOTE_SECRET}'), 256), 'RCP-2081-000005', '192.168.1.14');

SET FOREIGN_KEY_CHECKS = 1;
SQLEOF

ok "Seed data inserted (15 citizens, 15 voters, 3 admins, 3 elections, 7 pools, 5 candidates, 5 sample votes)."

# ==============================================================================
# STEP 8 — Voter Passwords
# ==============================================================================
hr
echo -e "${BOLD}[8/8] Hashing voter passwords via PHP…${NC}"

cat > .temp_hash.php << 'PHPEOF'
<?php
define('BASE_PATH', getcwd());

// Load Env — support both class-based and direct dotenv parsing
if (file_exists(BASE_PATH . '/core/Env.php')) {
    require_once BASE_PATH . '/core/Env.php';
    Env::load(BASE_PATH . '/.env');
} else {
    // Fallback: parse .env manually
    $lines = file(BASE_PATH . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') === false) continue;
        [$key, $val] = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($val);
        putenv(trim($key) . '=' . trim($val));
    }
}

// Load Database — support both class-based and raw PDO
if (file_exists(BASE_PATH . '/core/Database.php')) {
    require_once BASE_PATH . '/core/Database.php';
    try {
        $db      = Database::getInstance();
        $users   = $db->query("SELECT id, nid FROM users")->fetchAll(PDO::FETCH_ASSOC);
        $updated = 0;
        foreach ($users as $u) {
            $plain = 'pwd' . $u['nid'];
            $hash  = password_hash($plain, PASSWORD_BCRYPT, ['cost' => 10]);
            $db->query("UPDATE users SET password = ? WHERE id = ?", [$hash, $u['id']]);
            $updated++;
        }
        echo "  → Passwords set for {$updated} voters (format: pwd + NID).\n";
    } catch (Exception $e) {
        echo "  ERROR: " . $e->getMessage() . "\n";
        exit(1);
    }
} else {
    // Fallback: raw PDO
    $host = $_ENV['DB_HOST'] ?? '127.0.0.1';
    $port = $_ENV['DB_PORT'] ?? '3306';
    $name = $_ENV['DB_NAME'] ?? 'voting_system';
    $user = $_ENV['DB_USER'] ?? 'root';
    $pass = $_ENV['DB_PASS'] ?? '';
    try {
        $pdo   = new PDO("mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4", $user, $pass);
        $users = $pdo->query("SELECT id, nid FROM users")->fetchAll(PDO::FETCH_ASSOC);
        $updated = 0;
        foreach ($users as $u) {
            $plain = 'pwd' . $u['nid'];
            $hash  = password_hash($plain, PASSWORD_BCRYPT, ['cost' => 10]);
            $stmt  = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hash, $u['id']]);
            $updated++;
        }
        echo "  → Passwords set for {$updated} voters (format: pwd + NID).\n";
    } catch (Exception $e) {
        echo "  ERROR: " . $e->getMessage() . "\n";
        exit(1);
    }
}
PHPEOF

$PHP_BIN .temp_hash.php
rm .temp_hash.php

ok "All voter passwords hashed."

# ==============================================================================
# STEP 9 — Finalizing
# ==============================================================================
hr
echo -e "${BOLD}Finalizing…${NC}"

chmod 640 .env
ok "File permissions for .env set."

# ==============================================================================
# DONE — Full credential summary
# ==============================================================================
hr
echo ""
echo -e "${BOLD}${GREEN}"
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║              OVMS Setup Complete!  v3.2                ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

if [[ -n "$BASE_URL" && "$BASE_URL" != "/" ]]; then
    APP_BASE="http://your-server${BASE_URL}"
else
    APP_BASE="http://your-server"
fi

echo -e "  ${BOLD}App URL:${NC}  ${APP_BASE}"
echo ""

echo -e "  ${BOLD}Admin Accounts (all use password: password)${NC}"
echo "  ┌────────────┬────────────────────────────────┬──────────────────────┐"
echo "  │  Role      │ Email                          │ Password             │"
echo "  ├────────────┼────────────────────────────────┼──────────────────────┤"
echo "  │  Admin     │ votingsystemadmin@gmail.com    │ password             │"
echo "  │  Officer   │ officer.raju@ovms.gov.np       │ password             │"
echo "  │  Officer   │ officer.sunita@ovms.gov.np     │ password             │"
echo "  └────────────┴────────────────────────────────┴──────────────────────┘"
echo ""
echo "  Admin login URL: ${APP_BASE}?route=admin/login"
echo ""

echo -e "  ${BOLD}Voter Accounts  (password = pwd + NID)${NC}"
echo "  ┌─────┬───────────────────┬──────────────────┬──────────────────────────┐"
echo "  │  #  │ NID               │ Voter ID         │ Password                 │"
echo "  ├─────┼───────────────────┼──────────────────┼──────────────────────────┤"
echo "  │  1  │ 1234567890123     │ VTR-2081-000001  │ pwd1234567890123         │"
echo "  │  2  │ 1234567890124     │ VTR-2081-000002  │ pwd1234567890124         │"
echo "  │  3  │ 1234567890125     │ VTR-2081-000003  │ pwd1234567890125         │"
echo "  │  4  │ 1234567890126     │ VTR-2081-000004  │ pwd1234567890126         │"
echo "  │  5  │ 1234567890127     │ VTR-2081-000005  │ pwd1234567890127         │"
echo "  │  6  │ 1234567890128     │ VTR-2081-000006  │ pwd1234567890128         │"
echo "  │  7  │ 1234567890129     │ VTR-2081-000007  │ pwd1234567890129 (cand.) │"
echo "  │  8  │ 1234567890130     │ VTR-2081-000008  │ pwd1234567890130         │"
echo "  │  9  │ 1234567890131     │ VTR-2081-000009  │ pwd1234567890131 (cand.) │"
echo "  │ 10  │ 1234567890132     │ VTR-2081-000010  │ pwd1234567890132         │"
echo "  │ 11  │ 1234567890133     │ VTR-2081-000011  │ pwd1234567890133 (cand.) │"
echo "  │ 12  │ 1234567890134     │ VTR-2081-000012  │ pwd1234567890134         │"
echo "  │ 13  │ 1234567890135     │ VTR-2081-000013  │ pwd1234567890135 (cand.) │"
echo "  │ 14  │ 1234567890136     │ VTR-2081-000014  │ pwd1234567890136         │"
echo "  │ 15  │ 1234567890137     │ VTR-2081-000015  │ pwd1234567890137 (cand.) │"
echo "  └─────┴───────────────────┴──────────────────┴──────────────────────────┘"
echo ""
echo "  Voter login URL: ${APP_BASE}?route=voter/login"
echo ""

echo -e "  ${BOLD}${YELLOW}Post-setup security checklist:${NC}"
echo "  ① Change ALL admin passwords immediately after first login."
echo "  ② DELETE these debug/utility files from the server:"
echo "       debug_db.php          check_env.php         check_html.php"
echo "       reset_credentials.php  test_otp_send.php"
echo "  ③ Verify MAIL_USER and MAIL_PASS in .env for OTP email delivery."
echo "  ④ APP_ENV=production and APP_DEBUG=false are already set in .env."
echo "  ⑤ The .env file is protected (chmod 640) and blocked from web access."
echo ""
hr