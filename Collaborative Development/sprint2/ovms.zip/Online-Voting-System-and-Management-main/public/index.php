<?php

define('BASE_PATH', dirname(__DIR__));

// Check for required extensions
$requiredExtensions = ['pdo_mysql', 'gd', 'session'];
$missing = [];
foreach ($requiredExtensions as $ext) {
    if (!extension_loaded($ext)) {
        $missing[] = $ext;
    }
}
if (!empty($missing)) {
    http_response_code(500);
    die("<div style='font-family:sans-serif;padding:40px;color:#721c24;background:#f8d7da;border:1px solid #f5c6cb;border-radius:8px;margin:20px'>
        <h2 style='margin-top:0'>Missing PHP Extensions</h2>
        <p>The following required extensions are not installed on this server: <strong>" . implode(', ', $missing) . "</strong></p>
        <p>To fix this on Ubuntu, run: <code>sudo apt update && sudo apt install php-" . implode(' php-', $missing) . " && sudo systemctl restart apache2</code></p>
    </div>");
}

$config = require BASE_PATH . '/config/config.php';

$baseUrl = $config['base_url'] ?? '';

// Normalize: treat "/" the same as "" (both mean "root, no subfolder")
if ($baseUrl === '/') {
    $baseUrl = '';
}

// Auto-detect if still empty (supports root and subfolder hosting)
if ($baseUrl === '') {
    $scriptName = $_SERVER['SCRIPT_NAME']; // e.g. /ovms/public/index.php
    $scriptDir = str_replace('\\', '/', dirname($scriptName));
    
    // If we are in public/ directory, we want the parent directory as base
    if (basename($scriptDir) === 'public') {
        $baseUrl = str_replace('\\', '/', dirname($scriptDir));
    } else {
        $baseUrl = $scriptDir;
    }
    
    if ($baseUrl === '/') {
        $baseUrl = '';
    }
}

// Ensure starts with / but never ends with /
$baseUrl = rtrim($baseUrl, '/');
if ($baseUrl !== '' && $baseUrl[0] !== '/') {
    $baseUrl = '/' . $baseUrl;
}

define('BASE_URL', $baseUrl);
define('ASSET_URL', !empty($config['asset_url']) ? $config['asset_url'] : BASE_URL);
define('VOTE_SECRET', $config['vote_secret'] ?? 'ovms_secret_key_2083');

/**
 * Asset Helper
 * Ensures clean paths for assets regardless of BASE_URL (prevents double slashes)
 */
function asset(string $path): string {
    return rtrim(ASSET_URL, '/') . '/' . ltrim($path, '/');
}

// Set Timezone
date_default_timezone_set($config['app_timezone'] ?? 'Asia/Kathmandu');

// Core
require_once BASE_PATH . '/core/Env.php';
require_once BASE_PATH . '/core/Database.php';
require_once BASE_PATH . '/core/Controller.php';
require_once BASE_PATH . '/core/ActivityLog.php';
require_once BASE_PATH . '/core/Session.php';
require_once BASE_PATH . '/core/Auth.php';
require_once BASE_PATH . '/core/Helpers.php';

// PHPMailer autoloader — installed via `composer require phpmailer/phpmailer`
if (file_exists(BASE_PATH . '/vendor/autoload.php')) {
    require_once BASE_PATH . '/vendor/autoload.php';
}

// Shared OTP service — procedural functions used by admin and voter auth flows
require_once BASE_PATH . '/core/OtpService.php';

// Initialize Secure Session
try {
    Session::start();
} catch (Exception $e) {
    die("Session Error: " . $e->getMessage());
}

try {

// Autoload controllers recursively
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(BASE_PATH . '/app/controllers/'));
foreach ($iterator as $file) {
    if ($file->getExtension() === 'php') {
        require_once $file->getPathname();
    }
}

// Autoload models
if (is_dir(BASE_PATH . '/app/models/')) {
    $modelIterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(BASE_PATH . '/app/models/'));
    foreach ($modelIterator as $file) {
        if ($file->getExtension() === 'php') {
            require_once $file->getPathname();
        }
    }
}

// Parse URI
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = rtrim($uri, '/');

// Normalize URI by removing the BASE_URL prefix
if (BASE_URL !== '' && strpos($uri, BASE_URL) === 0) {
    $uri = substr($uri, strlen(BASE_URL));
}

// Extra safety: if URI still starts with /public/ (e.g. rewrite issues)
if (strpos($uri, '/public') === 0) {
    $uri = substr($uri, 7);
}

// Strip /index.php if it was explicitly included in the URL path
if (strpos($uri, '/index.php') === 0) {
    $uri = substr($uri, 10);
}

if ($uri === '' || $uri === '/index.php') {
    $uri = '/';
}

$uri = $uri ?: '/';

// Route table  [uri => [ControllerClass, method]]
$routes = [

    // Auth — login, OTP two-factor, and logout
    '/admin/login'                  => ['AuthController',             'showLogin'],
    '/admin/login/submit'           => ['AuthController',             'handleLogin'],
    '/admin/captcha'                => ['AuthController',             'captcha'],
    '/admin/logout'                 => ['AuthController',             'logout'],
    '/admin/otp/request'            => ['AuthController',             'showOtpRequest'],
    '/admin/otp/request/submit'     => ['AuthController',             'sendOtpToEmail'],
    '/admin/otp'                    => ['AuthController',             'showOtp'],
    '/admin/otp/verify'             => ['AuthController',             'verifyOtp'],
    '/admin/otp/resend'             => ['AuthController',             'resendOtp'],

    // Voter auth
    '/voter/login'                  => ['VoterAuthController',        'showVoterLogin'],
    '/voter/login/submit'           => ['VoterAuthController',        'voterLogin'],
    '/voter/logout'                 => ['VoterAuthController',        'voterLogout'],

    // Voter dashboard
    '/voter/dashboard'              => ['VoterDashboardController',   'index'],
    '/voter/profile'                => ['VoterProfileController',     'index'],
    '/voter/profile/update'         => ['VoterProfileController',     'update'],

    // Vote actions
    '/vote/verify'                  => ['VoteController',             'verify'],
    '/vote/cast'                    => ['VoteController',             'cast'],
    '/voter/vote/verify'            => ['VoteController',             'verify'],
    '/voter/vote/cast'              => ['VoteController',             'cast'],

    // Ballot voting
    '/ballot'                       => ['BallotController',           'index'],
    '/ballot/submit'                => ['BallotController',           'submit'],
    '/voter/ballot'                 => ['BallotController',           'index'],
    '/voter/ballot/submit'          => ['BallotController',           'submit'],

    // Results
    '/results'                      => ['ResultsController',          'index'],
    '/voter/results'                => ['ResultsController',          'index'],

    // Admin routes
    '/'                             => ['AdminController',            'dashboard'],
    '/admin'                        => ['AdminController',            'dashboard'],
    '/admin/dashboard'              => ['AdminController',            'dashboard'],
    '/admin/stats-api'              => ['AdminController',            'statsApi'],

    // Audit log
    '/admin/activity-log'           => ['AdminActivityLogController', 'index'],

    // Profile Management
    '/admin/profile'                => ['ProfileController',          'index'],
    '/admin/profile/update'         => ['ProfileController',          'update'],
    '/admin/profile/password'       => ['ProfileController',          'changePassword'],

    // Elections
    '/admin/elections'              => ['ElectionController',         'index'],
    '/admin/elections/create'       => ['ElectionController',         'create'],
    '/admin/elections/store'        => ['ElectionController',         'store'],
    '/admin/elections/edit'         => ['ElectionController',         'edit'],
    '/admin/elections/update'       => ['ElectionController',         'update'],
    '/admin/elections/delete'       => ['ElectionController',         'delete'],

    // Officers
    '/admin/officers'               => ['OfficerController',          'index'],
    '/admin/officers/create'        => ['OfficerController',          'create'],
    '/admin/officers/store'         => ['OfficerController',          'store'],
    '/admin/officers/edit'          => ['OfficerController',          'edit'],
    '/admin/officers/update'        => ['OfficerController',          'update'],
    '/admin/officers/delete'        => ['OfficerController',          'delete'],

    // Candidates
    '/admin/candidates'             => ['CandidateController',        'index'],
    '/admin/candidates/create'      => ['CandidateController',        'create'],
    '/admin/candidates/store'       => ['CandidateController',        'store'],
    '/admin/candidates/edit'        => ['CandidateController',        'edit'],
    '/admin/candidates/update'      => ['CandidateController',        'update'],
    '/admin/candidates/approve'     => ['CandidateController',        'approve'],
    '/admin/candidates/reject'      => ['CandidateController',        'reject'],
    '/admin/candidates/delete'      => ['CandidateController',        'delete'],
    '/admin/candidates/search-voter' => ['CandidateController',       'searchVoter'],

    // Voters
    '/admin/voters'                 => ['VoterController',            'index'],
    '/admin/voters/show'            => ['VoterController',            'show'],
    '/admin/voters/block'           => ['VoterController',            'block'],
    '/admin/voters/unblock'         => ['VoterController',            'unblock'],
    '/admin/voters/reset-password'  => ['VoterController',            'resetPassword'],
    '/admin/voters/delete'          => ['VoterController',            'delete'],
    '/admin/voters/activity'        => ['VoterController',            'activity'],

    // Parties
    '/admin/parties'                => ['PartyController',            'index'],
    '/admin/parties/create'         => ['PartyController',            'create'],
    '/admin/parties/store'          => ['PartyController',            'store'],
    '/admin/parties/edit'           => ['PartyController',            'edit'],
    '/admin/parties/update'         => ['PartyController',            'update'],
    '/admin/parties/delete'         => ['PartyController',            'delete'],

    // Pools
    '/admin/pools'                                  => ['PoolController',             'index'],
    '/admin/pools/create'                           => ['PoolController',             'create'],
    '/admin/pools/store'                            => ['PoolController',             'store'],
    '/admin/pools/edit'                             => ['PoolController',             'edit'],
    '/admin/pools/update'                           => ['PoolController',             'update'],
    '/admin/pools/delete'                           => ['PoolController',             'delete'],
    '/admin/pools/bulk-action'                      => ['PoolController',             'bulkAction'],
    '/admin/pools/auto-assign'                      => ['PoolController',             'bulkAssignCandidates'],
    '/admin/pools/candidates/add'                   => ['PoolController',             'addCandidate'],
    '/admin/pools/candidates/remove'                => ['PoolController',             'removeCandidate'],
    '/admin/pools/candidates/by-constituency'       => ['PoolController',             'getCandidatesByConstituency'],
    
    // Reports, Settings, Security
    '/admin/reports'                => ['ReportController',           'index'],
    '/admin/reports/export'         => ['ReportController',           'export'],
    '/admin/security'               => ['SecurityController',         'index'],
    '/admin/settings'               => ['SettingController',          'index'],
];

// --- Legacy Redirects (to be removed in future versions) ---
$legacyRedirects = [
    '/login'   => '/admin/login',
    '/logout'  => '/admin/logout',
    '/captcha' => '/admin/captcha'
];
if (isset($legacyRedirects[$uri])) {
    $queryString = !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '';
    header('Location: ' . BASE_URL . $legacyRedirects[$uri] . $queryString);
    exit;
}

    if (isset($routes[$uri])) {
        [$controllerClass, $method] = $routes[$uri];
        $controller = new $controllerClass();
        $controller->$method();
    } elseif (preg_match('#^/admin/pools/(\d+)/candidates$#', $uri, $m)) {
        $_GET['id'] = $m[1];
        $controller = new PoolController();
        $controller->candidates();
    } else {
        http_response_code(404);
        echo '<h2 style="font-family:sans-serif;padding:40px">404 — Page not found</h2>';
        echo '<p style="font-family:sans-serif;padding:0 40px">No route matched: <code>' . htmlspecialchars($uri) . '</code></p>';
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo '<div style="font-family:sans-serif;padding:40px;background:#fff5f5;border:1px solid #feb2b2;margin:20px;border-radius:8px">';
    echo '<h2 style="color:#c53030;margin-top:0">Database Connection Error</h2>';
    echo '<p>The application could not connect to the database. Please check your <code>.env</code> file.</p>';
    echo '<p style="font-size:0.85rem;color:#742a2a"><strong>Error details:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '</div>';
} catch (Exception $e) {
    http_response_code(500);
    echo '<div style="font-family:sans-serif;padding:40px;background:#fefcbf;border:1px solid #faf089;margin:20px;border-radius:8px">';
    echo '<h2 style="color:#744210;margin-top:0">Application Error</h2>';
    echo '<p>Something went wrong while processing your request.</p>';
    echo '<p style="font-size:0.85rem;color:#744210"><strong>Error details:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '</div>';
}