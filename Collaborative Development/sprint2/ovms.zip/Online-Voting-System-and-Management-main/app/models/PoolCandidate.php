<?php
/**
 * PoolCandidate Model
 * Handles all database operations for this table.
 * TODO: Implement methods as needed.
 */
class PoolCandidate {

    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // TODO: Add your query methods here.
    // Examples:
    // public function findById(int $id): ?array { ... }
    // public function all(): array { ... }
    // public function create(array $data): bool { ... }
    // public function update(int $id, array $data): bool { ... }
    // public function delete(int $id): bool { ... }
}
