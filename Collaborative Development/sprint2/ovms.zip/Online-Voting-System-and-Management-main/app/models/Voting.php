<?php

class Voting {

    private static $db = null;

    public static function getInstance() {
        if (!self::$db) {
            self::$db = Database::getInstance();
        }
        return self::$db;
    }

    public static function getActivePools($userId, $constituencyId, $province = '', $district = '') {
        $db = self::getInstance();
        $secret = VOTE_SECRET;

        // This query finds:
        // 1. Pools directly matching the voter's constituency (FPTP)
        // 2. PR Pools matching the voter's Province
        // 3. PR Pools matching the voter's District (for local elections)
        $sql = "
            SELECT p.id, p.title, p.pool_type, p.voting_end, p.election_id, p.constituency_id,
                   (SELECT COUNT(*) FROM votes v WHERE v.pool_id = p.id AND v.voter_hash = SHA2(CONCAT(?, p.id, ?), 256)) > 0 AS has_voted
            FROM pools p
            JOIN constituencies c ON p.constituency_id = c.id
            WHERE 
                (p.status = 'active' OR (p.status = 'upcoming' AND p.voting_start <= NOW()))
                AND p.status != 'closed'
                AND p.voting_end > NOW()
                AND (
                    p.constituency_id = ? 
                    OR (p.pool_type = 'pr' AND c.province = ? AND p.election_type IN ('national', 'by_election'))
                    OR (p.pool_type = 'pr' AND c.district = ? AND p.election_type = 'local')
                )
            ORDER BY p.id ASC
        ";

        $stmt = $db->prepare($sql);
        $stmt->execute([$userId, $secret, $constituencyId, $province, $district]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getPoolById($poolId, $constituencyId, $province = '', $district = '') {
        $db = self::getInstance();
        $sql = "
            SELECT p.* FROM pools p
            JOIN constituencies c ON p.constituency_id = c.id
            WHERE p.id = ?
              AND (p.status = 'active' OR (p.status = 'upcoming' AND p.voting_start <= NOW()))
              AND p.status != 'closed'
              AND p.voting_end > NOW()
              AND (
                  p.constituency_id = ? 
                  OR (p.pool_type = 'pr' AND c.province = ? AND p.election_type IN ('national', 'by_election'))
                  OR (p.pool_type = 'pr' AND c.district = ? AND p.election_type = 'local')
              )
            LIMIT 1
        ";
        $stmt = $db->prepare($sql);
        $stmt->execute([$poolId, $constituencyId, $province, $district]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function getCandidatesForPool($poolId) {
        $db = self::getInstance();
        $stmt = $db->prepare(
            "SELECT pc.id AS pool_candidate_id, pc.ballot_order,
                    c.id AS candidate_id, c.photo_path, c.manifesto,
                    u.id AS user_id, ci.full_name AS candidate_name,
                    p.id AS party_id, p.name AS party_name, p.abbreviation, p.symbol_url
             FROM pool_candidates pc
             JOIN pools po ON pc.pool_id = po.id
             JOIN candidates c ON pc.candidate_id = c.id
             JOIN users u ON c.user_id = u.id
             JOIN citizens ci ON u.nid = ci.nid
             LEFT JOIN parties p ON c.party_id = p.id
             WHERE pc.pool_id = ? 
               AND c.is_active = 1
               AND (c.election_type = po.pool_type OR c.election_type = 'both')
             ORDER BY pc.ballot_order"
        );
        $stmt->execute([$poolId]);
        return $stmt->fetchAll();
    }

    public static function getPartiesForPool($poolId) {
        $db = self::getInstance();
        $stmt = $db->prepare(
            "SELECT pp.id AS pool_party_id, pp.ballot_order,
                    p.id AS party_id, p.name AS party_name, p.abbreviation, p.symbol_url
             FROM pool_parties pp
             JOIN parties p ON pp.party_id = p.id
             WHERE pp.pool_id = ?
             ORDER BY pp.ballot_order"
        );
        $stmt->execute([$poolId]);
        return $stmt->fetchAll();
    }

    public static function castVote($userId, $poolId, $poolCandidateId = null, $partyId = null) {
        $db = self::getInstance();
        $voterHash = hash('sha256', $userId . $poolId . VOTE_SECRET);
        $receiptCode = strtoupper(bin2hex(random_bytes(8)));

        try {
            $stmt = $db->prepare(
                "INSERT INTO votes (pool_id, pool_candidate_id, party_id, voter_hash, receipt_code, ip_address)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([
                $poolId,
                $poolCandidateId ?: null,
                $partyId ?: null,
                $voterHash,
                $receiptCode,
                $_SERVER['REMOTE_ADDR'] ?? null
            ]);
            return ['success' => true, 'receipt' => $receiptCode];
        } catch (Exception $e) {
            return ['success' => false, 'error' => 'already_voted'];
        }
    }

    public static function hasUserVotedInPool($userId, $poolId) {
        $db = self::getInstance();
        $voterHash = hash('sha256', $userId . $poolId . VOTE_SECRET);
        $stmt = $db->prepare("SELECT id FROM votes WHERE pool_id = ? AND voter_hash = ?");
        $stmt->execute([$poolId, $voterHash]);
        return (bool) $stmt->fetch();
    }

    public static function getVotingResults($poolId) {
        $db = self::getInstance();
        
        // Check pool type
        $poolStmt = $db->prepare("SELECT pool_type FROM pools WHERE id = ?");
        $poolStmt->execute([$poolId]);
        $poolType = $poolStmt->fetchColumn() ?: 'fptp';

        if ($poolType === 'pr') {
            // PR: Group by party from pool_parties
            $stmt = $db->prepare(
                "SELECT p.name AS name, p.name AS party, p.abbreviation, p.symbol_url, COUNT(v.id) AS vote_count
                 FROM pool_parties pp
                 JOIN parties p ON pp.party_id = p.id
                 LEFT JOIN votes v ON v.party_id = p.id AND v.pool_id = pp.pool_id
                 WHERE pp.pool_id = ?
                 GROUP BY p.id
                 ORDER BY vote_count DESC"
            );
            $stmt->execute([$poolId]);
            return $stmt->fetchAll();
        } else {
            // FPTP: Group by candidate
            $stmt = $db->prepare(
                "SELECT pc.ballot_order, c.id, ci.full_name as name, p.name AS party, COUNT(v.id) AS vote_count
                 FROM pool_candidates pc
                 JOIN candidates c ON pc.candidate_id = c.id
                 JOIN users u ON c.user_id = u.id
                 JOIN citizens ci ON u.nid = ci.nid
                 LEFT JOIN parties p ON c.party_id = p.id
                 LEFT JOIN votes v ON v.pool_candidate_id = pc.id
                 WHERE pc.pool_id = ?
                 GROUP BY pc.id
                 ORDER BY pc.ballot_order"
            );
            $stmt->execute([$poolId]);
            return $stmt->fetchAll();
        }
    }

    public static function getOverallPartyResults(?string $district = null) {
        $db = self::getInstance();
        
        $sql = "SELECT p.name AS name, p.abbreviation AS party, p.symbol_url, 
                       (SELECT COUNT(*) FROM votes v WHERE v.party_id = p.id) + 
                       (SELECT COUNT(*) FROM votes v 
                        JOIN pool_candidates pc ON v.pool_candidate_id = pc.id 
                        JOIN candidates c ON pc.candidate_id = c.id 
                        WHERE c.party_id = p.id) AS vote_count
                FROM parties p";
        
        $params = [];
        if ($district) {
            $sql .= " JOIN pools po ON pc.pool_id = po.id
                      JOIN constituencies co ON po.constituency_id = co.id
                      WHERE co.district = ?";
            $params[] = $district;
        }
        
        $sql .= " GROUP BY p.id
                  HAVING vote_count > 0
                  ORDER BY vote_count DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
