<?php
/**
 * Live Results Portal — Pool Detail
 * Matches Figma wireframe:
 *   ✓ Vertical bar chart with % labels on bars
 *   ✓ Party logo circles below each bar
 *   ✓ Candidate table: SN | Photo+Name | Party Logo+Party Name | Votes | %
 *   ✓ Winner highlight card (gold, trophy)
 *   ✓ Auto-refresh every 30s with countdown
 *   ✓ Stats strip (total votes, candidates, lead margin)
 */

$totalVotes     = array_sum(array_column($results, 'vote_count'));
// Removed usort by vote_count to show candidates in ballot order as requested
$isLive         = ($pool['status'] === 'active');
$isClosed       = ($pool['status'] === 'closed');
$candidateCount = count($results);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">

<style>
:root {
    --teal:     #0d9488;
    --teal-lt:  #ecfeff;
    --teal-bdr: #5eead4;
    --teal-dk:  #0f766e;
    --gold:     #d97706;
    --gold-lt:  #fffbeb;
    --gold-md:  #fef3c7;
    --gold-bdr: #fcd34d;
    --gold-dk:  #92400e;
    --sl-900:   #0f172a;
    --sl-700:   #334155;
    --sl-500:   #64748b;
    --sl-300:   #cbd5e1;
    --sl-100:   #f1f5f9;
    --font:     'DM Sans', sans-serif;
    --mono:     'DM Mono', monospace;
}

.rp { font-family: var(--font); max-width: 960px; margin: 0 auto; padding: 1.5rem 1rem 4rem; }

/* Back link */
.rp-back {
    display: inline-flex; align-items: center; gap: 6px;
    font-size: .82rem; font-weight: 500; color: var(--teal);
    text-decoration: none; margin-bottom: 1.25rem;
    transition: gap .15s;
}
.rp-back:hover { gap: 10px; }

/* Banner */
.rp-banner {
    background: #fff; border: 1px solid #e2e8f0;
    border-left: 4px solid var(--teal); border-radius: 12px;
    padding: 1.1rem 1.4rem;
    display: flex; flex-wrap: wrap;
    align-items: flex-start; justify-content: space-between;
    gap: 1rem; margin-bottom: 1.25rem;
}
.rp-banner h1 { font-size: 1.4rem; font-weight: 700; color: var(--sl-900); margin: 0 0 .25rem; letter-spacing: -.02em; }
.rp-banner .sub { font-size: .78rem; color: var(--sl-500); margin: 0; }

.rp-badge-live {
    display: inline-flex; align-items: center; gap: 6px;
    background: var(--teal-lt); border: 1px solid var(--teal-bdr);
    color: var(--teal-dk); font-size: .67rem; font-weight: 700;
    letter-spacing: .08em; text-transform: uppercase;
    padding: 4px 11px; border-radius: 999px;
}
.rp-badge-live .dot {
    width: 7px; height: 7px; border-radius: 50%;
    background: var(--teal); animation: pulse 1.4s ease-in-out infinite;
}
.rp-badge-final {
    display: inline-flex; align-items: center; gap: 5px;
    background: var(--sl-100); border: 1px solid var(--sl-300);
    color: var(--sl-700); font-size: .67rem; font-weight: 700;
    letter-spacing: .08em; text-transform: uppercase;
    padding: 4px 11px; border-radius: 999px;
}
@keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.35;transform:scale(.7)} }

/* Refresh bar */
.rp-refresh {
    background: var(--teal-lt); border: 1px solid var(--teal-bdr);
    border-radius: 8px; padding: .5rem 1rem;
    display: flex; align-items: center; justify-content: space-between;
    font-size: .75rem; color: var(--teal-dk); font-weight: 500;
    margin-bottom: 1.25rem; gap: 1rem;
}
.rp-refresh .left { display: flex; align-items: center; gap: 6px; }
.rp-refresh .right { display: flex; align-items: center; gap: .6rem; }
.rp-refresh .cd { font-family: var(--mono); font-size: .82rem; font-weight: 600; }
.rp-refresh-track { width: 100px; height: 4px; background: var(--teal-bdr); border-radius: 999px; overflow: hidden; }
.rp-refresh-fill  { height: 100%; background: var(--teal); border-radius: 999px; transition: width 1s linear; }

/* Stats strip */
.rp-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px,1fr)); gap: .65rem; margin-bottom: 1.25rem; }
.rp-stat  { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: .8rem 1rem; }
.rp-stat .lbl { font-size: .6rem; font-weight: 600; text-transform: uppercase; letter-spacing: .07em; color: var(--sl-500); display: block; margin-bottom: 4px; }
.rp-stat .val { font-size: 1.45rem; font-weight: 700; font-family: var(--mono); color: var(--sl-900); display: block; line-height: 1; }
.rp-stat .val.teal { color: var(--teal); }
.rp-stat .val.gold { color: var(--gold); }
.rp-stat .note { font-size: .67rem; color: var(--sl-500); display: block; margin-top: 3px; }

/* Winner card */
.rp-winner {
    background: linear-gradient(135deg, var(--gold-md) 0%, #fff 55%);
    border: 2px solid var(--gold-bdr); border-radius: 14px;
    padding: 1.25rem 1.4rem;
    display: flex; align-items: center; gap: 1.1rem;
    margin-bottom: 1.25rem; position: relative; overflow: hidden;
}
.rp-winner::before {
    content: ''; position: absolute; top: 0; right: 0;
    width: 110px; height: 110px;
    background: radial-gradient(circle at top right, rgba(252,211,77,.4), transparent 70%);
    pointer-events: none;
}
.rp-winner-icon {
    flex-shrink: 0; width: 50px; height: 50px;
    background: var(--gold-md); border: 2px solid var(--gold-bdr);
    border-radius: 12px; display: flex; align-items: center; justify-content: center;
    font-size: 1.4rem;
}
.rp-winner-body { flex: 1; min-width: 0; }
.rp-winner-lbl { font-size: .6rem; font-weight: 700; text-transform: uppercase; letter-spacing: .1em; color: var(--gold); display: block; margin-bottom: 3px; }
.rp-winner-body h2 { font-size: 1.25rem; font-weight: 700; color: var(--gold-dk); margin: 0 0 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.rp-winner-party { font-size: .78rem; color: #92400e; opacity: .75; }
.rp-winner-right { text-align: right; flex-shrink: 0; }
.rp-winner-right .votes { font-size: 1.5rem; font-weight: 700; font-family: var(--mono); color: var(--gold-dk); display: block; line-height: 1; }
.rp-winner-right .pct  { font-size: .78rem; font-weight: 600; color: var(--gold); display: block; margin-top: 2px; }
.rp-winner-right .lead { font-size: .68rem; color: #a16207; display: block; margin-top: 2px; }

/* No votes */
.rp-empty { background: var(--sl-100); border: 1px dashed var(--sl-300); border-radius: 12px; padding: 2.5rem; text-align: center; color: var(--sl-500); font-size: .9rem; margin-bottom: 1.25rem; }
.rp-empty i { font-size: 2rem; opacity: .3; display: block; margin-bottom: .5rem; }

/* ── VOTE GRAPH SECTION (matches wireframe) ── */
.rp-graph-card {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 12px;
    padding: 1.25rem 1.4rem; margin-bottom: 1.25rem;
}
.rp-graph-title {
    font-size: .72rem; font-weight: 700; text-transform: uppercase;
    letter-spacing: .07em; color: var(--sl-500); margin: 0 0 1.25rem;
}

/* Chart + party logos wrapper */
.rp-chart-outer { position: relative; }
.rp-chart-wrap  { position: relative; }

/* Party logo row — circles below bars matching each column */
.rp-party-row {
    display: flex; align-items: flex-start;
    gap: 0; margin-top: .75rem;
    padding: 0 /* will be set by JS to align with chart bars */;
}
.rp-party-col {
    display: flex; flex-direction: column; align-items: center;
    gap: 4px; flex: 1;
}
.rp-party-avatar {
    width: 40px; height: 40px; border-radius: 50%;
    background: var(--sl-100); border: 2px solid #e2e8f0;
    display: flex; align-items: center; justify-content: center;
    font-size: .65rem; font-weight: 700; color: var(--sl-500);
    overflow: hidden; flex-shrink: 0;
}
.rp-party-avatar img { width: 100%; height: 100%; object-fit: cover; }
.rp-party-col-name {
    font-size: .65rem; font-weight: 600; color: var(--sl-700);
    text-align: center; line-height: 1.2;
    max-width: 80px; word-break: break-word;
}

/* ── CANDIDATE TABLE (matches wireframe bottom table) ── */
.rp-table-section { margin-bottom: 1.5rem; }
.rp-table-header {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: .65rem;
}
.rp-table-header h3 { font-size: .95rem; font-weight: 700; color: var(--sl-900); margin: 0; }
.rp-table-header .cnt {
    font-size: .7rem; color: var(--sl-500);
    background: var(--sl-100); border: 1px solid var(--sl-300);
    padding: 2px 8px; border-radius: 999px;
}
.rp-table {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;
    width: 100%; border-collapse: collapse;
}
.rp-table thead tr { background: var(--sl-100); border-bottom: 1px solid #e2e8f0; }
.rp-table thead th {
    padding: .65rem .9rem; font-size: .62rem; font-weight: 700;
    text-transform: uppercase; letter-spacing: .07em; color: var(--sl-500);
    text-align: left; white-space: nowrap;
}
.rp-table thead th.right { text-align: right; }
.rp-table tbody tr { border-bottom: 1px solid #f8fafc; transition: background .1s; }
.rp-table tbody tr:last-child { border-bottom: none; }
.rp-table tbody tr:hover { background: #f8fafc; }
.rp-table tbody tr.winner-row { background: var(--gold-lt); }
.rp-table tbody tr.winner-row:hover { background: #fef9eb; }
.rp-table td { padding: .75rem .9rem; vertical-align: middle; }

/* SN cell */
.td-sn { width: 42px; }
.td-sn .sn-badge {
    width: 28px; height: 28px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: .7rem; font-weight: 700;
}
.sn-badge.r1 { background: var(--gold-md); color: var(--gold-dk); border: 1px solid var(--gold-bdr); font-size: .85rem; }
.sn-badge.r2 { background: var(--sl-100); color: #475569; border: 1px solid var(--sl-300); }
.sn-badge.r3 { background: #fff7ed; color: #9a3412; border: 1px solid #fed7aa; }
.sn-badge.rn { background: #f8fafc; color: #94a3b8; border: 1px solid #e2e8f0; }

/* Candidate name cell */
.td-candidate { min-width: 160px; }
.td-candidate .cand-inner { display: flex; align-items: center; gap: 9px; }
.td-candidate .cand-photo {
    width: 36px; height: 36px; border-radius: 8px; flex-shrink: 0;
    background: var(--sl-100); border: 1px solid #e2e8f0;
    display: flex; align-items: center; justify-content: center;
    font-size: .7rem; font-weight: 600; color: var(--sl-500);
    overflow: hidden;
}
.td-candidate .cand-photo img { width: 100%; height: 100%; object-fit: cover; }
.td-candidate .cand-name {
    font-size: .88rem; font-weight: 600; color: var(--sl-900);
    display: flex; align-items: center; gap: 5px; line-height: 1.3;
}

/* Party cell */
.td-party { min-width: 140px; }
.td-party .party-inner { display: flex; align-items: center; gap: 8px; }
.td-party .party-logo {
    width: 30px; height: 30px; border-radius: 6px; flex-shrink: 0;
    background: var(--sl-100); border: 1px solid #e2e8f0;
    display: flex; align-items: center; justify-content: center;
    font-size: .6rem; font-weight: 700; color: var(--sl-500);
    overflow: hidden;
}
.td-party .party-logo img { width: 100%; height: 100%; object-fit: contain; }
.td-party .party-name { font-size: .82rem; color: var(--sl-700); font-weight: 500; line-height: 1.3; }

/* Votes + pct cells */
.td-votes, .td-pct { text-align: right; white-space: nowrap; }
.td-votes .v { font-family: var(--mono); font-size: 1rem; font-weight: 600; color: var(--sl-900); }
.td-pct   .p { font-size: .82rem; font-weight: 600; color: var(--teal); }
.td-pct   .p.gold { color: var(--gold); }
.td-pct .bar-wrap { height: 4px; background: var(--sl-100); border-radius: 999px; overflow: hidden; margin-top: 4px; min-width: 60px; }
.td-pct .bar-fill { height: 100%; border-radius: 999px; background: var(--teal); }
.td-pct .bar-fill.gold { background: linear-gradient(90deg, #f59e0b, #d97706); }

/* Footer */
.rp-footer { text-align: center; font-size: .7rem; color: var(--sl-500); margin-top: 1.5rem; }
.rp-footer span { font-family: var(--mono); }
</style>

<div class="rp">

    <a href="<?= BASE_URL ?>/voter/results" class="rp-back">
        <i class="fas fa-arrow-left"></i> All Results
    </a>

    <!-- Banner -->
    <div class="rp-banner">
        <div>
            <h1><?= htmlspecialchars($pool['title']) ?></h1>
            <p class="sub">
                <?= htmlspecialchars($pool['election_title']) ?>
                &nbsp;&middot;&nbsp;
                <?= htmlspecialchars($pool['constituency_name']) ?>
                &nbsp;&middot;&nbsp;
                <?= strtoupper(htmlspecialchars($pool['pool_type'])) ?>
            </p>
        </div>
        <?php if ($isLive): ?>
            <span class="rp-badge-live"><span class="dot"></span> Counting Live</span>
        <?php else: ?>
            <span class="rp-badge-final"><i class="fas fa-check-circle" style="font-size:.72rem"></i> Final Results</span>
        <?php endif; ?>
    </div>

    <!-- Auto-refresh (live only) -->
    <?php if ($isLive): ?>
    <div class="rp-refresh">
        <div class="left"><i class="fas fa-sync-alt" id="refreshIcon"></i> Auto-refreshing every 30 seconds</div>
        <div class="right">
            Next in <span class="cd" id="refreshCd">30</span>s
            <div class="rp-refresh-track"><div class="rp-refresh-fill" id="refreshFill" style="width:100%"></div></div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Stats strip -->
    <div class="rp-stats">
        <div class="rp-stat">
            <span class="lbl">Total Votes</span>
            <span class="val teal"><?= $isClosed ? number_format($totalVotes) : '???' ?></span>
            <?php if ($isLive): ?><span class="note">Counting in progress</span><?php endif; ?>
        </div>
        <div class="rp-stat">
            <span class="lbl">Candidates</span>
            <span class="val"><?= $candidateCount ?></span>
        </div>
        <?php if (!$isClosed): ?>
        <div class="rp-stat">
            <span class="lbl">Status</span>
            <span class="val" style="font-size:.95rem;font-family:var(--font);color:var(--teal)">Ongoing</span>
            <span class="note">Awaiting completion</span>
        </div>
        <?php else: ?>
        <div class="rp-stat">
            <span class="lbl">Status</span>
            <span class="val" style="font-size:.95rem;font-family:var(--font);color:#475569">Certified</span>
            <span class="note">Results are final</span>
        </div>
        <?php endif; ?>
    </div>

    <?php if (!$isClosed): ?>
        <!-- Placeholder for Ongoing Election -->
        <div style="background:linear-gradient(135deg, #f0fdfa 0%, #fff 100%); border:2px dashed #5eead4; border-radius:16px; padding:4rem 2rem; text-align:center; margin-bottom:2rem; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
            <div style="width:80px; height:80px; background:#ecfeff; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 1.5rem; border:2px solid #5eead4;">
                <i class="fas fa-hourglass-half" style="font-size:2rem; color:#0d9488; animation: spin-slow 4s linear infinite;"></i>
            </div>
            <h2 style="font-size:1.75rem; font-weight:700; color:#0f172a; margin-bottom:0.75rem;">Election Ongoing</h2>
            <p style="color:#64748b; max-width:500px; margin:0 auto; line-height:1.6; font-size:1rem;">
                Vote counting is currently in progress. Detailed results, including vote percentages and winner information, will be published once the election officially concludes.
            </p>
            <div style="margin-top:2rem; display:inline-flex; align-items:center; gap:8px; background:#fff; padding:8px 16px; border-radius:99px; border:1px solid #e2e8f0; font-size:0.82rem; font-weight:600; color:#0d9488;">
                <span style="width:8px; height:8px; background:#22c55e; border-radius:50%;"></span>
                Stay tuned for live updates
            </div>
        </div>
        
        <style>
            @keyframes spin-slow {
                0% { transform: rotate(0deg); }
                25% { transform: rotate(10deg); }
                75% { transform: rotate(-10deg); }
                100% { transform: rotate(0deg); }
            }
        </style>
    <?php endif; ?>

    <!-- Results Data -->
    <?php if ($totalVotes > 0): ?>
        
        <!-- Vote Graph (vertical bars + party logos) — matches wireframe -->
        <?php if ($isClosed): ?>
        <div class="rp-graph-card">
            <div class="rp-graph-title">Vote Graph</div>
            <div class="rp-chart-outer">
                <div class="rp-chart-wrap" style="height:<?= max(200, $candidateCount * 55) ?>px">
                    <canvas id="resultsChart"></canvas>
                </div>
                <!-- Party logo row below chart (matches wireframe) -->
                <div class="rp-party-row" id="partyRow">
                    <?php
                    // Sort by ballot order for chart display
                    $chartResults = $results;
                    usort($chartResults, fn($a,$b) => $a['ballot_order'] <=> $b['ballot_order']);
                    foreach ($chartResults as $r):
                        $initials = implode('', array_map(fn($w) => strtoupper($w[0]), array_slice(explode(' ', $r['party'] ?? 'Independent'), 0, 2)));
                        $partySlug = strtolower(str_replace([' ', '(', ')'], ['-', '', ''], $r['party'] ?? 'independent'));
                        $logoPath = BASE_URL . '/public/assets/img/parties/' . $partySlug . '.png';
                    ?>
                    <div class="rp-party-col">
                        <div class="rp-party-avatar">
                            <img src="<?= $logoPath ?>" alt="<?= htmlspecialchars($r['party'] ?? '') ?>"
                                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                            <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:.6rem;font-weight:700;color:var(--sl-500)"><?= htmlspecialchars($initials) ?></span>
                        </div>
                        <span class="rp-party-col-name"><?= htmlspecialchars($r['party'] ?? 'Indep.') ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

    <?php elseif (!$isLive): ?>
        <div class="rp-empty">
            <i class="fas fa-hourglass-half"></i>
            No votes recorded yet. Check back once voting has started.
        </div>
    <?php endif; ?>

    <!-- Candidate table — matches wireframe: SN | Photo+Name | Party Logo+Name | Votes | % -->
    <div class="rp-table-section">
        <div class="rp-table-header">
            <h3>Candidate Standings</h3>
            <span class="cnt"><?= $candidateCount ?> candidates</span>
        </div>
        <table class="rp-table">
            <thead>
                <tr>
                    <th class="td-sn">SN</th>
                    <th>Photo &amp; Candidate Name</th>
                    <th>Party</th>
                    <?php if ($isClosed): ?>
                    <th class="right">Gained Votes</th>
                    <th class="right">% of Total</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($results as $idx => $r):
                $pct       = $totalVotes > 0 ? round(($r['vote_count'] / $totalVotes) * 100, 1) : 0;
                $isWin     = ($idx === 0 && $totalVotes > 0);
                $rankClass = match(true) { $idx===0=>'r1', $idx===1=>'r2', $idx===2=>'r3', default=>'rn' };
                $partySlug = strtolower(str_replace([' ', '(', ')'], ['-', '', ''], $r['party'] ?? 'independent'));
                $logoPath  = BASE_URL . '/public/assets/img/parties/' . $partySlug . '.png';
                $candPhoto = BASE_URL . '/public/assets/img/candidates/' . (int)$r['id'] . '.jpg';
                $nameInitials = strtoupper(substr($r['name'], 0, 1));
                $partyInitials = implode('', array_map(fn($w)=>strtoupper($w[0]), array_slice(explode(' ', $r['party'] ?? 'Ind'), 0, 2)));
            ?>
            <tr>
                <!-- SN -->
                <td class="td-sn">
                    <div class="sn-badge rn">
                        <?= '#' . ($idx + 1) ?>
                    </div>
                </td>
                <!-- Photo + Candidate Name -->
                <td class="td-candidate">
                    <div class="cand-inner">
                        <div class="cand-photo">
                            <img src="<?= $candPhoto ?>" alt=""
                                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                            <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center"><?= htmlspecialchars($nameInitials) ?></span>
                        </div>
                        <span class="cand-name">
                            <?= htmlspecialchars($r['name']) ?>
                        </span>
                    </div>
                </td>
                <!-- Party Logo + Name -->
                <td class="td-party">
                    <div class="party-inner">
                        <div class="party-logo">
                            <img src="<?= $logoPath ?>" alt=""
                                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                            <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center"><?= htmlspecialchars($partyInitials) ?></span>
                        </div>
                        <span class="party-name"><?= htmlspecialchars($r['party'] ?? 'Independent') ?></span>
                    </div>
                </td>
                <!-- Gained Votes -->
                <?php if ($isClosed): ?>
                <td class="td-votes"><span class="v"><?= number_format($r['vote_count']) ?></span></td>
                <!-- % of Total -->
                <td class="td-pct">
                    <span class="p"><?= $pct ?>%</span>
                    <div class="bar-wrap">
                        <div class="bar-fill" style="width:<?= $pct ?>%"></div>
                    </div>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Footer -->
    <div class="rp-footer">
        Last updated: <span><?= date('d M Y, H:i:s') ?></span>
        <?php if ($isLive): ?>
        &nbsp;&middot;&nbsp;
        <a href="javascript:location.reload()" style="color:var(--teal);text-decoration:none">Refresh now</a>
        <?php endif; ?>
    </div>

</div><!-- /.rp -->

<?php if ($isClosed && $totalVotes > 0):
    // Sort by ballot order for chart display (left-to-right matches wireframe)
    $chartData = $results;
    usort($chartData, fn($a,$b) => $a['ballot_order'] <=> $b['ballot_order']);
    $chartJson = json_encode(array_values(array_map(fn($r) => [
        'name'  => $r['name'],
        'votes' => (int)$r['vote_count'],
        'party' => $r['party'] ?? 'Independent'
    ], $chartData)));
?>
<script>
document.addEventListener('DOMContentLoaded', function () {

    /* ── Vertical bar chart (matches wireframe) ── */
    const ctx = document.getElementById('resultsChart');
    if (!ctx) return;

    const raw = <?= $chartJson ?>;

    const palette = ['#f97066','#4ade80','#60a5fa','#c084fc','#fbbf24','#34d399','#f97316','#94a3b8'];
    const labels  = raw.map(r => r.name);
    const data    = raw.map(r => r.votes);
    const total   = <?= $totalVotes ?>;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                data,
                backgroundColor: labels.map((_,i) => palette[i % palette.length] + 'cc'),
                borderColor:     labels.map((_,i) => palette[i % palette.length]),
                borderWidth: 1.5, borderRadius: 6, borderSkipped: false,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label(c) {
                            const v = c.raw;
                            const p = ((v/total)*100).toFixed(1);
                            return `  ${v.toLocaleString()} votes  (${p}%)`;
                        }
                    },
                    backgroundColor: '#0f172a', titleColor: '#94a3b8',
                    bodyColor: '#f8fafc', padding: 10, cornerRadius: 8,
                },
                /* Show % labels on top of bars */
                datalabels: false
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: '#f1f5f9' },
                    ticks: { precision: 0, color: '#94a3b8', font: { size: 11 } },
                    border: { color: '#f1f5f9' }
                },
                x: {
                    grid: { display: false },
                    ticks: {
                        color: '#334155',
                        font: { family:"'DM Sans',sans-serif", size: 11, weight: '500' },
                        maxRotation: 30
                    },
                    border: { display: false }
                }
            },
            animation: { duration: 700, easing: 'easeOutQuart' }
        },
        plugins: [{
            /* Draw % label above each bar */
            id: 'pctLabels',
            afterDatasetsDraw(chart) {
                const { ctx: c, data } = chart;
                const ds = chart.getDatasetMeta(0);
                c.save();
                c.font = "600 11px 'DM Sans',sans-serif";
                c.fillStyle = '#334155';
                c.textAlign = 'center';
                ds.data.forEach((bar, i) => {
                    const v = data.datasets[0].data[i];
                    if (!v) return;
                    const pct = ((v / total) * 100).toFixed(1) + '%';
                    c.fillText(pct, bar.x, bar.y - 5);
                });
                c.restore();
            }
        }]
    });

    <?php if ($isLive): ?>
    /* Auto-refresh countdown */
    let rem = 30;
    const cdEl   = document.getElementById('refreshCd');
    const fillEl = document.getElementById('refreshFill');
    const iconEl = document.getElementById('refreshIcon');
    setInterval(() => {
        rem--;
        if (cdEl)   cdEl.textContent = rem;
        if (fillEl) fillEl.style.width = ((rem / 30) * 100) + '%';
        if (rem <= 0) {
            if (iconEl) iconEl.classList.add('fa-spin');
            location.reload();
        }
    }, 1000);
    <?php endif; ?>

});
</script>
<?php endif; ?>