<?php /* TODO: Build the Cast Your Vote view */ ?>
<div class="container-fluid py-4">
    <h4><?= htmlspecialchars($title ?? 'Cast Your Vote') ?></h4>
    <!-- TODO: Add your HTML here -->
</div>
