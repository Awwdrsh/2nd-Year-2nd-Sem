<?php
/**
 * Unified Election Results Dashboard
 * Shows a single master card with integrated graph and filters.
 */

$totalVotes     = array_sum(array_column($results, 'vote_count'));
$isLive         = ($pool && $pool['status'] === 'active');
$isClosed       = ($pool && $pool['status'] === 'closed');
$candidateCount = count($results);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">

<style>
:root {
    --teal:     #0d9488;
    --teal-lt:  #ecfeff;
    --teal-bdr: #5eead4;
    --teal-dk:  #0f766e;
    --gold:     #d97706;
    --gold-lt:  #fffbeb;
    --gold-md:  #fef3c7;
    --gold-bdr: #fcd34d;
    --gold-dk:  #92400e;
    --sl-900:   #0f172a;
    --sl-700:   #334155;
    --sl-500:   #64748b;
    --sl-300:   #cbd5e1;
    --sl-100:   #f1f5f9;
    --font:     'DM Sans', sans-serif;
    --mono:     'DM Mono', monospace;
}

.rp-wrap { font-family: var(--font); max-width: 1000px; margin: 0 auto; padding: 2rem 1rem 4rem; }

/* Header */
.rp-header { margin-bottom: 2rem; text-align: center; }
.rp-header h1 { font-size: 2.2rem; font-weight: 800; color: var(--sl-900); margin: 0 0 .5rem; letter-spacing: -.03em; }
.rp-header p { color: var(--sl-500); font-size: 1rem; }

/* Filters Section */
.rp-filters {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 16px;
    padding: 1.25rem; margin-bottom: 2rem;
    display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-end;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
}
.rp-filter-group { display: flex; flex-direction: column; gap: 6px; flex: 1; min-width: 200px; }
.rp-filter-group label { font-size: .75rem; font-weight: 700; color: var(--sl-500); text-transform: uppercase; letter-spacing: .05em; }
.rp-filter-group select {
    padding: 10px 14px; border-radius: 10px; border: 1px solid #e2e8f0;
    font-size: .9rem; font-family: var(--font); color: var(--sl-900);
    background-color: #f8fafc; cursor: pointer; transition: all .2s;
}
.rp-filter-group select:focus { border-color: var(--teal); outline: none; box-shadow: 0 0 0 3px rgba(13,148,136,0.1); }

.rp-btn-filter {
    padding: 10px 24px; background: var(--teal); color: #fff; border: none;
    border-radius: 10px; font-weight: 600; cursor: pointer; transition: .2s;
    height: 42px; display: flex; align-items: center; justify-content: center;
}
.rp-btn-filter:hover { background: var(--teal-dk); transform: translateY(-1px); }

/* Master Card */
.rp-master-card {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 20px;
    overflow: hidden; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.08);
}

.rp-card-header {
    padding: 2rem; border-bottom: 1px solid #f1f5f9;
    display: flex; justify-content: space-between; align-items: flex-start;
    background: linear-gradient(to right, #ffffff, #f8fafc);
}
.rp-card-header .left h2 { font-size: 1.6rem; font-weight: 700; color: var(--sl-900); margin: 0 0 .4rem; }
.rp-card-header .left .meta { font-size: .85rem; color: var(--sl-500); display: flex; align-items: center; gap: 8px; }

.rp-badge {
    padding: 5px 12px; border-radius: 99px; font-size: .7rem; font-weight: 700;
    text-transform: uppercase; letter-spacing: .05em; display: inline-flex; align-items: center; gap: 6px;
}
.rp-badge.live { background: var(--teal-lt); color: var(--teal-dk); border: 1px solid var(--teal-bdr); }
.rp-badge.live .dot { width: 8px; height: 8px; background: var(--teal); border-radius: 50%; animation: pulse 1.5s infinite; }
.rp-badge.closed { background: var(--sl-100); color: var(--sl-700); border: 1px solid var(--sl-300); }

@keyframes pulse { 0% { transform: scale(0.95); opacity: 1; } 50% { transform: scale(1.1); opacity: 0.5; } 100% { transform: scale(0.95); opacity: 1; } }

/* Stats Grid */
.rp-stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; padding: 1.5rem 2rem; background: #fafafa; }
.rp-stat-box { display: flex; flex-direction: column; }
.rp-stat-box .lbl { font-size: .65rem; font-weight: 700; color: var(--sl-500); text-transform: uppercase; margin-bottom: 4px; }
.rp-stat-box .val { font-size: 1.5rem; font-weight: 700; font-family: var(--mono); color: var(--sl-900); }

/* Graph Section */
.rp-graph-section { padding: 2rem; border-top: 1px solid #f1f5f9; }
.rp-graph-title { font-size: .8rem; font-weight: 700; color: var(--sl-500); text-transform: uppercase; margin-bottom: 1.5rem; }
.rp-chart-container { height: 350px; position: relative; }

/* Table Section */
.rp-table-section { padding: 0 2rem 2rem; }
.rp-table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
.rp-table th { text-align: left; padding: 12px; font-size: .75rem; color: var(--sl-500); text-transform: uppercase; border-bottom: 2px solid #f1f5f9; }
.rp-table td { padding: 16px 12px; border-bottom: 1px solid #f8fafc; vertical-align: middle; }
.rp-table tr:hover { background: #fcfcfc; }

.cand-info { display: flex; align-items: center; gap: 12px; }
.cand-photo { width: 40px; height: 40px; border-radius: 50%; overflow: hidden; background: #eee; flex-shrink: 0; }
.cand-photo img { width: 100%; height: 100%; object-fit: cover; }
.cand-name { font-weight: 600; color: var(--sl-900); font-size: .95rem; }

.party-badge { display: flex; align-items: center; gap: 8px; font-size: .85rem; color: var(--sl-600); }
.party-logo { width: 24px; height: 24px; object-fit: contain; }

.vote-cnt { font-family: var(--mono); font-weight: 700; font-size: 1.1rem; color: var(--teal); }
.vote-pct { font-size: .8rem; color: var(--sl-500); font-weight: 600; }

.progress-bar { width: 100px; height: 6px; background: #f1f5f9; border-radius: 99px; overflow: hidden; margin-top: 4px; }
.progress-fill { height: 100%; background: var(--teal); border-radius: 99px; }

/* Empty State */
.rp-empty { padding: 5rem 2rem; text-align: center; color: var(--sl-400); }
.rp-empty i { font-size: 3rem; margin-bottom: 1rem; display: block; opacity: .3; }

/* Auto-refresh indicator */
.rp-refresh-bar { padding: 8px 2rem; background: var(--teal-lt); color: var(--teal-dk); font-size: .75rem; font-weight: 600; display: flex; justify-content: space-between; align-items: center; }
.rp-refresh-progress { width: 120px; height: 4px; background: var(--teal-bdr); border-radius: 99px; overflow: hidden; }
.rp-refresh-fill { height: 100%; background: var(--teal); width: 100%; transition: width 1s linear; }

@media (max-width: 768px) {
    .rp-filters { flex-direction: column; align-items: stretch; }
    .rp-card-header { flex-direction: column; gap: 1rem; }
}
</style>

<div class="rp-wrap">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <a href="<?= BASE_URL ?>/voter/dashboard" class="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-semibold text-slate-600 hover:bg-slate-50 transition shadow-sm flex items-center gap-2">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <div class="flex items-center gap-3">
             <?php if (Auth::isVoter()): ?>
                <div id="voterTimer" class="px-2 py-1 rounded bg-warning text-dark border border-warning shadow-sm d-flex align-items-center gap-2" style="font-size: 0.75rem; font-weight: 800; min-width: 80px;">
                    <i class="fas fa-clock"></i>
                    <span id="timerDisplay">10:00</span>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="rp-header">
        <h1>Election Results</h1>
        <p>Live tracking and certified outcomes for local and national elections</p>
    </div>

    <!-- FILTERS -->
    <form method="GET" class="rp-filters" id="filterForm">
        <div class="rp-filter-group">
            <label>Location / District</label>
            <select name="district" onchange="this.form.submit()">
                <option value="">All Districts</option>
                <?php foreach ($districts as $d): ?>
                    <option value="<?= $d ?>" <?= ($selectedDistrict == $d) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($d) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="rp-filter-group">
            <label>Select Election</label>
            <select name="pool_id" onchange="this.form.submit()">
                <?php if (empty($pools)): ?>
                    <option value="">No elections found</option>
                <?php else: ?>
                    <?php if ($selectedDistrict == ''): ?>
                        <option value="0" <?= ($selectedPoolId == 0) ? 'selected' : '' ?>>Overall Performance</option>
                    <?php endif; ?>
                    <?php foreach ($pools as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= ($selectedPoolId == $p['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($p['title']) ?> (<?= ucfirst($p['status']) ?>)
                        </option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
        </div>

        <button type="submit" class="rp-btn-filter">Update Results</button>
        <a href="<?= BASE_URL ?>/voter/results" style="font-size: .8rem; color: var(--sl-400); text-decoration: none; margin-bottom: 12px;">Reset</a>
    </form>

    <!-- MASTER CARD -->
    <?php if ($pool): ?>
        <div class="rp-master-card">
            


            <div class="rp-card-header">
                <div class="left">
                    <h2><?= htmlspecialchars($pool['title']) ?></h2>
                    <div class="meta">
                        <span><?= htmlspecialchars($pool['election_title']) ?></span>
                        &bull;
                        <span><?= htmlspecialchars($pool['constituency_name']) ?></span>
                    </div>
                </div>
                <div class="right">
                    <?php if ($isLive): ?>
                        <span class="rp-badge live"><span class="dot"></span> Ongoing</span>
                    <?php else: ?>
                        <span class="rp-badge closed"><i class="fas fa-check-circle"></i> Completed</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="rp-stats-grid">
                <div class="rp-stat-box">
                    <span class="lbl">Total Votes</span>
                    <span class="val" style="color: var(--teal)">
                        <?= $isLive ? '<span style="font-size: 1.1rem; color: var(--sl-400);"><i class="fas fa-lock"></i> Hidden</span>' : number_format($totalVotes) ?>
                    </span>
                </div>
                <div class="rp-stat-box">
                    <span class="lbl">Candidates</span>
                    <span class="val"><?= $candidateCount ?></span>
                </div>
                <div class="rp-stat-box">
                    <span class="lbl">District</span>
                    <span class="val" style="font-size: 1.1rem; font-family: var(--font)"><?= htmlspecialchars($pool['district']) ?></span>
                </div>
                <div class="rp-stat-box">
                    <span class="lbl">Type</span>
                    <span class="val" style="font-size: 1.1rem; font-family: var(--font)"><?= strtoupper($pool['pool_type']) ?></span>
                </div>
            </div>

            <?php if ($isLive): ?>
                <div class="rp-empty" style="padding: 4rem 2rem 2rem;">
                    <i class="fas fa-lock" style="font-size: 2.5rem; color: var(--teal); margin-bottom: 1rem; opacity: 1;"></i>
                    <h3 style="font-size: 1.25rem; font-weight: 700; color: var(--sl-900); margin-bottom: 0.5rem;">Election is Ongoing</h3>
                    <p style="color: var(--sl-500);">Live results are hidden to ensure voting integrity. The final certified outcomes will be published once the election concludes.</p>
                </div>

                <div class="rp-table-section">
                    <div class="rp-graph-title" style="margin-bottom: 1rem;">Participating <?= (($isOverall ?? false) || ($pool['pool_type'] === 'pr')) ? 'Parties' : 'Candidates' ?></div>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1rem;">
                        <?php foreach ($results as $idx => $r): 
                            $symbolUrl = !empty($r['symbol_url']) ? $r['symbol_url'] : '';
                            $photoUrl = !empty($r['photo_path']) ? $r['photo_path'] : '';
                            
                            if (empty($symbolUrl)) {
                                $partySlug = strtolower(str_replace([' ', '(', ')'], ['-', '', ''], $r['party'] ?? 'independent'));
                                $symbolUrl = BASE_URL . '/public/assets/img/parties/' . $partySlug . '.png';
                            }
                            if (empty($photoUrl)) {
                                $photoUrl = BASE_URL . '/public/assets/img/candidates/' . (int)($r['id'] ?? 0) . '.jpg';
                            }
                            $nameInitials = strtoupper(substr($r['name'] ?? 'V', 0, 1));
                        ?>
                        <div style="display: flex; align-items: center; gap: 12px; padding: 1rem; border: 1px solid #e2e8f0; border-radius: 12px; background: #fff;">
                            <div class="cand-photo" style="<?= (($isOverall ?? false) || ($pool['pool_type'] === 'pr')) ? 'border-radius: 8px; background: #f8fafc;' : '' ?>">
                                <?php if (($isOverall ?? false) || ($pool['pool_type'] === 'pr')): ?>
                                     <img src="<?= $symbolUrl ?>" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                                     <i class="fas fa-flag" style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:.8rem;color:var(--sl-300)"></i>
                                <?php else: ?>
                                    <img src="<?= $photoUrl ?>" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                                    <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;color:var(--sl-400)"><?= $nameInitials ?></span>
                                <?php endif; ?>
                            </div>
                            <div>
                                <div class="cand-name" style="font-size: .9rem; line-height: 1.2;"><?= htmlspecialchars($r['name']) ?></div>
                                <div class="party-badge" style="font-size: .75rem; margin-top: 4px;">
                                    <span><?= htmlspecialchars($r['party'] ?? 'Independent') ?></span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

            <?php elseif ($totalVotes > 0): ?>
                <!-- Graph -->
                <div class="rp-graph-section">
                    <div class="rp-graph-title">Vote Distribution</div>
                    <div class="rp-chart-container">
                        <canvas id="resultsChart"></canvas>
                    </div>
                </div>

                <!-- Standings Table -->
                <div class="rp-table-section">
                    <div class="rp-graph-title"><?= (($isOverall ?? false) || ($pool['pool_type'] === 'pr')) ? 'Party Standings' : 'Candidate Standings' ?></div>
                    <table class="rp-table">
                        <thead>
                            <tr>
                                <th><?= (($isOverall ?? false) || ($pool['pool_type'] === 'pr')) ? 'Party Name' : 'Candidate' ?></th>
                                <th><?= (($isOverall ?? false) || ($pool['pool_type'] === 'pr')) ? 'Abbr.' : 'Party' ?></th>
                                <th style="text-align: right;">Votes</th>
                                <th style="text-align: right;">Percentage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($results as $idx => $r): 
                                $pct = $totalVotes > 0 ? round(($r['vote_count'] / $totalVotes) * 100, 1) : 0;
                                
                                // Image logic
                                $symbolUrl = !empty($r['symbol_url']) ? $r['symbol_url'] : '';
                                $photoUrl = !empty($r['photo_path']) ? $r['photo_path'] : '';
                                
                                if (empty($symbolUrl)) {
                                    $partySlug = strtolower(str_replace([' ', '(', ')'], ['-', '', ''], $r['party'] ?? 'independent'));
                                    $symbolUrl = BASE_URL . '/public/assets/img/parties/' . $partySlug . '.png';
                                }
                                
                                if (empty($photoUrl)) {
                                    $photoUrl = BASE_URL . '/public/assets/img/candidates/' . (int)($r['id'] ?? 0) . '.jpg';
                                }
                                
                                $nameInitials = strtoupper(substr($r['name'] ?? 'V', 0, 1));
                            ?>
                            <tr>
                                <td>
                                    <div class="cand-info">
                                        <div class="cand-photo" style="<?= (($isOverall ?? false) || ($pool['pool_type'] === 'pr')) ? 'border-radius: 8px; background: #fff;' : '' ?>">
                                            <?php if (($isOverall ?? false) || ($pool['pool_type'] === 'pr')): ?>
                                                 <img src="<?= $symbolUrl ?>" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                                                 <i class="fas fa-flag" style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:.8rem;color:var(--sl-300)"></i>
                                            <?php else: ?>
                                                <img src="<?= $photoUrl ?>" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                                                <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;color:var(--sl-400)"><?= $nameInitials ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <span class="cand-name"><?= htmlspecialchars($r['name']) ?></span>
                                    </div>
                                </td>
                                <td>
                                    <div class="party-badge">
                                        <img src="<?= $symbolUrl ?>" class="party-logo" onerror="this.style.display='none'">
                                        <span><?= htmlspecialchars($r['party'] ?? 'Independent') ?></span>
                                    </div>
                                </td>
                                <td style="text-align: right;">
                                    <span class="vote-cnt"><?= number_format($r['vote_count']) ?></span>
                                </td>
                                <td style="text-align: right;">
                                    <div style="display:flex; flex-direction:column; align-items:flex-end;">
                                        <span class="vote-pct"><?= $pct ?>%</span>
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width: <?= $pct ?>%"></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="rp-empty">
                    <i class="fas fa-vote-yea"></i>
                    <p>No votes have been recorded for this election yet.</p>
                </div>
            <?php endif; ?>

        </div>
    <?php else: ?>
        <div class="rp-master-card">
            <div class="rp-empty">
                <i class="fas fa-search-location"></i>
                <p>Please select a district and election to view results.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if ($pool && !$isLive && $totalVotes > 0): 
    $chartData = json_encode(array_map(fn($r) => [
        'label' => $r['name'],
        'votes' => (int)$r['vote_count']
    ], $results));
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('resultsChart');
    if (!ctx) return;

    const rawData = <?= $chartData ?>;
    const labels = rawData.map(d => d.label);
    const votes = rawData.map(d => d.votes);
    const total = <?= $totalVotes ?>;

    const colors = [
        '#0d9488', '#0ea5e9', '#6366f1', '#a855f7', '#ec4899', 
        '#f43f5e', '#f97316', '#eab308', '#84cc16', '#10b981'
    ];

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                data: votes,
                backgroundColor: colors.map(c => c + 'dd'),
                borderColor: colors,
                borderWidth: 1,
                borderRadius: 8,
                barThickness: 40
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const v = context.raw;
                            const p = ((v / total) * 100).toFixed(1);
                            return ` ${v.toLocaleString()} votes (${p}%)`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: '#f1f5f9' },
                    ticks: { color: '#94a3b8', font: { size: 11 } }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: '#64748b', font: { weight: '600' } }
                }
            }
        }
    });
});


</script>
<?php endif; ?>
