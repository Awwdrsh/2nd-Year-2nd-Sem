<?php
$successMap = [
    'vote_cast' => '✓ Vote Cast Successfully! Your vote has been recorded securely.',
    '1'         => '✓ Vote Cast Successfully! Your vote has been recorded securely.',
];
$errorMap = [
    'already_voted'         => 'You have already voted in this pool.',
    'already_voted_in_pool' => 'You have already voted in this pool.',
    'pool_not_found'        => 'Voting pool is not available or has closed.',
    'pool_invalid'          => 'Voting pool is not available or has closed.',
    'pool_closed'           => 'This pool has closed.',
    'no_candidates'         => 'No candidates have been assigned to this pool yet.',
    'verify_required'       => 'Identity verification is required before voting.',
    'invalid'               => 'Invalid request. Please try again.',
    'invalid_verification'  => 'Verification failed. Please enter the last 4 digits of your NID correctly.',
    'timeout'               => 'Your session expired. Please sign in again.',
];
?>

<style>
  .ovms-dashboard {
    font-family: 'Segoe UI', system-ui, sans-serif;
    background: #f0f4f8;
    min-height: 100vh;
    padding: 0;
  }

  /* ── Voter Info Bar ── */
  .voter-bar {
    background: #fff;
    border-bottom: 1px solid #e2e8f0;
    padding: 14px 28px;
    display: flex;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
  }
  .voter-avatar {
    width: 48px; height: 48px;
    border-radius: 50%;
    background: #e6f7f4;
    border: 2px solid #14b8a6;
    overflow: hidden;
    display: flex; align-items: center; justify-content: center;
    color: #0d9488; font-size: 20px; flex-shrink: 0;
  }
  .voter-avatar img { width: 100%; height: 100%; object-fit: cover; }
  .voter-meta h1 { margin: 0; font-size: 16px; font-weight: 700; color: #1e293b; display: flex; align-items: center; gap: 10px; }
  .voter-meta p  { margin: 2px 0 0; font-size: 12px; color: #64748b; }
  .session-timer { font-size: 11px; font-weight: 700; color: #92400e; background: #fef3c7; padding: 2px 8px; border-radius: 4px; border: 1px solid #fde68a; }
  .voter-actions { margin-left: auto; display: flex; align-items: center; gap: 12px; }
  .constituency-badge {
    background: #f0fdf9; border: 1px solid #99f6e4;
    border-radius: 8px; padding: 6px 14px; text-align: center;
  }
  .constituency-badge small { display: block; font-size: 10px; color: #64748b; }
  .constituency-badge strong { font-size: 13px; color: #0d9488; }
  .btn-logout {
    display: flex; align-items: center; gap: 6px;
    background: #fff5f5; color: #dc2626;
    border: 1px solid #fecaca; border-radius: 8px;
    padding: 7px 14px; font-size: 13px; font-weight: 600;
    text-decoration: none; transition: background .15s;
  }
  .btn-logout:hover { background: #fee2e2; }

  /* ── Alerts ── */
  .alert-wrap { padding: 16px 28px 0; }
  .alert-success {
    background: #f0fdf4; border: 1px solid #86efac;
    border-radius: 10px; padding: 14px 16px;
    display: flex; gap: 12px; align-items: flex-start;
  }
  .alert-success .ic { color: #16a34a; font-size: 18px; margin-top: 1px; }
  .alert-success .msg { font-weight: 700; color: #166534; font-size: 14px; }
  .receipt-box {
    display: inline-block; margin-top: 8px;
    background: #dcfce7; border: 1px solid #86efac;
    border-radius: 6px; padding: 6px 12px;
  }
  .receipt-box small { font-size: 10px; color: #15803d; font-weight: 600; display: block; }
  .receipt-box span  { font-family: monospace; font-size: 13px; color: #166534; font-weight: 700; letter-spacing: 2px; }
  .alert-error {
    background: #fff1f2; border: 1px solid #fecdd3;
    border-radius: 10px; padding: 12px 16px;
    display: flex; gap: 10px; align-items: center;
    color: #be123c; font-size: 13px;
  }

  /* ── Pool Container ── */
  .pools-wrap {
    padding: 20px 28px;
    max-width: 1040px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  .pools-wrap h2 { font-size: 15px; font-weight: 700; color: #334155; margin: 0 0 14px; letter-spacing: .3px; width: 100%; }

  /* ── Election Cards Wrapper ── */
  .election-wrapper {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    width: 100%;
    margin-bottom: 24px;
  }

  /* ── Ballot Card ── */
  .ballot-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 1px 4px rgba(0,0,0,.06);
    width: 100%;
    display: flex;
    flex-direction: column;
  }
  .ballot-card-header {
    background: #0f766e;
    color: #fff;
    padding: 12px 20px;
    display: flex; justify-content: space-between; align-items: center;
    gap: 12px;
  }
  .ballot-card-header h3 { margin: 0; font-size: 15px; font-weight: 700; line-height: 1.3; }
  .ballot-card-header small { font-size: 11px; color: #99f6e4; margin-top: 2px; display: block; }
  .pool-type-badge {
    background: rgba(255,255,255,.2); border: 1px solid rgba(255,255,255,.4);
    border-radius: 20px; padding: 4px 10px; font-size: 10px;
    font-weight: 800; letter-spacing: .5px; text-transform: uppercase; white-space: nowrap;
  }

  /* ── Panel Body ── */
  .ballot-panel {
    padding: 16px;
    flex: 1;
    display: flex;
    flex-direction: column;
  }
  .panel-header {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 12px; padding-bottom: 10px;
    border-bottom: 1.5px solid #e2e8f0;
  }
  .panel-title {
    font-size: 12px; font-weight: 700; color: #475569;
    text-transform: uppercase; letter-spacing: .6px;
  }
  .panel-timer {
    background: #fef3c7; border: 1px solid #fde68a;
    border-radius: 5px; padding: 2px 8px;
    font-size: 11px; font-weight: 700; color: #92400e;
    display: flex; align-items: center; gap: 4px;
  }

  /* ── Candidate Scroll List ── */
  .candidates-scroll {
    max-height: 260px;
    overflow-y: auto;
    display: flex; flex-direction: column; gap: 8px;
    padding-right: 4px;
    margin-bottom: 12px;
  }
  .candidates-scroll::-webkit-scrollbar { width: 5px; }
  .candidates-scroll::-webkit-scrollbar-track { background: #f1f5f9; border-radius: 3px; }
  .candidates-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }

  .candidate-card {
    display: flex; align-items: center; gap: 10px;
    background: #f8fafc; border: 1px solid #e2e8f0;
    border-radius: 9px; padding: 9px 11px;
    transition: border-color .15s, background .15s;
    position: relative;
  }
  .cand-photo {
    width: 38px; height: 38px; border-radius: 50%;
    background: #e2e8f0; border: 1.5px solid #cbd5e1;
    display: flex; align-items: center; justify-content: center;
    overflow: hidden; font-size: 15px; font-weight: 700; color: #64748b;
    flex-shrink: 0;
  }
  .cand-photo img { width: 100%; height: 100%; object-fit: cover; }
  .cand-info { flex: 1; min-width: 0; }
  .cand-name { font-size: 13px; font-weight: 700; color: #1e293b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .cand-party { font-size: 11px; color: #64748b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .manifesto-link {
    color: #6366f1; background: #eef2ff; border-radius: 50%;
    width: 26px; height: 26px; display: flex; align-items: center;
    justify-content: center; flex-shrink: 0; font-size: 11px;
    text-decoration: none; transition: background .15s;
  }
  .manifesto-link:hover { background: #c7d2fe; }

  /* ── Panel Actions ── */
  .panel-actions {
    display: flex; gap: 8px; justify-content: flex-end;
    padding-top: 10px; border-top: 1px solid #e2e8f0;
  }
  .btn-vote-now {
    background: #0d9488; color: #fff; border: none;
    border-radius: 7px; padding: 7px 18px; font-size: 13px;
    font-weight: 700; cursor: pointer; transition: background .15s;
    display: flex; align-items: center; gap: 6px; text-decoration: none;
  }
  .btn-vote-now:hover { background: #0f766e; }
  .btn-clear {
    background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0;
    border-radius: 7px; padding: 7px 14px; font-size: 13px;
    font-weight: 600; cursor: pointer; transition: background .15s;
  }
  .btn-clear:hover { background: #e2e8f0; }
  .already-voted-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: #f0fdf4; color: #16a34a; border: 1px solid #86efac;
    border-radius: 7px; padding: 7px 14px; font-size: 13px; font-weight: 700;
  }

  /* ── Empty state ── */
  .no-candidates {
    text-align: center; padding: 24px 12px;
    color: #94a3b8; font-size: 13px;
    border: 1.5px dashed #e2e8f0; border-radius: 8px;
    background: #f8fafc;
  }

  .empty-pools {
    background: #eff6ff; border: 1px solid #bfdbfe;
    border-radius: 10px; padding: 28px; text-align: center;
    color: #3b82f6; font-size: 14px;
    width: 100%;
  }

  @media (max-width: 768px) {
    .election-wrapper { grid-template-columns: 1fr; }
    .voter-bar { padding: 12px 16px; }
    .pools-wrap { padding: 16px; }
    .alert-wrap { padding: 12px 16px 0; }
  }
</style>

<div class="ovms-dashboard">
<!-- Verification Modal -->
<div class="modal fade" id="voteVerifyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-3xl border border-slate-200 overflow-hidden">
            <div class="modal-header bg-teal-600 text-white border-0">
                <h5 class="modal-title"><i class="fas fa-shield-alt"></i> Secure Voting Verification</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?= BASE_URL ?>/voter/vote/verify" method="POST" id="voteVerifyForm">
                <input type="hidden" name="pool_id" id="verifyPoolId" value="">
                <div class="modal-body p-5 bg-slate-50">
                    <p class="text-sm text-slate-600 mb-4">Before proceeding to the ballot, confirm your identity by entering the <strong>last 4 digits of your registered NID</strong>.</p>
                    <div class="mb-3">
                        <label class="form-label text-sm font-semibold text-slate-700">Last 4 digits of NID</label>
                        <input type="text" name="verification_code" id="verificationCode" class="form-control rounded-xl border-slate-300" maxlength="4" pattern="\d{4}" required placeholder="e.g. 1234">
                    </div>
                    <div class="rounded-2xl bg-teal-100 border border-teal-200 p-3 text-sm text-teal-800">
                        This additional verification helps prevent unauthorized access to the ballot.
                    </div>
                </div>
                <div class="modal-footer border-0 bg-white p-5 pt-3">
                    <button type="button" class="btn btn-secondary rounded-full px-4 py-2" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn rounded-full px-4 py-2 text-white" style="background-color:#0f766e; border:none;">Proceed</button>
                </div>
            </form>
        </div>
    </div>
</div>

  <!-- ── Voter Info Bar ── -->
  <div class="voter-bar">
    <div class="voter-avatar">
      <?php if (!empty($voter['photo_url'])): ?>
        <img src="<?= htmlspecialchars($voter['photo_url']) ?>" alt="">
      <?php else: ?>
        <i class="fas fa-user"></i>
      <?php endif; ?>
    </div>
    <div class="voter-meta">
      <h1>
        <?= htmlspecialchars($voter['full_name'] ?? 'Voter') ?>
        <span id="session-countdown" class="session-timer">10:00</span>
      </h1>
      <p><?= htmlspecialchars($voter['nid'] ?? 'N/A') ?> | ID: <?= htmlspecialchars($voter['voter_id'] ?? 'N/A') ?></p>
    </div>
    
    <div class="voter-actions">
      <a href="<?= BASE_URL ?>/voter/logout" class="btn-logout" style="margin-right: 8px;">
        <i class="fas fa-sign-out-alt"></i> Logout
      </a>
      <div class="constituency-badge">
        <small>Constituency</small>
        <strong><?= htmlspecialchars($voter['constituency_name'] ?? 'N/A') ?></strong>
      </div>
    </div>
  </div>

  <!-- ── Alerts ── -->
  <?php if (!empty($_GET['success']) && isset($successMap[$_GET['success']])): ?>
  <div class="alert-wrap">
    <div class="alert-success">
      <i class="fas fa-check-circle ic"></i>
      <div>
        <p class="msg"><?= $successMap[$_GET['success']] ?></p>
        <?php if (!empty($_GET['receipt'])): ?>
        <div class="receipt-box">
          <small>Receipt Code</small>
          <span><?= htmlspecialchars($_GET['receipt']) ?></span>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <?php if (!empty($_GET['error']) && isset($errorMap[$_GET['error']])): ?>
  <div class="alert-wrap">
    <div class="alert-error">
      <i class="fas fa-exclamation-circle"></i>
      <p><?= $errorMap[$_GET['error']] ?></p>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── Pools ── -->
  <div class="pools-wrap">
    <h2>Active Voting Pools</h2>

    <?php if (empty($groupedElections)): ?>
      <div class="empty-pools">No active voting pools</div>

    <?php else: ?>
      <?php foreach ($groupedElections as $election):
        $fptpPool = $election['fptp_pool'];
        $prPool   = $election['pr_pool'];
        $mainPool = $fptpPool ?: $prPool;
        
        $directCandidates       = $election['fptp_candidates'];
        $proportionalCandidates = $election['pr_candidates'];
      ?>

      <div class="election-wrapper">
        <!-- Direct Candidate Card -->
        <div class="ballot-card <?= !$fptpPool ? 'opacity-50' : '' ?>">
          <div class="ballot-card-header">
            <div>
              <h3><?= htmlspecialchars($fptpPool['title'] ?? 'Direct Election') ?></h3>
              <?php if ($fptpPool): ?><small>Ends: <?= date('M d, Y H:i', strtotime($fptpPool['voting_end'])) ?></small><?php endif; ?>
            </div>
            <span class="pool-type-badge">FPTP</span>
          </div>

          <div class="ballot-panel">
            <div class="panel-header">
              <span class="panel-title">Direct Candidate</span>
              <span class="panel-timer"><i class="fas fa-clock" style="font-size:10px;"></i> <?= $fptpPool ? 'Live' : 'N/A' ?></span>
            </div>

            <div class="candidates-scroll" id="direct-<?= $fptpPool['id'] ?? 'none' ?>">
              <?php if (!$fptpPool): ?>
                <div class="no-candidates">Not applicable for this ballot.</div>
              <?php elseif (empty($directCandidates)): ?>
                <div class="no-candidates">No candidates assigned yet.</div>
              <?php else: ?>
                <?php foreach ($directCandidates as $cand): ?>
                <div class="candidate-card">
                  <div class="cand-photo" style="background: white; display: flex; align-items: center; justify-content: center; overflow: hidden; border: 1px solid #e2e8f0;">
                    <?php 
                      $pName = $cand['party_name'] ?? 'Independent';
                      $pLogo = !empty($cand['party_logo']) ? $cand['party_logo'] : '';
                      $cPhoto = !empty($cand['photo_url']) ? $cand['photo_url'] : '';
                      
                      // Prioritize party logo for all candidates
                      $lUrlRaw = !empty($pLogo) ? $pLogo : (!empty($cPhoto) ? $cPhoto : '');
                      
                      if (empty($lUrlRaw)) {
                          $lUrl = "https://ui-avatars.com/api/?name=" . urlencode($pName) . "&background=2d8f9f&color=fff&size=128&bold=true";
                      } else {
                          // Handle external links vs local assets
                          $lUrl = (filter_var($lUrlRaw, FILTER_VALIDATE_URL)) ? $lUrlRaw : asset($lUrlRaw);
                      }
                    ?>
                    <img src="<?= htmlspecialchars($lUrl) ?>" alt="" style="width: 100%; height: 100%; object-fit: contain;" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                    <div class="w-full h-full flex items-center justify-center bg-slate-100 text-[12px] font-black text-slate-400" style="display:none">
                        <?= htmlspecialchars(strtoupper(substr($pName, 0, 1))) ?>
                    </div>
                  </div>
                  <div class="cand-info">
                    <div class="cand-name"><?= htmlspecialchars($cand['full_name']) ?></div>
                    <div class="cand-party"><?= htmlspecialchars($cand['party_name'] ?? '') ?></div>
                  </div>
                </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>

            <div class="panel-actions" style="margin-top: auto;">
              <?php if ($fptpPool && $fptpPool['voted']): ?>
                <span class="already-voted-badge"><i class="fas fa-check-circle"></i> Voted</span>
              <?php elseif ($fptpPool): ?>
                <button type="button" onclick="openVerifyModal(<?= $fptpPool['id'] ?>)" class="btn-vote-now">
                  <i class="fas fa-vote-yea"></i> Vote Now
                </button>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <!-- Proportional Candidate Card -->
        <div class="ballot-card <?= !$prPool ? 'opacity-50' : '' ?>">
          <div class="ballot-card-header">
            <div>
              <h3><?= htmlspecialchars($prPool['title'] ?? 'Proportional Election') ?></h3>
              <?php if ($prPool): ?><small>Ends: <?= date('M d, Y H:i', strtotime($prPool['voting_end'])) ?></small><?php endif; ?>
            </div>
            <span class="pool-type-badge">PR</span>
          </div>

          <div class="ballot-panel">
            <div class="panel-header">
              <span class="panel-title">Proportional Candidate</span>
              <span class="panel-timer"><i class="fas fa-clock" style="font-size:10px;"></i> <?= $prPool ? 'Live' : 'N/A' ?></span>
            </div>

            <div class="candidates-scroll" id="prop-<?= $prPool['id'] ?? 'none' ?>">
              <?php if (!$prPool): ?>
                <div class="no-candidates">Not applicable for this ballot.</div>
              <?php elseif (empty($proportionalCandidates)): ?>
                <div class="no-candidates">No parties assigned yet.</div>
              <?php else: ?>
                <?php foreach ($proportionalCandidates as $cand): ?>
                <div class="candidate-card">
                  <div class="cand-photo" style="background: white; display: flex; align-items: center; justify-content: center; overflow: hidden; border: 1px solid #e2e8f0;">
                    <?php 
                      $pName = $cand['full_name'] ?? 'Party';
                      $pLogo = !empty($cand['party_logo']) ? $cand['party_logo'] : '';
                      
                      if (empty($pLogo)) {
                          $lUrl = "https://ui-avatars.com/api/?name=" . urlencode($pName) . "&background=2d8f9f&color=fff&size=128&bold=true";
                      } else {
                          $lUrl = (filter_var($pLogo, FILTER_VALIDATE_URL)) ? $pLogo : asset($pLogo);
                      }
                    ?>
                    <img src="<?= htmlspecialchars($lUrl) ?>" alt="" style="width: 100%; height: 100%; object-fit: contain;" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                    <div class="w-full h-full flex items-center justify-center bg-slate-100 text-[12px] font-black text-slate-400" style="display:none">
                        <?= htmlspecialchars(strtoupper(substr($pName, 0, 1))) ?>
                    </div>
                  </div>
                  <div class="cand-info">
                    <div class="cand-name"><?= htmlspecialchars($cand['full_name']) ?></div>
                    <div class="cand-party"><?= htmlspecialchars($cand['party_name'] ?? '') ?></div>
                  </div>
                </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>

            <div class="panel-actions" style="margin-top: auto;">
              <?php if ($prPool && $prPool['voted']): ?>
                <span class="already-voted-badge"><i class="fas fa-check-circle"></i> Voted</span>
              <?php elseif ($prPool): ?>
                <button type="button" onclick="openVerifyModal(<?= $prPool['id'] ?>)" class="btn-vote-now">
                  <i class="fas fa-vote-yea"></i> Vote Now
                </button>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>

      <?php endforeach; ?>
    <?php endif; ?>
  </div>

</div><!-- /ovms-dashboard -->

<script>
function openVerifyModal(poolId) {
  document.getElementById('verifyPoolId').value = poolId;
  const modalEl = document.getElementById('voteVerifyModal');
  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

// Session Countdown
(function() {
  let timeLeft = <?= (int)($_SESSION['last_activity'] + Auth::VOTER_TIMEOUT - time()) ?>;
  const display = document.getElementById('session-countdown');
  if (!display) return;

  function update() {
    if (timeLeft <= 0) {
      window.location.href = '<?= BASE_URL ?>/voter/logout?error=timeout';
      return;
    }
    const m = Math.floor(timeLeft / 60);
    const s = timeLeft % 60;
    display.innerText = `${m}:${s.toString().padStart(2, '0')}`;
    timeLeft--;
  }
  update();
  setInterval(update, 1000);
})();
</script>
