<?php $step = $step ?? 'grid'; ?>

<main class="max-w-5xl mx-auto px-4 py-6">

<!-- HEADER -->
<div class="bg-white rounded-lg shadow border mb-6 overflow-hidden">
    <div class="bg-gradient-to-r from-teal-600 to-teal-500 px-6 py-4 text-white">
        <h1 class="text-2xl font-bold"><?= htmlspecialchars($pool['title']) ?></h1>
        <p class="text-sm text-teal-100">
            Voting Ends: <?= date('M d, Y H:i', strtotime($pool['voting_end'])) ?>
        </p>
    </div>
</div>

<!-- STEP INDICATOR -->
<div class="flex mb-6 text-sm font-semibold">
    <div class="flex-1 text-center pb-2 border-b-4 <?= $step==='grid' ? 'border-teal-600 text-teal-600' : 'border-gray-300 text-gray-400' ?>">
        1. Select
    </div>
    <div class="flex-1 text-center pb-2 border-b-4 <?= $step==='summary' ? 'border-teal-600 text-teal-600' : 'border-gray-300 text-gray-400' ?>">
        2. Review
    </div>
    <div class="flex-1 text-center pb-2 border-b-4 <?= $step==='confirm' ? 'border-teal-600 text-teal-600' : 'border-gray-300 text-gray-400' ?>">
        3. Receipt
    </div>
</div>

<!-- ================= GRID (Step 1) ================= -->
<?php if ($step === 'grid'): ?>

<form method="POST" action="<?= BASE_URL ?>/voter/ballot/submit" id="ballotForm">
<input type="hidden" name="step" value="summary">
<input type="hidden" name="pool_id" value="<?= (int)$poolId ?>">
        <?php if ($pool['pool_type'] === 'pr'): ?>
            <input type="hidden" name="party_id" id="selectedParty" value="">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
            <?php foreach ($parties as $party): 
                $partyAbbr = strtoupper(substr($party['abbreviation'] ?? $party['party_name'] ?? 'IND', 0, 3));
            ?>
            <div class="party-card candidate-card relative cursor-pointer border-2 border-gray-200 rounded-3xl p-4 text-left transition-all hover:border-teal-400 hover:shadow-xl select-none bg-white flex flex-row items-center justify-between"
                 data-party-id="<?= (int)$party['party_id'] ?>">
                
                <div class="flex items-center gap-4">
                    <div class="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center overflow-hidden border border-slate-200 shrink-0">
                        <?php 
                          $pName = $party['party_name'] ?? 'Party';
                          $lUrl = !empty($party['symbol_url']) ? $party['symbol_url'] : '';
                          if (empty($lUrl)) {
                              $lUrl = "https://ui-avatars.com/api/?name=" . urlencode($pName) . "&background=2d8f9f&color=fff&size=128&bold=true";
                          } else if (!filter_var($lUrl, FILTER_VALIDATE_URL) && !str_starts_with($lUrl, '/')) {
                              $lUrl = BASE_URL . '/' . ltrim($lUrl, '/');
                          }
                        ?>
                        <img src="<?= htmlspecialchars($lUrl) ?>" alt="Party symbol" class="w-full h-full object-contain p-1.5" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" />
                        <span class="text-sm font-bold text-teal-700" style="display:none"><?= htmlspecialchars(strtoupper(substr($pName, 0, 1))) ?></span>
                    </div>
                    <div>
                        <h3 class="text-[13px] font-bold text-slate-900 leading-tight pr-2"><?= htmlspecialchars($party['party_name']) ?></h3>
                        <?php if (!empty($party['abbreviation'])): ?>
                        <p class="text-[10px] text-slate-500 uppercase tracking-widest mt-1"><?= htmlspecialchars($party['abbreviation']) ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Stamp Box -->
                <div class="w-12 h-12 ml-2 rounded border-2 border-dashed border-gray-300 shrink-0 flex items-center justify-center relative bg-slate-50">
                    <div class="tick hidden text-teal-600">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="square" stroke-linejoin="miter">
                            <circle cx="12" cy="12" r="10" stroke-width="1.5"></circle>
                            <path d="M12 12 V6.5 H17 M12 12 V17.5 H7 M12 12 H7 V6.5 M12 12 H17 V17.5"/>
                        </svg>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            </div>
        <?php else: ?>
            <input type="hidden" name="pool_candidate_id" id="selectedCandidate" value="">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
            <?php foreach ($candidates as $candidate):
                $partyAbbr = strtoupper(substr($candidate['abbreviation'] ?? $candidate['party_name'] ?? 'IND', 0, 3));
            ?>
            <div class="candidate-card relative cursor-pointer border-2 border-gray-200 rounded-3xl p-4 text-left transition-all hover:border-teal-400 hover:shadow-xl select-none bg-white flex flex-row items-center justify-between"
                 data-id="<?= (int)$candidate['pool_candidate_id'] ?>">

                <div class="flex items-center gap-4">
                    <div class="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center overflow-hidden border border-slate-200 shrink-0">
                        <?php 
                          $pName = $candidate['party_name'] ?? 'Independent';
                          $lUrl = !empty($candidate['symbol_url']) ? $candidate['symbol_url'] : '';
                          if (empty($lUrl)) {
                              $lUrl = "https://ui-avatars.com/api/?name=" . urlencode($pName) . "&background=2d8f9f&color=fff&size=128&bold=true";
                          } else if (!filter_var($lUrl, FILTER_VALIDATE_URL) && !str_starts_with($lUrl, '/')) {
                              $lUrl = BASE_URL . '/' . ltrim($lUrl, '/');
                          }
                        ?>
                        <img src="<?= htmlspecialchars($lUrl) ?>" alt="Party symbol" class="w-full h-full object-contain p-1.5" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" />
                        <span class="text-sm font-bold text-teal-700" style="display:none"><?= htmlspecialchars(strtoupper(substr($pName, 0, 1))) ?></span>
                    </div>

                    <div>
                        <p class="text-[10px] text-slate-400 uppercase tracking-widest mb-0.5"><?= htmlspecialchars($pName) ?></p>
                        <h3 class="text-[13px] font-bold text-slate-900 leading-tight pr-2"><?= htmlspecialchars($candidate['candidate_name']) ?></h3>
                        <p class="text-[10px] text-slate-500 mt-1">Ballot #<?= (int)($candidate['ballot_order'] ?? 0) ?></p>
                    </div>
                </div>

                <!-- Stamp Box -->
                <div class="w-12 h-12 ml-2 rounded border-2 border-dashed border-gray-300 shrink-0 flex items-center justify-center relative bg-slate-50">
                    <div class="tick hidden text-teal-600">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="square" stroke-linejoin="miter">
                            <circle cx="12" cy="12" r="10" stroke-width="1.5"></circle>
                            <path d="M12 12 V6.5 H17 M12 12 V17.5 H7 M12 12 H7 V6.5 M12 12 H17 V17.5"/>
                        </svg>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- No selection warning -->
        <div id="noSelectionWarning" class="hidden mt-4 bg-amber-50 border border-amber-300 text-amber-700 text-sm px-4 py-2 rounded">
            ⚠️ Please select a candidate before proceeding.
        </div>

        <!-- ACTIONS -->
        <div class="flex gap-3 mt-6">
            <a href="<?= BASE_URL ?>/voter/dashboard"
               class="flex-1 text-center bg-gray-200 hover:bg-gray-300 text-gray-700 py-3 rounded-lg font-medium transition">
               ← Cancel
            </a>
            <button type="submit" id="nextBtn"
                class="flex-1 bg-teal-600 hover:bg-teal-700 text-white py-3 rounded-lg font-semibold transition shadow disabled:opacity-40 disabled:cursor-not-allowed"
                disabled>
                Next →
            </button>
        </div>
    </div>
</div>
</form>

<style>
.candidate-card { position: relative; }
.candidate-card.selected .tick { display: block !important; }
.party-card.selected { border-color: #0d9488; background-color: #f0fdfa; }
.candidate-card:not(.party-card).selected { border-color: #0d9488; background-color: #f0fdfa; }
</style>

<script>
(function() {
    const cards = document.querySelectorAll('.candidate-card');
    const hiddenCandidate = document.getElementById('selectedCandidate');
    const hiddenParty = document.getElementById('selectedParty');
    const nextBtn = document.getElementById('nextBtn');
    const warning = document.getElementById('noSelectionWarning');

    cards.forEach(card => {
        card.addEventListener('click', () => {
            // Deselect all
            cards.forEach(c => {
                c.classList.remove('selected');
                const t = c.querySelector('.tick');
                if (t) t.classList.add('hidden');
            });

            // Select clicked
            card.classList.add('selected');
            const tick = card.querySelector('.tick');
            if (tick) tick.classList.remove('hidden');

            if (hiddenCandidate) hiddenCandidate.value = card.dataset.id || '';
            if (hiddenParty) hiddenParty.value = card.dataset.partyId || '';
            
            nextBtn.disabled = false;
            warning.classList.add('hidden');
        });
    });

    // Guard: prevent submit without selection
    document.getElementById('ballotForm').addEventListener('submit', function(e) {
        const val = (hiddenCandidate ? hiddenCandidate.value : '') || (hiddenParty ? hiddenParty.value : '');
        if (!val) {
            e.preventDefault();
            warning.classList.remove('hidden');
        }
    });
})();
</script>

<?php endif; ?>

<!-- ================= SUMMARY (Step 2) ================= -->
<?php if ($step === 'summary' && isset($selected)): ?>

<form method="POST" action="<?= BASE_URL ?>/voter/ballot/submit">
<input type="hidden" name="step" value="confirm">
<input type="hidden" name="pool_id" value="<?= (int)$poolId ?>">
<?php if ($pool['pool_type'] === 'pr'): ?>
    <input type="hidden" name="party_id" value="<?= (int)$selected['party_id'] ?>">
<?php else: ?>
    <input type="hidden" name="pool_candidate_id" value="<?= (int)$selected['pool_candidate_id'] ?>">
<?php endif; ?>

<div class="bg-white border rounded-3xl p-6 shadow-lg">

    <div class="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
            <h2 class="text-2xl font-bold text-slate-900">Review Your Selection</h2>
            <p class="text-sm text-slate-500 mt-2">Confirm the candidate details and final vote summary before casting.</p>
        </div>
        <span class="inline-flex items-center gap-2 rounded-full bg-teal-100 px-4 py-2 text-teal-700 text-sm font-semibold">
            Step 2 of 3
        </span>
    </div>

    <div class="max-w-2xl mx-auto mt-6">
        <!-- Main Confirmation Card -->
        <div class="bg-slate-50 border border-slate-200 rounded-3xl p-6 mb-6">
            <h3 class="text-center text-sm font-bold text-slate-500 uppercase tracking-widest mb-6">Selected Choice</h3>
            
            <div class="flex flex-col items-center justify-center text-center">
                <div class="w-24 h-24 rounded-full bg-white flex items-center justify-center overflow-hidden border-4 border-teal-100 shadow-md mb-4">
                    <?php if (!empty($selected['photo_path'])): ?>
                        <img src="<?= htmlspecialchars($selected['photo_path']) ?>" alt="Candidate photo" class="w-full h-full object-cover" />
                    <?php elseif (!empty($selected['symbol_url'])): ?>
                        <img src="<?= htmlspecialchars($selected['symbol_url']) ?>" alt="Party symbol" class="w-full h-full object-contain p-3" />
                    <?php else: ?>
                        <span class="text-3xl font-bold text-teal-700"><?= htmlspecialchars(strtoupper(substr($selected['abbreviation'] ?? $selected['party_name'] ?? 'IND', 0, 3))) ?></span>
                    <?php endif; ?>
                </div>
                
                <?php if (isset($selected['party_id']) && !isset($selected['candidate_name'])): ?>
                    <h3 class="text-2xl font-bold text-slate-900"><?= htmlspecialchars($selected['party_name']) ?></h3>
                    <p class="text-sm font-semibold text-teal-600 uppercase tracking-widest mt-1"><?= htmlspecialchars($selected['abbreviation']) ?></p>
                <?php else: ?>
                    <h3 class="text-2xl font-bold text-slate-900"><?= htmlspecialchars($selected['candidate_name']) ?></h3>
                    <p class="text-sm font-semibold text-teal-600 mt-1"><?= htmlspecialchars($selected['party_name'] ?? 'Independent') ?></p>
                <?php endif; ?>
            </div>
            
            <div class="border-t border-slate-200 mt-6 pt-6">
                <div class="grid grid-cols-2 gap-y-4 text-sm">
                    <div>
                        <p class="text-slate-400 text-[10px] uppercase tracking-widest font-bold">Voter Name</p>
                        <p class="text-slate-900 font-semibold mt-0.5"><?= htmlspecialchars($_SESSION['user']['name'] ?? 'Anonymous Voter') ?></p>
                    </div>
                    <div>
                        <p class="text-slate-400 text-[10px] uppercase tracking-widest font-bold">Voter ID</p>
                        <p class="text-slate-900 font-semibold mt-0.5"><?= htmlspecialchars($_SESSION['user']['voter_id'] ?? 'N/A') ?></p>
                    </div>
                    <div>
                        <p class="text-slate-400 text-[10px] uppercase tracking-widest font-bold">Election Pool</p>
                        <p class="text-slate-900 font-semibold mt-0.5"><?= htmlspecialchars($pool['title']) ?></p>
                    </div>
                    <div>
                        <p class="text-slate-400 text-[10px] uppercase tracking-widest font-bold">Timestamp</p>
                        <p class="text-slate-900 font-semibold mt-0.5"><?= date('Y-m-d H:i:s') ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mb-8 px-4">
            <p class="text-sm text-slate-500">Your vote will be securely encrypted and anonymously recorded. This action cannot be undone.</p>
        </div>

    <div class="flex flex-col gap-3 sm:flex-row mt-6 max-w-2xl mx-auto">
        <a href="<?= BASE_URL ?>/voter/ballot?pool_id=<?= (int)$poolId ?>"
           class="flex-1 text-center bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 py-3.5 rounded-2xl font-bold transition">
            ← Change Selection
        </a>
        <button type="submit"
            class="flex-1 bg-teal-600 hover:bg-teal-700 text-white py-3.5 rounded-2xl font-bold transition shadow-md">
            <i class="fas fa-lock mr-2"></i> Confirm Vote
        </button>
    </div>
</div>
</form>

<?php endif; ?>

<!-- ================= RECEIPT (Step 3) ================= -->
<?php if ($step === 'confirm'): ?>

<div class="bg-white border-2 <?= isset($success) && $success ? 'border-green-400' : 'border-red-300' ?> rounded-xl p-8 text-center shadow">

<?php if (isset($success) && $success): ?>

    <div class="w-20 h-20 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
        <i class="fas fa-check text-3xl text-green-600"></i>
    </div>
    <h2 class="text-2xl font-bold text-green-700 mb-2">Vote Cast Successfully!</h2>
    <p class="text-gray-500 mb-5">Your vote has been recorded securely and anonymously.</p>

    <div class="bg-green-50 border border-green-300 rounded-xl p-5 inline-block mb-6">
        <p class="text-xs text-green-600 font-semibold uppercase tracking-wider mb-1">Your Receipt Code</p>
        <p class="font-mono text-xl font-bold text-green-800 tracking-widest"><?= htmlspecialchars($receipt ?? '') ?></p>
        <p class="text-xs text-gray-400 mt-2">Keep this code for your records</p>
    </div>

    <p class="text-sm text-gray-500 mb-6">You will be redirected to the dashboard in <span id="countdown" class="font-bold text-teal-600">5</span> seconds.</p>

    <script>
    (function(){
        let sec = 5;
        const el = document.getElementById('countdown');
        const iv = setInterval(() => {
            sec--;
            if (el) el.textContent = sec;
            if (sec <= 0) {
                clearInterval(iv);
                window.location.href = '<?= BASE_URL ?>/voter/dashboard';
            }
        }, 1000);
    })();
    </script>

<?php else: ?>

    <div class="w-20 h-20 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center">
        <i class="fas fa-exclamation-triangle text-3xl text-red-500"></i>
    </div>
    <h2 class="text-xl font-bold text-red-600 mb-2">Vote Not Recorded</h2>
    <p class="text-gray-500 mb-5">
        <?= htmlspecialchars($error_msg ?? 'You may have already voted in this pool.') ?>
    </p>

<?php endif; ?>

<a href="<?= BASE_URL ?>/voter/dashboard"
   class="inline-block bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 rounded-lg font-semibold shadow transition">
   ← Back to Dashboard
</a>

</div>

<?php endif; ?>

</main>
