<?php /* TODO: Build the Vote Receipt view */ ?>
<div class="container-fluid py-4">
    <h4><?= htmlspecialchars($title ?? 'Vote Receipt') ?></h4>
    <!-- TODO: Add your HTML here -->
</div>
