<main class="max-w-5xl mx-auto px-4 py-4 md:py-8 animate-slide-up">
    <!-- Header -->
    <div class="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
            <p class="text-[10px] font-black uppercase tracking-[0.3em] text-[#2d8f9f] mb-2">Voter Identity</p>
            <h1 class="text-3xl md:text-4xl font-black text-slate-900 tracking-tight leading-none"><?= htmlspecialchars($voter['full_name'] ?? 'Authorized Voter') ?></h1>
            <p class="text-sm text-slate-400 mt-3 font-medium">Official registration details as recorded by the Election Commission.</p>
        </div>
        <div class="flex gap-3">
            <a href="<?= BASE_URL ?>/voter/dashboard" class="flex-1 md:flex-none inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-[10px] font-black uppercase tracking-widest text-slate-500 hover:bg-slate-50 transition no-underline">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
            <a href="<?= BASE_URL ?>/voter/results" class="flex-1 md:flex-none inline-flex items-center justify-center gap-2 rounded-2xl bg-[#2d8f9f] px-5 py-3 text-[10px] font-black uppercase tracking-widest text-white hover:bg-[#267a88] shadow-lg shadow-[#2d8f9f]/20 transition no-underline">
                <i class="fas fa-chart-line"></i> Results
            </a>
        </div>
    </div>

    <div class="grid gap-8 md:grid-cols-12">
        <!-- Sidebar / Visual Info (Top on mobile, Side on desktop) -->
        <div class="md:col-span-5 lg:col-span-4 space-y-6">
            <div class="bg-gradient-to-br from-[#2d8f9f] to-[#1c2b3a] rounded-[40px] p-8 text-white relative overflow-hidden shadow-2xl">
                <div class="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                
                <div class="relative z-10">
                    <div class="w-24 h-24 rounded-3xl bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center mb-6 overflow-hidden shadow-xl">
                        <?php if (!empty($voter['photo_url'])): ?>
                            <img src="<?= htmlspecialchars($voter['photo_url']) ?>" class="w-full h-full object-cover" alt="">
                        <?php else: ?>
                            <i class="fas fa-user text-3xl opacity-50"></i>
                        <?php endif; ?>
                    </div>
                    
                    <p class="text-[9px] font-black uppercase tracking-[0.4em] opacity-60 mb-2">Official Voter ID</p>
                    <p class="text-2xl font-black tracking-tight mb-6"><?= htmlspecialchars($voter['voter_id'] ?? 'N/A') ?></p>
                    
                    <div class="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10">
                        <p class="text-[8px] font-black uppercase tracking-widest opacity-60 mb-1">Status</p>
                        <div class="flex items-center gap-2">
                            <div class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></div>
                            <span class="text-[10px] font-black uppercase">Verified Active</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Help Card -->
            <div class="bg-slate-900 rounded-[32px] p-8 text-white shadow-xl">
                <h3 class="text-xs font-black uppercase tracking-widest mb-4">Security Note</h3>
                <p class="text-[11px] text-slate-400 leading-relaxed">Your data is synchronized with the National Identity Registry. If you find any discrepancies, please contact your local Election Office.</p>
                <div class="mt-6 pt-6 border-t border-white/5">
                    <a href="<?= BASE_URL ?>/voter/logout" class="text-rose-400 text-[10px] font-black uppercase tracking-widest no-underline flex items-center gap-2 hover:text-rose-300 transition">
                        <i class="fas fa-sign-out-alt"></i> Logout Securely
                    </a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="md:col-span-7 lg:col-span-8 space-y-6">
            <!-- Personal Info Card -->
            <section class="bg-white rounded-[32px] border border-slate-100 shadow-xl shadow-slate-200/40 p-6 md:p-8">
                <h2 class="text-lg font-black text-slate-900 mb-6 flex items-center gap-3">
                    <span class="w-2 h-2 bg-[#2d8f9f] rounded-full"></span> 
                    Personal Information
                </h2>
                <div class="grid gap-4 sm:grid-cols-2">
                    <div class="rounded-2xl bg-slate-50 p-5 border border-slate-100 transition-all hover:border-[#2d8f9f]/30">
                        <p class="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2">Full Legal Name</p>
                        <p class="font-black text-slate-800 tracking-tight leading-tight"><?= htmlspecialchars($voter['full_name'] ?? 'N/A') ?></p>
                    </div>
                    <div class="rounded-2xl bg-slate-50 p-5 border border-slate-100 transition-all hover:border-[#2d8f9f]/30">
                        <p class="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2">National ID (NID)</p>
                        <p class="font-black text-slate-800 tracking-tight leading-tight"><?= htmlspecialchars($voter['nid'] ?? 'N/A') ?></p>
                    </div>
                    <div class="rounded-2xl bg-slate-50 p-5 border border-slate-100 transition-all hover:border-[#2d8f9f]/30">
                        <p class="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2">Date of Birth</p>
                        <p class="font-black text-slate-800 tracking-tight leading-tight"><?= htmlspecialchars($voter['date_of_birth'] ?? 'N/A') ?></p>
                    </div>
                    <div class="rounded-2xl bg-slate-50 p-5 border border-slate-100 transition-all hover:border-[#2d8f9f]/30">
                        <p class="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2">Citizenship Number</p>
                        <p class="font-black text-slate-800 tracking-tight leading-tight"><?= htmlspecialchars($voter['citizenship_no'] ?? 'N/A') ?></p>
                    </div>
                </div>
            </section>

            <!-- Registration Details -->
            <section class="bg-white rounded-[32px] border border-slate-100 shadow-xl shadow-slate-200/40 p-6 md:p-8">
                <h2 class="text-lg font-black text-slate-900 mb-6 flex items-center gap-3">
                    <span class="w-2 h-2 bg-[#2d8f9f] rounded-full"></span> 
                    Voter Registration
                </h2>
                <div class="space-y-4">
                    <div class="flex items-center justify-between py-4 border-b border-slate-50">
                        <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Constituency</span>
                        <span class="text-sm font-black text-slate-800"><?= htmlspecialchars($voter['constituency_name'] ?? 'N/A') ?></span>
                    </div>
                    <div class="flex items-center justify-between py-4 border-b border-slate-50">
                        <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">District</span>
                        <span class="text-sm font-black text-slate-800"><?= htmlspecialchars($voter['district'] ?? 'N/A') ?></span>
                    </div>
                    <div class="flex items-center justify-between py-4 border-b border-slate-50">
                        <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Municipality / Ward</span>
                        <span class="text-sm font-black text-slate-800"><?= htmlspecialchars($voter['municipality'] ?? 'N/A') ?> &bull; Ward <?= htmlspecialchars($voter['ward_no'] ?? 'N/A') ?></span>
                    </div>
                </div>
            </section>
        </div>
    </div>
</main>

<style>
@keyframes slide-up {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
.animate-slide-up { animation: slide-up 0.6s cubic-bezier(0.16, 1, 0.3, 1); }
</style>
