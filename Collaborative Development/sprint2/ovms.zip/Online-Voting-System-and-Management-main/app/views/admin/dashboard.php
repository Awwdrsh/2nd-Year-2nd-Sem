<?php
$statusMap = [
    'draft'     => 'draft',
    'active'    => 'active',
    'completed' => 'completed',
    'cancelled' => 'cancelled',
];

$statusLabels = array_map('ucfirst', array_column($electionStatusCounts, 'status'));
$statusValues = array_map(fn($r) => (int) $r['count'], $electionStatusCounts);
$poolLabels   = array_column($votesByPool, 'title');
$poolValues   = array_map(fn($r) => (int) $r['vote_count'], $votesByPool);

$kpiCards = [
    ['label' => 'Total Voters',       'key' => 'total_voters',       'sub' => 'Registered in system',         'color' => 'blue',   'icon' => 'fa-users',      'link' => '/admin/voters'],
    ['label' => 'Active Voters',      'key' => 'active_voters',      'sub' => 'Have cast at least 1 vote',    'color' => 'green',  'icon' => 'fa-user-check', 'link' => '/admin/voters'],
    ['label' => 'Total Candidacy',    'key' => 'total_candidacy',    'sub' => 'All candidacy applications',   'color' => 'amber',  'icon' => 'fa-user-tie',   'link' => '/admin/candidates'],
    ['label' => 'Active Pools',       'key' => 'active_pools',       'sub' => 'Pools currently open',         'color' => 'teal',   'icon' => 'fa-layer-group', 'link' => '/admin/pools'],
    ['label' => 'Total Votes Cast',   'key' => 'total_votes_cast',   'sub' => 'Across all pools',             'color' => 'teal',   'icon' => 'fa-poll',        'link' => '/voter/results'],
    ['label' => 'Participation Rate', 'key' => 'participation_rate', 'sub' => 'Active voters / total voters', 'color' => 'slate',  'icon' => 'fa-chart-line'],
    ['label' => 'System Officers',    'key' => 'total_officers',     'sub' => 'Administrative staff',         'color' => 'blue',   'icon' => 'fa-user-shield', 'link' => '/admin/officers'],
    ['label' => 'Political Parties',  'key' => 'total_parties',      'sub' => 'Registered organizations',     'color' => 'green',  'icon' => 'fa-flag',        'link' => '/admin/parties'],
];

// Human-friendly relative time
function relativeTime(string $datetime): string {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)    return 'Just now';
    if ($diff < 3600)  return floor($diff / 60) . 'm ago';
    if ($diff < 86400) return floor($diff / 3600) . 'h ago';
    return date('d M', strtotime($datetime));
}
?>

<!-- Page header -->
<div class="flex items-start justify-between mb-5">
    <div>
        <h4 class="text-[1rem] font-bold text-text-primary m-0 mb-0.5">System Overview</h4>
        <p class="text-[0.76rem] text-text-muted m-0">Live election metrics &mdash; auto-refreshes every 30 seconds</p>
    </div>
    <div class="flex items-center gap-2.5 flex-shrink-0">
        <span class="inline-flex items-center gap-1.5 text-[0.65rem] font-bold tracking-wider px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700" id="live-badge">
            <span class="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse-slow"></span>LIVE
        </span>
        <span class="text-[0.71rem] text-text-muted" id="last-updated">Updated <?= date('H:i:s') ?></span>
    </div>
</div>

<?php if (isset($_GET['success']) && $_GET['success'] === 'db_synced'): ?>
<div class="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-xl mb-4 flex items-center gap-2 text-[0.8rem]">
    <i class="fas fa-check-circle text-emerald-500"></i>
    <span class="font-semibold">Database Synchronized!</span> All schema updates and password migrations have been applied successfully.
</div>
<?php endif; ?>

<!-- KPI cards -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
<?php foreach ($kpiCards as $card):
    $val = $stats[$card['key']];
    $display = $card['key'] === 'participation_rate' ? $val . '%' : number_format($val);
    $domId = 'kpi-' . str_replace('_', '-', $card['key']);
    
    $colorMap = [
        'blue'  => ['bg' => 'bg-blue-50',    'text' => 'text-blue-600',    'bar' => 'bg-blue-500'],
        'green' => ['bg' => 'bg-emerald-50',  'text' => 'text-emerald-600', 'bar' => 'bg-emerald-500'],
        'amber' => ['bg' => 'bg-amber-50',    'text' => 'text-amber-600',   'bar' => 'bg-amber-500'],
        'teal'  => ['bg' => 'bg-teal-50',     'text' => 'text-teal-600',    'bar' => 'bg-teal-500'],
        'slate' => ['bg' => 'bg-slate-100',   'text' => 'text-slate-600',   'bar' => 'bg-slate-500'],
    ];
    $c = $colorMap[$card['color']] ?? $colorMap['teal'];
    
    $tag = isset($card['link']) ? 'a' : 'div';
    $hrefAttr = isset($card['link']) ? 'href="' . BASE_URL . $card['link'] . '"' : '';
?>
    <<?= $tag ?> <?= $hrefAttr ?> class="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-4 shadow-sm transition-all hover:border-primary/30 no-underline group">
        <div class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 <?= $c['bg'] ?> <?= $c['text'] ?>">
            <i class="fas <?= $card['icon'] ?> text-[0.85rem]"></i>
        </div>
        <div class="flex-1 min-w-0">
            <div class="text-[0.6rem] font-bold tracking-widest uppercase text-text-muted mb-0.5"><?= $card['label'] ?></div>
            <div class="text-[1.2rem] font-bold text-text-primary leading-none mb-0.5 tabular-nums" id="<?= $domId ?>"><?= $display ?></div>
            <div class="text-[0.65rem] text-text-muted"><?= $card['sub'] ?></div>
            <?php if ($card['key'] === 'participation_rate'): ?>
            <div class="h-1 bg-slate-100 rounded mt-1.5 overflow-hidden">
                <div class="h-full rounded <?= $c['bar'] ?> transition-all duration-500" id="participation-bar"
                     data-pct="<?= min($val, 100) ?>" style="width: 0;"></div>
            </div>
            <?php endif; ?>
        </div>
    </<?= $tag ?>>
<?php endforeach; ?>
</div>

<!-- Main content row: Charts -->
<div class="grid grid-cols-1 xl:grid-cols-12 gap-4 mb-6">
    <!-- Charts section -->
    <div class="xl:col-span-12 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div class="px-4 py-2.5 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                <h6 class="text-[0.7rem] font-bold text-text-primary uppercase tracking-wide m-0">Elections Status</h6>
                <i class="fas fa-chart-pie text-slate-400 text-[0.8rem]"></i>
            </div>
            <div class="p-3 h-[260px] flex items-center justify-center">
                <?php if (empty($electionStatusCounts)): ?>
                    <span class="text-[0.7rem] text-text-muted italic">No data available</span>
                <?php else: ?>
                    <canvas id="chartStatus" class="max-w-full"></canvas>
                <?php endif; ?>
            </div>
        </div>
        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div class="px-4 py-2.5 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                <h6 class="text-[0.7rem] font-bold text-text-primary uppercase tracking-wide m-0">Votes per Pool</h6>
                <i class="fas fa-chart-bar text-slate-400 text-[0.8rem]"></i>
            </div>
            <div class="p-3 h-[260px]">
                <?php if (empty($votesByPool)): ?>
                    <span class="text-[0.7rem] text-text-muted italic">No data available</span>
                <?php else: ?>
                    <canvas id="chartPools" class="max-w-full"></canvas>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Bottom row -->
<div class="grid grid-cols-1 gap-4 mb-4">
    <!-- Recent elections -->
    <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h6 class="text-[0.8rem] font-bold text-text-primary m-0">Recent Elections</h6>
            <a href="<?= BASE_URL ?>/admin/elections" class="text-[0.72rem] font-bold text-primary hover:underline">View all elections &rarr;</a>
        </div>
        <div class="panel-body-flush">
            <table class="ovms-table">
                <thead>
                    <tr>
                        <th class="th-pl">Title</th>
                        <th>Status</th>
                        <th>Start</th>
                        <th>End</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recentElections)): ?>
                    <tr><td colspan="5" class="td-empty">No elections found.</td></tr>
                    <?php else: ?>
                    <?php foreach ($recentElections as $e): ?>
                    <tr>
                        <td class="pl-5 font-semibold text-text-primary"><?= htmlspecialchars($e['title']) ?></td>
                        <td>
                            <span class="status-badge status--<?= $statusMap[$e['status']] ?? 'draft' ?>">
                                <?= ucfirst($e['status']) ?>
                            </span>
                        </td>
                        <td class="td-muted"><?= date('d M Y', strtotime($e['voting_start'])) ?></td>
                        <td class="td-muted"><?= date('d M Y', strtotime($e['voting_end'])) ?></td>
                        <td class="pr-4">
                            <a href="<?= BASE_URL ?>/admin/elections/edit?id=<?= (int) $e['id'] ?>" class="text-[0.73rem] font-semibold text-primary no-underline opacity-80 hover:opacity-100">
                                Manage &rarr;
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Chart scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    <?php if (!empty($electionStatusCounts)): ?>
    new Chart(document.getElementById('chartStatus'), {
        type: 'doughnut',
        data: {
            labels: <?= json_encode(array_map(fn($s) => ucfirst($s ?: 'Unknown'), array_column($electionStatusCounts, 'status'))) ?>,
            datasets: [{
                data: <?= json_encode($statusValues) ?>,
                backgroundColor: ['#5189afff', '#475569', '#5d6a7dff', '#94a3b8'],
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            layout: {
                padding: { top: 15, bottom: 15, left: 15, right: 15 }
            },
            cutout: '65%',
            plugins: {
                legend: {
                    position: 'right',
                    labels: { 
                        padding: 15, 
                        usePointStyle: true,
                        pointStyle: 'circle',
                        font: { size: 11, weight: '500' },
                        boxWidth: 7,
                        boxHeight: 7 
                    }
                }
            }
        }
    });
<?php endif; ?>

<?php if (!empty($votesByPool)): ?>
    new Chart(document.getElementById('chartPools'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($poolLabels) ?>,
            datasets: [{
                data: <?= json_encode($poolValues) ?>,
                backgroundColor: '#54a2ccff',
                borderRadius: 4,
                barThickness: 20
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: { padding: { top: 15, bottom: 0 } },
            plugins: { legend: { display: false } },
            scales: {
                y: { display: false },
                x: { 
                    ticks: { font: { size: 9 }, color: '#64748b' }, 
                    grid: { display: false },
                    border: { display: false }
                }
            }
        }
    });
<?php endif; ?>
});
</script>

<script>
(function () {
    var bar = document.getElementById('participation-bar');
    if (bar) bar.style.width = (bar.dataset.pct || 0) + '%';

    var BASE  = '<?= BASE_URL ?>';
    var badge = document.getElementById('live-badge');

    var kpiMap = {
        'kpi-total-voters':       function (d) { return Number(d.total_voters).toLocaleString(); },
        'kpi-active-voters':      function (d) { return Number(d.active_voters).toLocaleString(); },
        'kpi-total-candidacy':    function (d) { return Number(d.total_candidacy).toLocaleString(); },
        'kpi-active-pools':       function (d) { return Number(d.active_pools).toLocaleString(); },
        'kpi-total-votes-cast':   function (d) { return Number(d.total_votes_cast).toLocaleString(); },
        'kpi-participation-rate': function (d) { return d.participation_rate + '%'; },
        'kpi-total-officers':     function (d) { return Number(d.total_officers).toLocaleString(); },
        'kpi-total-parties':      function (d) { return Number(d.total_parties).toLocaleString(); },
        'kpi-active-elections-count': function (d) { return Number(d.active_elections).toLocaleString(); }
    };

    function refresh() {
        badge.innerHTML = '<span class="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse-slow"></span>UPDATING';

        fetch(BASE + '/admin/stats-api')
            .then(function (r) { return r.json(); })
            .then(function (data) {
                Object.keys(kpiMap).forEach(function (id) {
                    var el = document.getElementById(id);
                    if (el) el.textContent = kpiMap[id](data);
                });
                var b2 = document.getElementById('participation-bar');
                if (b2) b2.style.width = Math.min(data.participation_rate, 100) + '%';

                var now = new Date().toLocaleTimeString();
                document.getElementById('last-updated').textContent = 'Updated ' + now;
                document.getElementById('strip-time').textContent   = now;

                badge.innerHTML = '<span class="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse-slow"></span>LIVE';
            })
            .catch(function () {
                badge.innerHTML = '<span class="inline-block w-1.5 h-1.5 rounded-full bg-red-400"></span>OFFLINE';
            });
    }

    setInterval(refresh, 30000);
})();
</script>
