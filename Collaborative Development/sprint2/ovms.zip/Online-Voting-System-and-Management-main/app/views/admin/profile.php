<div class="mb-6">
    <h4 class="text-[1.1rem] font-bold text-text-primary m-0">Admin Account Profile</h4>
    <p class="text-[0.76rem] text-text-muted m-0">Update your account credentials and personal information</p>
</div>

<?php if ($success): ?>
    <div class="bg-emerald-50 border border-emerald-100 text-emerald-800 px-4 py-3 rounded-xl mb-6 text-[0.8rem] flex items-center gap-2">
        <i class="fas fa-check-circle text-emerald-500"></i>
        <span>
            <?php if ($success === 'profile_updated'): ?>Profile updated successfully.
            <?php elseif ($success === 'password_changed'): ?>Password successfully changed.
            <?php endif; ?>
        </span>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="bg-red-50 border border-red-100 text-red-800 px-4 py-3 rounded-xl mb-6 text-[0.8rem] flex items-center gap-2">
        <i class="fas fa-exclamation-circle text-red-500"></i>
        <span>
            <?php if ($error === 'missing_fields'): ?>Please fill in all required fields.
            <?php elseif ($error === 'email_exists'): ?>This email address is already in use by another administrator.
            <?php elseif ($error === 'password_missing'): ?>All password fields are required.
            <?php elseif ($error === 'password_mismatch'): ?>Passwords do not match.
            <?php elseif ($error === 'current_password_invalid'): ?>Current password is incorrect.
            <?php elseif ($error === 'password_same_as_old'): ?>New password must be different from current password.
            <?php endif; ?>
        </span>
    </div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
    <!-- PERSONAL INFORMATION -->
    <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-3.5 border-b border-slate-100 bg-slate-50/50">
            <h6 class="text-[0.8rem] font-bold text-text-primary uppercase tracking-wide m-0">Personal Information</h6>
        </div>
        <div class="p-5">
            <form action="<?= asset('admin/profile/update') ?>" method="POST">
                <div class="mb-4">
                    <label class="text-[0.65rem] font-bold text-text-muted uppercase tracking-widest block mb-1.5">Full Name</label>
                    <input type="text" name="full_name" value="<?= htmlspecialchars($admin['full_name']) ?>"
                           class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[0.85rem] focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/5 transition-all" required>
                </div>

                <div class="mb-6">
                    <label class="text-[0.65rem] font-bold text-text-muted uppercase tracking-widest block mb-1.5">Contact Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($admin['email']) ?>"
                           class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[0.85rem] focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/5 transition-all" required>
                </div>

                <div class="pt-4 border-t border-slate-100 flex justify-end">
                    <button type="submit" class="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-[0.78rem] font-bold transition-all flex items-center gap-2">
                        Update Information
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- SECURITY: CHANGE PASSWORD -->
    <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-3.5 border-b border-slate-100 bg-slate-50/50">
            <h6 class="text-[0.8rem] font-bold text-text-primary uppercase tracking-wide m-0">Credential Management</h6>
        </div>
        <div class="p-5">
            <form action="<?= asset('admin/profile/password') ?>" method="POST">
                <div class="mb-4">
                    <label class="text-[0.65rem] font-bold text-text-muted uppercase tracking-widest block mb-1.5">Current Password</label>
                    <input type="password" name="current_password" placeholder="Verify current credentials"
                           class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[0.85rem] focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/5 transition-all" required>
                </div>

                <div class="mb-4">
                    <label class="text-[0.65rem] font-bold text-text-muted uppercase tracking-widest block mb-1.5">New Password</label>
                    <input type="password" name="new_password" placeholder="Min. 8 characters"
                           class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[0.85rem] focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/5 transition-all" required>
                </div>

                <div class="mb-6">
                    <label class="text-[0.65rem] font-bold text-text-muted uppercase tracking-widest block mb-1.5">Confirm New Password</label>
                    <input type="password" name="confirm_password" placeholder="Repeat new password"
                           class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[0.85rem] focus:outline-none focus:border-primary/50 focus:ring-4 focus:ring-primary/5 transition-all" required>
                </div>

                <div class="pt-4 border-t border-slate-100 flex justify-end">
                    <button type="submit" class="px-5 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg text-[0.78rem] font-bold transition-all">
                        Change Password
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Footer Info -->
<div class="mt-6 bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center gap-4">
    <div class="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-400">
        <i class="fas fa-shield-halved text-[0.9rem]"></i>
    </div>
    <div class="flex-1">
        <p class="text-[0.78rem] font-bold text-text-primary m-0">Security Protocol Active</p>
        <p class="text-[0.7rem] text-text-muted m-0">
            Account created on <?= date('M d, Y', strtotime($admin['created_at'])) ?>. All sessions and sensitive actions are being monitored and logged.
        </p>
    </div>
</div>
