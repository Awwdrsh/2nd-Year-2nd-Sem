<div class="section-header">
    <div>
        <h4>Voter Registry</h4>
        <p>Register and manage voting eligibility for all verified accounts</p>
    </div>
</div>

<?php
$error = $_GET['error'] ?? '';
$success = $_GET['success'] ?? '';
$name = htmlspecialchars($_GET['name'] ?? '');
?>

<?php if ($error === 'is_candidate'): ?>
    <div class="alert alert-danger"
        style="background:#fff5f5;border:1px solid #fc8181;color:#c53030;padding:12px 16px;border-radius:6px;margin-bottom:16px;">
        <strong><i class="fas fa-exclamation-triangle"></i> Cannot Delete Voter</strong><br>
        <em>
            <?= $name ?>
        </em> is currently registered as a <strong>Candidate</strong>.
        Please remove their candidate status first before deleting this voter account.
    </div>
<?php elseif ($error === 'fk_constraint'): ?>
    <div class="alert alert-danger"
        style="background:#fff5f5;border:1px solid #fc8181;color:#c53030;padding:12px 16px;border-radius:6px;margin-bottom:16px;">
        <strong><i class="fas fa-exclamation-triangle"></i> Cannot Delete Voter</strong><br>
        <em>
            <?= $name ?>
        </em> cannot be deleted because they are linked to other records in the system.
        Remove those links first.
    </div>
<?php elseif ($success === 'deleted'): ?>
    <div class="alert alert-success"
        style="background:#f0fff4;border:1px solid #68d391;color:#276749;padding:12px 16px;border-radius:6px;margin-bottom:16px;">
        <i class="fas fa-check-circle"></i> Voter successfully de-registered.
    </div>
<?php endif; ?>

<form method="GET" action="<?= BASE_URL ?>/admin/voters" class="mb-6 flex flex-wrap gap-3 items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200">
    <div class="flex-1 min-w-[200px]">
        <input type="text" name="search" value="<?= htmlspecialchars($search ?? '') ?>" placeholder="Search name, NID, or Voter ID..." class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary">
    </div>
    <div class="w-40">
        <select name="status" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="">All Statuses</option>
            <option value="active" <?= ($status ?? '') === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="blocked" <?= ($status ?? '') === 'blocked' ? 'selected' : '' ?>>Blocked</option>
        </select>
    </div>
    <div class="w-48">
        <select name="sort" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="newest" <?= ($sort ?? '') === 'newest' ? 'selected' : '' ?>>Newest First</option>
            <option value="oldest" <?= ($sort ?? '') === 'oldest' ? 'selected' : '' ?>>Oldest First</option>
            <option value="name_asc" <?= ($sort ?? '') === 'name_asc' ? 'selected' : '' ?>>Name (A-Z)</option>
            <option value="name_desc" <?= ($sort ?? '') === 'name_desc' ? 'selected' : '' ?>>Name (Z-A)</option>
        </select>
    </div>
    <button type="submit" class="px-5 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors shadow-sm flex items-center gap-2">
        <i class="fas fa-filter"></i> Filter
    </button>
    <?php if (!empty($search) || !empty($status) || ($sort ?? 'newest') !== 'newest'): ?>
        <a href="<?= BASE_URL ?>/admin/voters" class="px-5 py-2 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors border border-slate-200">
            Clear
        </a>
    <?php endif; ?>
</form>

<?php if (empty($voters)): ?>
    <div class="panel">
        <div class="td-empty">
            <i class="fas fa-search block text-3xl opacity-20 mb-3"></i>
            No voters found matching your criteria.
        </div>
    </div>
<?php else: ?>
    <div class="panel">
        <div class="panel-body-flush">
            <table class="ovms-table">
                <thead>
                    <tr>
                        <th class="th-pl">Voter ID</th>
                        <th>Full Name</th>
                        <th>District / Municipality</th>
                        <th>Status</th>
                        <th class="td-pr text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($voters as $voter):
                        $isBlocked = $voter['blocked_until'] && strtotime($voter['blocked_until']) > time();
                        $statusClass = $isBlocked ? 'status--cancelled' : 'status--active';
                        $statusLabel = $isBlocked ? 'Blocked' : 'Active';
                        ?>
                        <tr>
                            <td class="th-pl td-bold"><?= htmlspecialchars($voter['voter_id']) ?></td>
                            <td class="td-medium"><?= htmlspecialchars($voter['full_name']) ?></td>
                            <td class="td-muted">
                                <?= htmlspecialchars($voter['district']) ?> / <?= htmlspecialchars($voter['municipality']) ?>
                            </td>
                            <td>
                                <span class="status-badge <?= $statusClass ?>">
                                    <?= $statusLabel ?>
                                </span>
                            </td>
                            <td class="td-pr text-right">
                                <div class="flex gap-2 justify-end">
                                    <a href="<?= BASE_URL ?>/admin/voters/show?id=<?= $voter['id'] ?>"
                                        class="table-link text-primary" title="Manage Password & Details">
                                        <i class="fas fa-key"></i> Manage
                                    </a>

                                    <a href="<?= BASE_URL ?>/admin/voters/show?id=<?= $voter['id'] ?>" class="table-link"
                                        title="View details">
                                        <i class="fas fa-eye"></i>
                                    </a>

                                    <?php if ($isBlocked): ?>
                                        <a href="<?= BASE_URL ?>/admin/voters/unblock?id=<?= $voter['id'] ?>"
                                            class="table-link text-emerald-600" title="Unblock"
                                            onclick="return confirm('Lift suspension from this account?');">
                                            <i class="fas fa-unlock"></i>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?= BASE_URL ?>/admin/voters/block?id=<?= $voter['id'] ?>"
                                            class="table-link text-amber-500" title="Temporarily Block"
                                            onclick="return confirm('Suspend this account for 24 hours?');">
                                            <i class="fas fa-user-lock"></i>
                                        </a>
                                    <?php endif; ?>

                                    <a href="<?= BASE_URL ?>/admin/voters/delete?id=<?= $voter['id'] ?>"
                                        class="table-link text-red-400" title="Deregister"
                                        onclick="return confirm('DANGEROUS: De-register this voter? This action is permanent and logs to the audit system.');">
                                        <i class="fas fa-user-minus"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if (($totalPages ?? 0) > 1): ?>
            <div class="p-4 border-t border-slate-100 flex flex-wrap justify-between items-center bg-slate-50/50 rounded-b-xl gap-4">
                <div class="text-sm text-slate-500 font-medium">
                    Showing page <?= $page ?> of <?= $totalPages ?> (Total: <?= $totalRows ?? 0 ?>)
                </div>
                <div class="flex gap-1">
                    <?php
                    $qs = $_GET;
                    for ($i = 1; $i <= $totalPages; $i++): 
                        $qs['page'] = $i;
                        $url = BASE_URL . '/admin/voters?' . http_build_query($qs);
                        
                        // Show limited pages with ellipsis (basic logic)
                        if ($totalPages > 7 && $i > 2 && $i < $totalPages - 1 && abs($i - $page) > 1) {
                            if ($i == 3 || $i == $totalPages - 2) {
                                echo '<span class="px-2 py-1 text-slate-400">...</span>';
                            }
                            continue;
                        }
                    ?>
                        <a href="<?= $url ?>" class="min-w-[32px] h-8 flex items-center justify-center px-2 border rounded-md text-sm font-medium transition-colors <?= $i === $page ? 'bg-primary text-white border-primary shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-50 border-slate-200' ?>">
                            <?= $i ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>