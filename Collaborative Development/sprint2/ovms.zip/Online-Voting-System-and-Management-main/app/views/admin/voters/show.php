<div class="section-header">
    <div>
        <h4>Voter Detail — <?= htmlspecialchars($voter['full_name']) ?></h4>
        <p>Verified Citizenship and Account Security Profile</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/voters" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-chevron-left"></i> Back to Registry
        </a>
    </div>
</div>

<?php if (isset($_GET['success']) && $_GET['success'] === 'password_reset'): ?>
    <div class="info-strip mb-4">
        <div class="info-strip-item">
            <i class="fas fa-check-circle info-icon--green"></i>
            <span class="text-emerald-700 font-semibold italic">Voter's password has been successfully updated.</span>
        </div>
    </div>
<?php endif; ?>

<div class="grid grid-cols-2 gap-4">
    <!-- PERSONAL INFORMATION -->
    <div class="panel">
        <div class="panel-header panel-header--bordered">
            <h5 class="panel-title">
                <i class="fas fa-id-card panel-icon--accent"></i>
                Verified Identity
            </h5>
        </div>
        <div class="panel-body space-y-4">
            <div>
                <div class="field-label">Full Name</div>
                <div class="text-[0.95rem] font-semibold text-text-primary"><?= htmlspecialchars($voter['full_name']) ?></div>
            </div>
            <div>
                <div class="field-label">Citizenship Number</div>
                <code class="receipt-code text-[0.9rem]"><?= htmlspecialchars($voter['citizenship_no']) ?></code>
            </div>
            <div>
                <div class="field-label">Date of Birth</div>
                <div class="text-[0.9rem] text-text-primary"><?= date('F d, Y', strtotime($voter['date_of_birth'])) ?></div>
            </div>
            <div>
                <div class="field-label">National ID (NID)</div>
                <div class="text-[0.9rem] text-text-primary"><?= htmlspecialchars($voter['nid']) ?></div>
            </div>
        </div>
    </div>

    <!-- GEOGRAPHIC / CONSTITUENCY -->
    <div class="panel">
        <div class="panel-header panel-header--bordered">
            <h5 class="panel-title">
                <i class="fas fa-location-dot text-teal-500 opacity-80"></i>
                Voting Location
            </h5>
        </div>
        <div class="panel-body space-y-4">
            <div>
                <div class="field-label">Primary District</div>
                <div class="text-[0.95rem] font-semibold text-text-primary"><?= htmlspecialchars($voter['district']) ?></div>
            </div>
            <div>
                <div class="field-label">Municipality / Ward</div>
                <div class="text-[0.9rem] text-text-primary"><?= htmlspecialchars($voter['municipality']) ?> — Ward <?= htmlspecialchars($voter['ward_no']) ?></div>
            </div>
            <div>
                <div class="field-label">Assigned Constituency</div>
                <div class="text-[0.9rem] font-semibold text-primary">
                    <?= htmlspecialchars($voter['constituency_name'] ?? 'Not Assigned') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="panel mt-4">
    <div class="panel-header panel-header--bordered">
        <h5 class="panel-title">
            <i class="fas fa-shield-halved panel-icon--amber"></i>
            Account Security &amp; Status
        </h5>
    </div>
    <div class="panel-body flex items-center justify-between">
        <?php
            $isBlocked = $voter['blocked_until'] && strtotime($voter['blocked_until']) > time();
        ?>
        <div class="flex items-center gap-4">
            <div class="bg-slate-100 p-3 rounded-full text-xl text-text-muted">
                <i class="fas fa-fingerprint"></i>
            </div>
            <div>
                <div class="field-label">Unique Voter ID</div>
                <div class="text-[1.1rem] font-bold text-text-primary tracking-wider"><?= htmlspecialchars($voter['voter_id']) ?></div>
            </div>
        </div>

        <div class="text-right">
            <?php if ($isBlocked): ?>
                <div class="text-[0.8rem] font-bold text-red-600 mb-0.5">SUSPENDED UNTIL</div>
                <div class="text-[0.85rem] text-text-muted"><?= date('M d, Y H:i', strtotime($voter['blocked_until'])) ?></div>
            <?php else: ?>
                <div class="text-[0.8rem] font-bold text-emerald-600 mb-0.5">ACTIVE &amp; ELIGIBLE</div>
                <div class="text-[0.85rem] text-text-muted">Registered on <?= date('M d, Y', strtotime($voter['created_at'])) ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="panel mt-4 border border-amber-200">
    <div class="panel-header bg-amber-50 border-b border-amber-200">
        <h5 class="panel-title text-amber-800">
            <i class="fas fa-key panel-icon--amber"></i>
            Password Management
        </h5>
    </div>
    <div class="panel-body">
        <p class="text-[0.85rem] text-slate-600 mb-4">You can set a custom password for this voter, or leave the field blank to reset their password to the default system format (<code>pwd</code> + <code>NID</code>).</p>
        
        <form action="<?= BASE_URL ?>/admin/voters/reset-password" method="POST" class="flex items-end gap-4" onsubmit="return confirm('Are you sure you want to change this voter\'s password?');">
            <input type="hidden" name="id" value="<?= $voter['id'] ?>">
            
            <div class="flex-1">
                <label class="field-label">New Password (Optional)</label>
                <div class="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-400/20 transition-all">
                    <span class="px-3 text-slate-400 border-r border-slate-300 py-2.5 bg-slate-50">
                        <i class="fas fa-lock text-sm"></i>
                    </span>
                    <input type="text" name="new_password" 
                           class="flex-1 px-3 py-2 text-[0.95rem] border-0 focus:ring-0 focus:outline-none placeholder-slate-300"
                           placeholder="Leave blank to reset to default">
                </div>
            </div>
            
            <button type="submit" class="action-btn action-btn--warning" style="width: auto; margin-bottom: 0;">
                <i class="fas fa-save"></i> Update Password
            </button>
        </form>
    </div>
</div>

<div class="mt-5 flex gap-3">
    <?php if ($isBlocked): ?>
        <a href="<?= BASE_URL ?>/admin/voters/unblock?id=<?= $voter['id'] ?>" class="action-btn action-btn--primary"
           style="width: auto; margin-bottom: 0;" onclick="return confirm('Restore this voter to active status?');">
            <i class="fas fa-unlock"></i> Lift account suspension
        </a>
    <?php else: ?>
        <a href="<?= BASE_URL ?>/admin/voters/block?id=<?= $voter['id'] ?>" class="action-btn action-btn--warning"
           style="width: auto; margin-bottom: 0;" onclick="return confirm('Suspend this account for 24 hours?');">
            <i class="fas fa-user-lock"></i> Suspend account
        </a>
    <?php endif; ?>

    <a href="<?= BASE_URL ?>/admin/voters/delete?id=<?= $voter['id'] ?>" class="action-btn action-btn--outline text-red-500"
       style="width: auto; margin-bottom: 0;" onclick="return confirm('DANGEROUS: De-register this voter? This action is permanent.');">
        <i class="fas fa-user-minus"></i> De-register voter
    </a>
</div>
