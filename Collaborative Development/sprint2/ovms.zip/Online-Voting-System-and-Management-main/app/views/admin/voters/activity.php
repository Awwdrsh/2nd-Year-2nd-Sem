<div class="section-header">
    <div>
        <h4 class="text-xl font-bold text-gray-800">Voter Activity Logs</h4>
        <p class="text-sm text-gray-500">Track voter logins and verify if they have cast their votes</p>
    </div>
    <div class="section-header-actions">
        <form action="<?= asset('admin/voters/activity') ?>" method="GET" class="flex gap-2">
            <div class="relative">
                <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs"></i>
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" 
                       placeholder="Search Name or ID..." 
                       class="pl-9 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all w-64">
            </div>
            <button type="submit" class="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                Filter
            </button>
            <?php if ($search): ?>
                <a href="<?= asset('admin/voters/activity') ?>" class="bg-gray-100 text-gray-600 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors flex items-center">
                    <i class="fas fa-times mr-2"></i> Clear
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="panel mt-6">
    <div class="panel-header panel-header--bordered">
        <h6 class="panel-title">
            <i class="fas fa-clock panel-icon--accent"></i> Recent Activity Log
        </h6>
        <div class="text-[0.7rem] text-gray-400 ml-auto">
            Total: <?= number_format($totalRows) ?> voters
        </div>
    </div>
    <div class="panel-body-flush overflow-x-auto">
        <table class="ovms-table w-full">
            <thead>
                <tr>
                    <th class="th-pl">Voter Details</th>
                    <th>District</th>
                    <th>Last Login</th>
                    <th>Voting Status</th>
                    <th class="td-pr text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($voters)): ?>
                    <tr>
                        <td colspan="5" class="td-empty py-12">
                            <div class="flex flex-col items-center">
                                <i class="fas fa-user-clock text-4xl text-gray-200 mb-3"></i>
                                <p class="text-gray-400 text-sm">No activity records found matching your criteria.</p>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($voters as $v): ?>
                        <tr>
                            <td class="th-pl">
                                <div class="flex flex-col leading-tight">
                                    <span class="text-[0.82rem] font-bold text-gray-800"><?= htmlspecialchars($v['full_name']) ?></span>
                                    <span class="text-[0.65rem] text-gray-400 font-mono"><?= htmlspecialchars($v['voter_id']) ?></span>
                                </div>
                            </td>
                            <td class="text-[0.78rem] text-gray-600 font-medium">
                                <?= htmlspecialchars($v['district'] ?: 'N/A') ?>
                            </td>
                            <td class="text-[0.78rem]">
                                <?php if ($v['last_login']): ?>
                                    <div class="flex flex-col">
                                        <span class="text-gray-700 font-medium"><?= date('M j, Y', strtotime($v['last_login'])) ?></span>
                                        <span class="text-[0.68rem] text-gray-400"><?= date('h:i A', strtotime($v['last_login'])) ?></span>
                                    </div>
                                <?php else: ?>
                                    <span class="text-gray-300 italic text-[0.75rem]">Never logged in</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($v['has_voted']): ?>
                                    <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 text-[0.68rem] font-bold border border-emerald-100 uppercase tracking-tight">
                                        <i class="fas fa-check-circle text-[0.6rem]"></i> Voted
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 text-[0.68rem] font-bold border border-amber-100 uppercase tracking-tight">
                                        <i class="fas fa-hourglass-half text-[0.6rem]"></i> Not Voted
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="td-pr text-right">
                                <a href="<?= asset('admin/voters/show?id=' . $v['id']) ?>" 
                                   class="inline-flex items-center justify-center w-8 h-8 rounded-lg text-slate-400 hover:text-primary hover:bg-primary/5 transition-all"
                                   title="View Profile">
                                    <i class="fas fa-eye text-xs"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
        <div class="px-5 py-4 border-t border-gray-100 bg-gray-50/50 flex items-center justify-between">
            <span class="text-[0.7rem] text-gray-500">
                Page <?= $page ?> of <?= $totalPages ?>
            </span>
            <div class="flex gap-1.5">
                <?php if ($page > 1): ?>
                    <a href="<?= asset('admin/voters/activity?page=' . ($page - 1) . '&search=' . urlencode($search)) ?>" 
                       class="px-3 py-1 bg-white border border-gray-200 rounded text-[0.75rem] font-medium hover:bg-gray-50 transition-colors">
                        Previous
                    </a>
                <?php endif; ?>
                
                <?php if ($page < $totalPages): ?>
                    <a href="<?= asset('admin/voters/activity?page=' . ($page + 1) . '&search=' . urlencode($search)) ?>" 
                       class="px-3 py-1 bg-white border border-gray-200 rounded text-[0.75rem] font-medium hover:bg-gray-50 transition-colors">
                        Next
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
