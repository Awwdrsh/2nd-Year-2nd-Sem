<?php /* TODO: Build the Constituencies view */ ?>
<div class="container-fluid py-4">
    <h4><?= htmlspecialchars($title ?? 'Constituencies') ?></h4>
    <!-- TODO: Add your HTML here -->
</div>
