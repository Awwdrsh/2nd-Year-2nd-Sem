<?php /* TODO: Build the Add Constituency view */ ?>
<div class="container-fluid py-4">
    <h4><?= htmlspecialchars($title ?? 'Add Constituency') ?></h4>
    <!-- TODO: Add your HTML here -->
</div>
