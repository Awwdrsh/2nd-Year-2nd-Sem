<div class="section-header">
    <div>
        <h4>Edit Candidate</h4>
        <p>Modify nomination details and candidate status</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/candidates" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-2">
        <div class="panel">
            <div class="panel-header panel-header--bordered">
                <h5 class="panel-title"><i class="fas fa-user-edit panel-icon--accent"></i> Update Candidate: <?= htmlspecialchars($candidate['citizen_name']) ?></h5>
            </div>
            <div class="panel-body">
                <form action="<?= BASE_URL ?>/admin/candidates/update" method="POST">
                    <input type="hidden" name="id" value="<?= $candidate['id'] ?>">

                    <div class="mb-6 p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-4">
                        <img src="<?= htmlspecialchars($candidate['photo_url'] ?: 'https://ui-avatars.com/api/?name='.$candidate['citizen_name']) ?>" class="w-16 h-16 rounded-lg object-cover border border-slate-300">
                        <div class="flex flex-col">
                            <span class="text-sm font-bold text-slate-800"><?= htmlspecialchars($candidate['citizen_name']) ?></span>
                            <span class="text-xs text-slate-500">Voter ID: <?= htmlspecialchars($candidate['voter_id']) ?></span>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label for="party_id" class="field-label">Political Party</label>
                            <select id="party_id" name="party_id" class="field-input">
                                <option value="0">-- Independent / No Party --</option>
                                <?php foreach ($parties as $p): 
                                    $symbolUrl = $p['symbol_url'];
                                    if ($symbolUrl && !filter_var($symbolUrl, FILTER_VALIDATE_URL) && strpos($symbolUrl, 'data:image') !== 0 && !str_starts_with($symbolUrl, '/')) {
                                        $symbolUrl = BASE_URL . '/' . ltrim($symbolUrl, '/');
                                    }
                                ?>
                                    <option value="<?= $p['id'] ?>" <?= $candidate['party_id'] == $p['id'] ? 'selected' : '' ?> data-symbol="<?= htmlspecialchars($symbolUrl) ?>">
                                        <?= htmlspecialchars($p['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label for="constituency_id" class="field-label">Election Constituency</label>
                            <select id="constituency_id" name="constituency_id" class="field-input" required>
                                <option value="">-- Select Constituency --</option>
                                <?php foreach ($constituencies as $co): ?>
                                    <option value="<?= $co['id'] ?>" <?= $candidate['constituency_id'] == $co['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($co['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="election_type" class="field-label">Election Participation Type</label>
                        <select id="election_type" name="election_type" class="field-input">
                            <option value="fptp" <?= $candidate['election_type'] === 'fptp' ? 'selected' : '' ?>>First Past The Post (FPTP) only</option>
                            <option value="pr" <?= $candidate['election_type'] === 'pr' ? 'selected' : '' ?>>Proportional Representation (PR) only</option>
                            <option value="both" <?= $candidate['election_type'] === 'both' ? 'selected' : '' ?>>Both FPTP and PR</option>
                        </select>
                        <p class="text-[0.71rem] text-text-muted mt-1">Determines which election pools this candidate can be assigned to.</p>
                    </div>

                    <div class="mb-6">
                        <label for="manifesto" class="field-label">Bio / Manifesto</label>
                        <textarea id="manifesto" name="manifesto" class="field-input min-h-[120px]" placeholder="Manifesto details..."><?= htmlspecialchars($candidate['manifesto'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-6">
                        <label class="flex items-center gap-2.5 cursor-pointer">
                            <input type="checkbox" name="is_active" value="1" <?= $candidate['is_active'] ? 'checked' : '' ?>
                                   class="w-4 h-4 rounded border-slate-300 text-primary focus:ring-primary/20">
                            <span class="text-[0.82rem] font-semibold text-text-primary">Candidate is active and appearing on ballots</span>
                        </label>
                    </div>

                    <div class="border-t border-slate-100 pt-4 flex justify-end gap-2.5">
                        <a href="<?= BASE_URL ?>/admin/candidates" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">Cancel</a>
                        <button type="submit" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
                            <i class="fas fa-check"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Live Preview Sidebar -->
    <div class="lg:col-span-1">
        <div class="panel sticky top-[100px]">
            <div class="panel-header panel-header--bordered">
                <h5 class="panel-title"><i class="fas fa-id-card panel-icon--accent"></i> Ballot Preview</h5>
            </div>
            <div class="panel-body text-center py-8">
                <div class="relative inline-block mb-4">
                    <img id="previewPhoto" src="<?= htmlspecialchars($candidate['photo_url'] ?: 'https://ui-avatars.com/api/?name='.$candidate['citizen_name']) ?>" class="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl">
                    <div id="previewPartyBox" class="absolute -bottom-2 -right-2 w-12 h-12 bg-white rounded-full flex items-center justify-center border border-slate-200 shadow-lg <?= !$candidate['party_id'] ? 'hidden' : '' ?>">
                        <img id="previewPartyLogo" src="" class="w-8 h-8 object-contain">
                    </div>
                </div>
                <h3 id="previewName" class="text-xl font-bold text-slate-800"><?= htmlspecialchars($candidate['citizen_name']) ?></h3>
                <p id="previewPartyName" class="text-sm text-slate-500 mb-4">Independent</p>
                <div class="px-6 py-2 bg-primary/10 rounded-full inline-block">
                    <span id="previewConst" class="text-xs font-bold text-primary"><?= htmlspecialchars($candidate['constituency_name']) ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const selectParty = document.getElementById('party_id');
    const selectConst = document.getElementById('constituency_id');
    const previewPartyBox = document.getElementById('previewPartyBox');
    const previewPartyLogo = document.getElementById('previewPartyLogo');
    const previewPartyName = document.getElementById('previewPartyName');
    const previewConst = document.getElementById('previewConst');

    function updatePreview() {
        const option = selectParty.options[selectParty.selectedIndex];
        const symbol = option.getAttribute('data-symbol');
        const name = option.text;

        if(selectParty.value != "0" && symbol) {
            previewPartyBox.classList.remove('hidden');
            previewPartyLogo.src = symbol;
            previewPartyName.innerText = name;
        } else {
            previewPartyBox.classList.add('hidden');
            previewPartyName.innerText = 'Independent';
        }

        previewConst.innerText = selectConst.options[selectConst.selectedIndex].text || 'No Constituency';
    }

    selectParty.addEventListener('change', updatePreview);
    selectConst.addEventListener('change', updatePreview);
    
    // Initial sync
    updatePreview();
});
</script>
