<div class="section-header">
    <div>
        <h4>Add New Candidate</h4>
        <p>Register a voter as an official candidate for upcoming elections</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/candidates" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>
</div>

<?php if (isset($_GET['error'])): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <i class="fas fa-exclamation-circle info-icon--red"></i>
            <span class="text-red-600 font-semibold">
                <?php
                    if ($_GET['error'] === 'missing_fields')    echo "Required fields are missing.";
                    if ($_GET['error'] === 'voter_not_found')   echo "Voter ID not found in the system.";
                    if ($_GET['error'] === 'already_candidate') echo "This voter is already registered as a candidate.";
                ?>
            </span>
        </div>
    </div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-2">
        <div class="panel">
            <div class="panel-header panel-header--bordered">
                <h5 class="panel-title"><i class="fas fa-user-plus panel-icon--accent"></i> Candidate Credentials</h5>
            </div>
            <div class="panel-body">
                <form action="<?= BASE_URL ?>/admin/candidates/store" method="POST" id="candidateForm">
                    <!-- Voter ID Search Section -->
                    <div class="mb-6">
                        <label for="voter_id" class="field-label">Voter Registration ID</label>
                        <div class="flex gap-2">
                            <input type="text" id="voter_id" name="voter_id" class="field-input" required placeholder="Enter Voter ID (e.g. V-123456)">
                            <button type="button" id="btnSearchVoter" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
                                <i class="fas fa-search"></i> Fetch
                            </button>
                        </div>
                        <p class="text-[0.71rem] text-text-muted mt-1">Enter Voter ID to automatically populate citizen details.</p>
                    </div>

                    <!-- Auto-populated Citizen Details (Read-only for confirmation) -->
                    <div id="voterInfoBox" class="hidden mb-6 p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-4">
                        <img id="voterPhoto" src="" class="w-16 h-16 rounded-lg object-cover border border-slate-300">
                        <div class="flex flex-col">
                            <span id="voterName" class="text-sm font-bold text-slate-800"></span>
                            <span id="voterConstituency" class="text-xs text-slate-500"></span>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label for="party_id" class="field-label">Political Party</label>
                            <select id="party_id" name="party_id" class="field-input">
                                <option value="0">-- Independent / No Party --</option>
                                <?php foreach ($parties as $p): 
                                    $symbolUrl = $p['symbol_url'];
                                    if ($symbolUrl && !filter_var($symbolUrl, FILTER_VALIDATE_URL) && strpos($symbolUrl, 'data:image') !== 0 && !str_starts_with($symbolUrl, '/')) {
                                        $symbolUrl = BASE_URL . '/' . ltrim($symbolUrl, '/');
                                    }
                                ?>
                                    <option value="<?= $p['id'] ?>" data-symbol="<?= htmlspecialchars($symbolUrl) ?>">
                                        <?= htmlspecialchars($p['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label for="constituency_id" class="field-label">Election Constituency</label>
                            <select id="constituency_id" name="constituency_id" class="field-input" required>
                                <option value="">-- Select Constituency --</option>
                                <?php foreach ($constituencies as $co): ?>
                                    <option value="<?= $co['id'] ?>"><?= htmlspecialchars($co['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="election_type" class="field-label">Election Participation Type</label>
                        <select id="election_type" name="election_type" class="field-input">
                            <option value="fptp">First Past The Post (FPTP) only</option>
                            <option value="pr">Proportional Representation (PR) only</option>
                            <option value="both">Both FPTP and PR</option>
                        </select>
                        <p class="text-[0.71rem] text-text-muted mt-1">Determines which election pools this candidate can be assigned to.</p>
                    </div>

                    <div class="border-t border-slate-100 pt-4 flex justify-end gap-2.5">
                        <a href="<?= BASE_URL ?>/admin/candidates" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">Cancel</a>
                        <button type="submit" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
                            <i class="fas fa-save"></i> Save Candidate
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Live Preview Sidebar -->
    <div class="lg:col-span-1">
        <div class="panel sticky top-[100px]">
            <div class="panel-header panel-header--bordered">
                <h5 class="panel-title"><i class="fas fa-id-card panel-icon--accent"></i> Ballot Preview</h5>
            </div>
            <div class="panel-body text-center py-8">
                <div class="relative inline-block mb-4">
                    <img id="previewPhoto" src="https://ui-avatars.com/api/?name=Candidate&background=f1f5f9&color=cbd5e1" class="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl">
                    <div id="previewPartyBox" class="absolute -bottom-2 -right-2 w-12 h-12 bg-white rounded-full flex items-center justify-center border border-slate-200 shadow-lg hidden">
                        <img id="previewPartyLogo" src="" class="w-8 h-8 object-contain">
                    </div>
                </div>
                <h3 id="previewName" class="text-xl font-bold text-slate-800">Candidate Name</h3>
                <p id="previewPartyName" class="text-sm text-slate-500 mb-4">Independent</p>
                <div class="px-6 py-2 bg-primary/10 rounded-full inline-block">
                    <span id="previewConst" class="text-xs font-bold text-primary">No Constituency</span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const btnSearch = document.getElementById('btnSearchVoter');
    const inputVoterId = document.getElementById('voter_id');
    const voterBox = document.getElementById('voterInfoBox');
    const voterPhoto = document.getElementById('voterPhoto');
    const voterName = document.getElementById('voterName');
    const voterConst = document.getElementById('voterConstituency');

    const previewPhoto = document.getElementById('previewPhoto');
    const previewName = document.getElementById('previewName');
    const previewConst = document.getElementById('previewConst');
    const previewPartyBox = document.getElementById('previewPartyBox');
    const previewPartyLogo = document.getElementById('previewPartyLogo');
    const previewPartyName = document.getElementById('previewPartyName');

    const selectParty = document.getElementById('party_id');
    const selectConst = document.getElementById('constituency_id');

    // Voter Lookup
    btnSearch.addEventListener('click', function() {
        const id = inputVoterId.value.trim();
        if(!id) return alert('Please enter a Voter ID');

        btnSearch.disabled = true;
        btnSearch.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

        fetch('<?= BASE_URL ?>/admin/candidates/search-voter?voter_id=' + encodeURIComponent(id))
            .then(res => res.json())
            .then(data => {
                btnSearch.disabled = false;
                btnSearch.innerHTML = '<i class="fas fa-search"></i> Fetch';

                if(data.success) {
                    voterBox.classList.remove('hidden');
                    voterPhoto.src = data.data.photo_url || 'https://ui-avatars.com/api/?name=' + data.data.full_name;
                    voterName.innerText = data.data.full_name;
                    voterConst.innerText = 'Constituency: ' + data.data.constituency_name;
                    
                    // Update Preview
                    previewPhoto.src = data.data.photo_url || 'https://ui-avatars.com/api/?name=' + data.data.full_name;
                    previewName.innerText = data.data.full_name;
                    
                    // Auto-select constituency if possible
                    if(data.data.constituency_id) {
                        selectConst.value = data.data.constituency_id;
                        previewConst.innerText = data.data.constituency_name;
                    }
                } else {
                    alert(data.message);
                }
            })
            .catch(err => {
                btnSearch.disabled = false;
                btnSearch.innerHTML = '<i class="fas fa-search"></i> Fetch';
                console.error(err);
            });
    });

    // Party Sync
    selectParty.addEventListener('change', function() {
        const option = this.options[this.selectedIndex];
        const symbol = option.getAttribute('data-symbol');
        const name = option.text;

        if(this.value != "0" && symbol) {
            previewPartyBox.classList.remove('hidden');
            previewPartyLogo.src = symbol;
            previewPartyName.innerText = name;
        } else {
            previewPartyBox.classList.add('hidden');
            previewPartyName.innerText = 'Independent';
        }
    });

    // Constituency Sync
    selectConst.addEventListener('change', function() {
        previewConst.innerText = this.options[this.selectedIndex].text || 'No Constituency';
    });
});
</script>
