<div class="section-header">
    <div class="section-header-text">
        <h4>Candidates Management</h4>
        <p>Manage election candidates, affiliations and nominations</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/candidates/create" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-plus"></i> Add New Candidate
        </a>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <i class="fas fa-check-circle info-icon--green"></i>
            <span class="text-emerald-700 font-semibold">Candidate details saved successfully.</span>
        </div>
    </div>
<?php endif; ?>

<?php if (isset($_GET['error'])): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <i class="fas fa-exclamation-triangle info-icon--red"></i>
            <span class="text-red-700 font-semibold">
                <?php 
                    if ($_GET['error'] === 'tied_to_active_pool') {
                        echo "Cannot delete candidate. They are currently assigned to an <strong>active</strong> election pool: <strong>" . htmlspecialchars($_GET['pool'] ?? 'Unknown') . "</strong>";
                    } elseif ($_GET['error'] === 'tied_to_pool') {
                        echo "Cannot delete candidate. They are linked to an election pool (upcoming or closed): <strong>" . htmlspecialchars($_GET['pool'] ?? 'Unknown') . "</strong>. Remove them from the pool first.";
                    } elseif ($_GET['error'] === 'db_error') {
                        echo "A database error occurred. This record might be linked to other system data and cannot be deleted.";
                    } else {
                        echo "An error occurred. Please try again.";
                    }
                ?>
            </span>
        </div>
    </div>
<?php endif; ?>

<form method="GET" action="<?= BASE_URL ?>/admin/candidates" class="mb-6 flex flex-wrap gap-3 items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200">
    <div class="flex-1 min-w-[200px]">
        <input type="text" name="search" value="<?= htmlspecialchars($search ?? '') ?>" placeholder="Search by name, party, or Voter ID..." class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary">
    </div>
    <div class="w-48">
        <select name="status" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="">All Statuses</option>
            <option value="pending" <?= ($status ?? '') === 'pending' ? 'selected' : '' ?>>Pending</option>
            <option value="approved" <?= ($status ?? '') === 'approved' ? 'selected' : '' ?>>Approved</option>
            <option value="rejected" <?= ($status ?? '') === 'rejected' ? 'selected' : '' ?>>Rejected</option>
        </select>
    </div>
    <div class="w-48">
        <select name="sort" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="newest" <?= ($sort ?? '') === 'newest' ? 'selected' : '' ?>>Newest First</option>
            <option value="oldest" <?= ($sort ?? '') === 'oldest' ? 'selected' : '' ?>>Oldest First</option>
            <option value="name_asc" <?= ($sort ?? '') === 'name_asc' ? 'selected' : '' ?>>Name (A-Z)</option>
            <option value="name_desc" <?= ($sort ?? '') === 'name_desc' ? 'selected' : '' ?>>Name (Z-A)</option>
        </select>
    </div>
    <button type="submit" class="px-5 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors shadow-sm flex items-center gap-2">
        <i class="fas fa-filter"></i> Filter
    </button>
    <?php if (!empty($search) || !empty($status) || ($sort ?? 'newest') !== 'newest'): ?>
        <a href="<?= BASE_URL ?>/admin/candidates" class="px-5 py-2 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors border border-slate-200">
            Clear
        </a>
    <?php endif; ?>
</form>

<div class="panel">
    <div class="panel-body-flush">
        <table class="ovms-table">
            <thead>
                <tr>
                    <th class="th-pl">Candidate</th>
                    <th>Party &amp; Symbol</th>
                    <th>Constituency</th>
                    <th>Status</th>
                    <th class="td-pr text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($candidates)): ?>
                    <tr>
                        <td colspan="5" class="td-empty py-8">
                            <i class="fas fa-search block text-3xl opacity-20 mb-3"></i>
                            No candidates found matching your criteria.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($candidates as $c): ?>
                        <tr>
                            <td class="th-pl">
                                <div class="flex flex-col">
                                    <span class="td-bold"><?= htmlspecialchars($c['citizen_name']) ?></span>
                                    <span class="text-[0.65rem] text-slate-400 font-mono">ID: <?= htmlspecialchars($c['user_id']) ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="flex items-center gap-2">
                                    <?php if ($c['party_symbol']): ?>
                                        <?php 
                                            $symbolUrl = $c['party_symbol'];
                                            if (!filter_var($symbolUrl, FILTER_VALIDATE_URL) && strpos($symbolUrl, 'data:image') !== 0 && !str_starts_with($symbolUrl, '/')) {
                                                $symbolUrl = BASE_URL . '/' . ltrim($symbolUrl, '/');
                                            }
                                        ?>
                                        <img src="<?= htmlspecialchars($symbolUrl) ?>" class="w-6 h-6 object-contain">
                                    <?php endif; ?>
                                    <span class="td-muted"><?= htmlspecialchars($c['party_name'] ?? 'Independent') ?></span>
                                </div>
                            </td>
                            <td>
                                <span class="td-muted"><?= htmlspecialchars($c['constituency_name']) ?></span>
                            </td>
                            <td>
                                <?php if ($c['is_active']): ?>
                                    <span class="status-badge status--active">Active</span>
                                <?php else: ?>
                                    <span class="status-badge status--cancelled">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td class="td-pr text-right">
                                <div class="flex gap-2 justify-end">
                                    <a href="<?= BASE_URL ?>/admin/candidates/edit?id=<?= $c['id'] ?>" class="table-link" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= BASE_URL ?>/admin/candidates/delete?id=<?= $c['id'] ?>" 
                                       class="table-link text-red-400" 
                                       onclick="return confirm('Are you sure you want to delete this candidate? This action cannot be undone.')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if (($totalPages ?? 0) > 1): ?>
        <div class="p-4 border-t border-slate-100 flex flex-wrap justify-between items-center bg-slate-50/50 rounded-b-xl gap-4">
            <div class="text-sm text-slate-500 font-medium">
                Showing page <?= $page ?> of <?= $totalPages ?> (Total: <?= $totalRows ?? 0 ?>)
            </div>
            <div class="flex gap-1">
                <?php
                $qs = $_GET;
                for ($i = 1; $i <= $totalPages; $i++): 
                    $qs['page'] = $i;
                    $url = BASE_URL . '/admin/candidates?' . http_build_query($qs);
                    
                    if ($totalPages > 7 && $i > 2 && $i < $totalPages - 1 && abs($i - $page) > 1) {
                        if ($i == 3 || $i == $totalPages - 2) {
                            echo '<span class="px-2 py-1 text-slate-400">...</span>';
                        }
                        continue;
                    }
                ?>
                    <a href="<?= $url ?>" class="min-w-[32px] h-8 flex items-center justify-center px-2 border rounded-md text-sm font-medium transition-colors <?= $i === $page ? 'bg-primary text-white border-primary shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-50 border-slate-200' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
