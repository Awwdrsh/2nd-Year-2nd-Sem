<?php /* TODO: Build the Candidate Detail view */ ?>
<div class="container-fluid py-4">
    <h4><?= htmlspecialchars($title ?? 'Candidate Detail') ?></h4>
    <!-- TODO: Add your HTML here -->
</div>
