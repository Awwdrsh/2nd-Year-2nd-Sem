<?php
$statusOptions = ['upcoming', 'active', 'closed'];
?>

<div class="flex items-center justify-between mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Edit Voting Pool</h1>
        <p class="text-sm text-gray-500 mt-1">Update pool settings and schedule</p>
    </div>
    <div class="flex items-center gap-3">
        <a href="<?= BASE_URL ?>/admin/pools/<?= $pool['id'] ?>/candidates"
           class="text-sm text-teal-600 font-semibold hover:text-teal-700 flex items-center gap-1.5 transition border border-teal-200 bg-teal-50 px-3 py-1.5 rounded-lg">
            <i class="fas fa-users text-xs"></i> Manage Candidates
        </a>
        <a href="<?= BASE_URL ?>/admin/pools"
           class="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1.5 transition">
            <i class="fas fa-arrow-left text-xs"></i> Back to Pools
        </a>
    </div>
</div>

<?php if ($pool['status'] === 'active'): ?>
<div class="bg-amber-50 border border-amber-300 text-amber-800 px-4 py-3 rounded-lg mb-5 flex items-center gap-2">
    <i class="fas fa-exclamation-triangle text-amber-500"></i>
    <strong>Active Pool:</strong> This pool is currently active and voters may be casting votes. Changes to dates will take effect immediately.
</div>
<?php endif; ?>

<form method="POST" action="<?= BASE_URL ?>/admin/pools/update" class="max-w-3xl">
<input type="hidden" name="id" value="<?= (int)$pool['id'] ?>">

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
        <div class="px-6 py-4 border-b border-gray-100 bg-gray-50">
            <h2 class="font-semibold text-gray-800 flex items-center gap-2">
                <i class="fas fa-layer-group text-primary text-sm"></i> Pool Details
            </h2>
        </div>
        <div class="p-6 space-y-5">

            <!-- Title -->
            <div>
                <label class="field-label">
                    Pool Title <span class="text-red-500">*</span>
                </label>
                <input type="text" name="title" required
                       value="<?= htmlspecialchars($pool['title']) ?>"
                       class="field-input">
            </div>

            <!-- Election (read-only) -->
            <div>
                <label class="field-label">Election</label>
                <select name="election_id" disabled
                        class="field-input bg-gray-50 text-gray-500 cursor-not-allowed">
                    <?php foreach ($elections as $e): ?>
                    <option value="<?= $e['id'] ?>" <?= $e['id'] == $pool['election_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e['title']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <p class="text-xs text-gray-400 mt-1">Election cannot be changed after creation.</p>
            </div>

            <!-- Constituency (read-only) -->
            <div>
                <label class="field-label">Constituency</label>
                <select disabled class="field-input bg-gray-50 text-gray-500 cursor-not-allowed">
                    <?php foreach ($constituencies as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $c['id'] == $pool['constituency_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <p class="text-xs text-gray-400 mt-1">Constituency cannot be changed after creation.</p>
            </div>

            <!-- Status -->
            <div>
                <label class="field-label">
                    Pool Status
                </label>
                <select name="status"
                        class="field-input">
                    <?php foreach ($statusOptions as $s): ?>
                    <option value="<?= $s ?>" <?= $s === $pool['status'] ? 'selected' : '' ?>>
                        <?= ucfirst($s) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <p class="text-xs text-gray-400 mt-1">Set to <strong>Active</strong> to allow voters to cast votes in this pool.</p>
            </div>

            <!-- Description -->
            <div>
                <label class="field-label">Description</label>
                <textarea name="description" rows="2"
                          class="field-input resize-none"><?= htmlspecialchars($pool['description'] ?? '') ?></textarea>
            </div>
        </div>
    </div>

    <!-- Voting Window -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
        <div class="px-6 py-4 border-b border-gray-100 bg-gray-50">
            <h2 class="font-semibold text-gray-800 flex items-center gap-2">
                <i class="fas fa-clock text-primary text-sm"></i> Voting Window
            </h2>
        </div>
        <div class="p-6 grid grid-cols-2 gap-5">
            <div>
                <label class="field-label">
                    Start Date &amp; Time <span class="text-red-500">*</span>
                </label>
                <input type="datetime-local" name="voting_start" required
                       value="<?= date('Y-m-d\TH:i', strtotime($pool['voting_start'])) ?>"
                       class="field-input">
            </div>
            <div>
                <label class="field-label">
                    End Date &amp; Time <span class="text-red-500">*</span>
                </label>
                <input type="datetime-local" name="voting_end" required
                       value="<?= date('Y-m-d\TH:i', strtotime($pool['voting_end'])) ?>"
                       class="field-input">
            </div>
        </div>
    </div>

    <!-- Danger Zone -->
    <div class="bg-white rounded-xl shadow-sm border border-red-200 overflow-hidden mb-6">
        <div class="px-6 py-4 border-b border-red-100 bg-red-50">
            <h2 class="font-semibold text-red-700 flex items-center gap-2 text-sm">
                <i class="fas fa-trash"></i> Danger Zone
            </h2>
        </div>
        <div class="p-6 flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-700">Delete this pool</p>
                <p class="text-xs text-gray-400 mt-0.5">Only possible if no votes have been cast and no candidates are assigned.</p>
            </div>
            <a href="<?= BASE_URL ?>/admin/pools/delete?id=<?= (int)$pool['id'] ?>"
               onclick="return confirm('Are you sure? This cannot be undone.')"
               class="px-4 py-2 bg-red-600 text-white text-sm font-semibold rounded-lg hover:bg-red-700 transition">
                Delete Pool
            </a>
        </div>
    </div>

    <!-- Buttons -->
    <div class="flex gap-3">
        <a href="<?= BASE_URL ?>/admin/pools"
           class="px-6 py-2.5 border border-gray-300 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-50 transition">
            Cancel
        </a>
        <button type="submit"
                class="px-8 py-2.5 bg-primary text-white rounded-lg text-sm font-semibold hover:opacity-90 transition shadow-sm flex items-center gap-2">
            <i class="fas fa-save"></i> Save Changes
        </button>
    </div>

</form>
