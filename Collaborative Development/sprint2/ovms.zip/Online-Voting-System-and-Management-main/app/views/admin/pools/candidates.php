<?php
$statusColors = [
    'upcoming' => 'bg-blue-50 text-blue-700 border border-blue-200',
    'active' => 'bg-green-50 text-green-700 border border-green-200',
    'closed' => 'bg-gray-100 text-gray-500 border border-gray-200',
];
$sc = $statusColors[$pool['status']] ?? 'bg-gray-100 text-gray-600';

$successMessages = [
    'created' => 'Pool created. Eligible candidates have been auto-assigned.',
    'added' => 'Assignment added to pool successfully.',
    'removed' => 'Assignment removed from pool.',
];
$errorMessages = [
    'already_assigned' => 'This candidate is already assigned to an active election pool.',
    'invalid_candidate' => 'Selected candidate is invalid or not approved.',
    'invalid_candidate_type' => 'Candidate not registered for this type of election.',
    'missing_fields' => 'Please select an item.',
    'has_votes' => 'Votes recorded for this item, cannot remove.',
    'not_found' => 'Pool not found.',
];
?>

<!-- Alerts -->
<?php if (!empty($success) && isset($successMessages[$success])): ?>
    <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
        <i class="fas fa-check-circle text-green-600"></i>
        <?= $successMessages[$success] ?>
    </div>
<?php endif; ?>

<?php if (!empty($error) && isset($errorMessages[$error])): ?>
    <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
        <i class="fas fa-exclamation-circle text-red-500"></i>
        <?= $errorMessages[$error] ?>
    </div>
<?php endif; ?>

<!-- Header -->
<div class="flex items-start justify-between mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900"><?= $pool['pool_type'] === 'pr' ? 'Assign Parties to PR Pool' : 'Assign Candidates to FPTP Pool' ?></h1>
        <p class="text-sm text-gray-500 mt-1">
            Carefully select and map <?= $pool['pool_type'] === 'pr' ? 'parties' : 'candidates' ?> to the <strong><?= htmlspecialchars($pool['title']) ?></strong> ballot.
        </p>
    </div>
    <a href="<?= BASE_URL ?>/admin/pools"
        class="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1.5 transition">
        <i class="fas fa-arrow-left text-xs"></i> Back to Pools
    </a>
</div>

<!-- Usage Tip -->
<div class="bg-indigo-50 border border-indigo-100 rounded-xl p-4 mb-6 flex items-start gap-3">
    <div
        class="bg-indigo-500 text-white w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm">
        <i class="fas fa-lightbulb text-[0.65rem]"></i>
    </div>
    <div>
        <p class="text-[0.8rem] text-indigo-900 font-semibold mb-0.5">Assignment Tip</p>
        <p class="text-[0.75rem] text-indigo-700 leading-relaxed">
            <?php if ($pool['pool_type'] === 'pr'): ?>
                In <strong>Proportional Representation (PR)</strong>, people vote for <strong>Parties</strong>. 
                Select the political parties that should appear on this ballot.
            <?php else: ?>
                In <strong>First Past The Post (FPTP)</strong>, people vote for <strong>Individual Candidates</strong>. 
                Select the approved candidates from <strong><?= htmlspecialchars($pool['constituency_name']) ?></strong> for this ballot.
            <?php endif; ?>
        </p>
    </div>
</div>

<!-- Pool Info Card -->
<div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
    <div class="px-6 py-4 border-b border-gray-100 bg-gray-50 flex items-center justify-between">
        <div class="flex items-center gap-3">
            <div class="w-9 h-9 bg-primary/10 rounded-lg flex items-center justify-center">
                <i class="fas fa-layer-group text-primary text-sm"></i>
            </div>
            <div>
                <p class="font-semibold text-gray-800"><?= htmlspecialchars($pool['title']) ?></p>
                <p class="text-xs text-gray-400"><?= htmlspecialchars($pool['election_title']) ?> ·
                    <?= htmlspecialchars($pool['constituency_name']) ?></p>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <span class="px-2.5 py-1 rounded-full text-xs font-semibold capitalize <?= $sc ?>">
                <?php if ($pool['status'] === 'active'): ?>
                    <span class="inline-block w-1.5 h-1.5 bg-green-500 rounded-full mr-1 animate-pulse"></span>
                <?php endif; ?>
                <?= ucfirst($pool['status']) ?>
            </span>
            <a href="<?= BASE_URL ?>/admin/pools/edit?id=<?= $pool['id'] ?>"
                class="text-xs text-blue-600 hover:text-blue-700 font-medium border border-blue-200 bg-blue-50 px-3 py-1.5 rounded-lg transition">
                <i class="fas fa-pencil text-[0.65rem] mr-1"></i>Edit Settings
            </a>
        </div>
    </div>
    <div class="px-6 py-3 text-sm text-gray-500 flex items-center gap-6">
        <span><i class="fas fa-clock mr-1.5 text-gray-400"></i>
            <?= date('M d, Y H:i', strtotime($pool['voting_start'])) ?> →
            <?= date('M d, Y H:i', strtotime($pool['voting_end'])) ?>
        </span>
        <span><i class="fas fa-list-ol mr-1.5 text-gray-400"></i>
            <?php if ($pool['pool_type'] === 'pr'): ?>
                <strong><?= count($poolParties) ?></strong> part<?= count($poolParties) !== 1 ? 'ies' : 'y' ?> assigned
            <?php else: ?>
                <strong><?= count($poolCandidates) ?></strong> candidate<?= count($poolCandidates) !== 1 ? 's' : '' ?> assigned
            <?php endif; ?>
        </span>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-5 gap-6">

    <!-- LEFT: Assigned Entities -->
    <div class="lg:col-span-3">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="px-5 py-4 border-b border-gray-100 bg-gray-50 flex items-center justify-between">
                <h2 class="font-semibold text-gray-800 text-sm flex items-center gap-2">
                    <i class="fas fa-check-circle text-teal-600 text-xs"></i>
                    Current Ballot List
                    <span class="bg-teal-100 text-teal-700 text-xs px-2 py-0.5 rounded-full font-bold ml-1">
                        <?= $pool['pool_type'] === 'pr' ? count($poolParties) : count($poolCandidates) ?>
                    </span>
                </h2>
            </div>

            <?php if ($pool['pool_type'] === 'pr'): ?>
                <?php if (empty($poolParties)): ?>
                    <div class="text-center py-12 text-gray-400">
                        <i class="fas fa-flag text-3xl mb-3 opacity-40"></i>
                        <p class="text-sm">No parties assigned yet.</p>
                    </div>
                <?php else: ?>
                    <ul class="divide-y divide-gray-100">
                        <?php foreach ($poolParties as $idx => $pp): ?>
                            <li class="px-5 py-3.5 flex items-center gap-3 hover:bg-gray-50 transition">
                                <div class="w-8 h-8 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-sm flex-shrink-0">
                                    <?= $idx + 1 ?>
                                </div>
                                <?php if (!empty($pp['symbol_url'])): ?>
                                    <img src="<?= htmlspecialchars($pp['symbol_url']) ?>" class="w-9 h-9 rounded object-contain bg-gray-50 border border-gray-200 p-0.5 flex-shrink-0" alt="">
                                <?php else: ?>
                                    <div class="w-9 h-9 rounded bg-primary/10 text-primary font-bold text-xs flex items-center justify-center flex-shrink-0">
                                        <?= strtoupper(substr($pp['abbreviation'] ?? 'P', 0, 3)) ?>
                                    </div>
                                <?php endif; ?>
                                <div class="flex-1 min-w-0">
                                    <p class="font-semibold text-gray-800 text-sm truncate"><?= htmlspecialchars($pp['party_name']) ?></p>
                                    <p class="text-xs text-gray-400 truncate"><?= htmlspecialchars($pp['abbreviation']) ?></p>
                                </div>
                                <form method="POST" action="<?= BASE_URL ?>/admin/pools/candidates/remove" onsubmit="return confirm('Remove party?')">
                                    <input type="hidden" name="pool_id" value="<?= $pool['id'] ?>">
                                    <input type="hidden" name="pp_id" value="<?= $pp['pp_id'] ?>">
                                    <button type="submit" class="w-8 h-8 flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition">
                                        <i class="fas fa-times text-xs"></i>
                                    </button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            <?php else: ?>
                <?php if (empty($poolCandidates)): ?>
                    <div class="text-center py-12 text-gray-400">
                        <i class="fas fa-user-slash text-3xl mb-3 opacity-40"></i>
                        <p class="text-sm">No candidates assigned yet.</p>
                    </div>
                <?php else: ?>
                    <ul class="divide-y divide-gray-100">
                        <?php foreach ($poolCandidates as $idx => $pc): ?>
                            <li class="px-5 py-3.5 flex items-center gap-3 hover:bg-gray-50 transition">
                                <div class="w-8 h-8 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-sm flex-shrink-0">
                                    <?= $idx + 1 ?>
                                </div>
                                <?php if (!empty($pc['symbol_url'])): ?>
                                    <img src="<?= htmlspecialchars($pc['symbol_url']) ?>" class="w-9 h-9 rounded object-contain bg-gray-50 border border-gray-200 p-0.5 flex-shrink-0" alt="">
                                <?php else: ?>
                                    <div class="w-9 h-9 rounded bg-primary/10 text-primary font-bold text-xs flex items-center justify-center flex-shrink-0">
                                        <?= strtoupper(substr($pc['party_name'] ?? 'I', 0, 3)) ?>
                                    </div>
                                <?php endif; ?>
                                <div class="flex-1 min-w-0">
                                    <p class="font-semibold text-gray-800 text-sm truncate"><?= htmlspecialchars($pc['full_name']) ?></p>
                                    <p class="text-xs text-gray-400 truncate"><?= htmlspecialchars($pc['party_name'] ?? 'Independent') ?></p>
                                </div>
                                <form method="POST" action="<?= BASE_URL ?>/admin/pools/candidates/remove" onsubmit="return confirm('Remove candidate?')">
                                    <input type="hidden" name="pool_id" value="<?= $pool['id'] ?>">
                                    <input type="hidden" name="pc_id" value="<?= $pc['pc_id'] ?>">
                                    <button type="submit" class="w-8 h-8 flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition">
                                        <i class="fas fa-times text-xs"></i>
                                    </button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- RIGHT: Add Panel -->
    <div class="lg:col-span-2">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden sticky top-6">
            <div class="px-5 py-4 border-b border-gray-100 bg-gray-50">
                <h2 class="font-semibold text-gray-800 text-sm flex items-center gap-2">
                    <i class="fas <?= $pool['pool_type'] === 'pr' ? 'fa-flag' : 'fa-user-plus' ?> text-primary text-xs"></i>
                    Assign <?= $pool['pool_type'] === 'pr' ? 'Party' : 'Candidate' ?>
                </h2>
            </div>

            <form method="POST" action="<?= BASE_URL ?>/admin/pools/candidates/add" class="p-5">
                <input type="hidden" name="pool_id" value="<?= $pool['id'] ?>">

                <?php if ($pool['pool_type'] === 'pr'): ?>
                    <div class="mb-4">
                        <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Select Political Party</label>
                        <select name="party_id" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary" required>
                            <option value="">-- Choose Party --</option>
                            <?php foreach ($eligibleParties as $ep): ?>
                                <option value="<?= $ep['id'] ?>"><?= htmlspecialchars($ep['name']) ?> (<?= htmlspecialchars($ep['abbreviation']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php else: ?>
                    <div class="mb-4">
                        <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Select Candidate</label>
                        <input type="text" id="candidateSearch" placeholder="Search..." class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary mb-2" autocomplete="off">
                        <div class="border border-gray-200 rounded-lg overflow-y-auto max-h-52" id="candidateList">
                            <?php foreach ($eligibleCandidates as $ec): ?>
                                <label class="candidate-option flex items-center gap-2.5 px-3 py-2.5 cursor-pointer hover:bg-teal-50 transition border-b border-gray-100 last:border-0" data-name="<?= htmlspecialchars(strtolower($ec['full_name'])) ?>" data-party="<?= htmlspecialchars(strtolower($ec['party_name'] ?? '')) ?>">
                                    <input type="radio" name="candidate_id" value="<?= $ec['id'] ?>" class="accent-teal-600">
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-semibold text-gray-800 truncate"><?= htmlspecialchars($ec['full_name']) ?></p>
                                        <p class="text-xs text-gray-400 truncate"><?= htmlspecialchars($ec['party_name'] ?? 'Independent') ?></p>
                                    </div>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <button type="submit" class="w-full bg-primary hover:opacity-90 text-white py-2.5 rounded-lg text-sm font-semibold transition shadow-sm flex items-center justify-center gap-2">
                    <i class="fas fa-plus text-xs"></i> Add to Pool
                </button>
            </form>
        </div>
    </div>

</div>

<script>
    (function () {
        const searchInput = document.getElementById('candidateSearch');
        if (!searchInput) return;

        searchInput.addEventListener('input', function () {
            const q = this.value.toLowerCase().trim();
            document.querySelectorAll('.candidate-option').forEach(opt => {
                const name = opt.dataset.name || '';
                const party = opt.dataset.party || '';
                opt.style.display = (!q || name.includes(q) || party.includes(q)) ? '' : 'none';
            });
        });
    })();
</script>