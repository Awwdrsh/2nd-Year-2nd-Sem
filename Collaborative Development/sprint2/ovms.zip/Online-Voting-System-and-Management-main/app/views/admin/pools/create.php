<?php
$errors = [
    'missing_fields' => 'Please fill in all required fields.',
    'invalid_dates'  => 'End date/time must be after start date/time.',
];
?>

<?php if (!empty($_GET['error']) && isset($errors[$_GET['error']])): ?>
<div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-5 flex items-center gap-2">
    <i class="fas fa-exclamation-circle"></i>
    <?= $errors[$_GET['error']] ?>
</div>
<?php endif; ?>

<div class="flex items-center justify-between mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Create Voting Pool</h1>
        <p class="text-sm text-gray-500 mt-1">A pool is a single ballot linked to an election and constituency</p>
    </div>
    <a href="<?= BASE_URL ?>/admin/pools"
       class="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1.5 transition">
        <i class="fas fa-arrow-left text-xs"></i> Back to Pools
    </a>
</div>

<form method="POST" action="<?= BASE_URL ?>/admin/pools/store" class="max-w-3xl">

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
        <div class="px-6 py-4 border-b border-gray-100 bg-gray-50">
            <h2 class="font-semibold text-gray-800 flex items-center gap-2">
                <i class="fas fa-layer-group text-primary text-sm"></i> Pool Details
            </h2>
        </div>
        <div class="p-6 space-y-5">

            <!-- Pool Title -->
            <div>
                <label class="field-label">
                    Pool Title <span class="text-red-500">*</span>
                </label>
                <input type="text" name="title" required
                       placeholder="e.g. Kathmandu-1 FPTP Ballot 2081"
                       class="field-input">
            </div>

            <!-- Election -->
            <div>
                <label class="field-label">
                    Election <span class="text-red-500">*</span>
                </label>
                <?php if (empty($elections)): ?>
                <div class="bg-amber-50 border border-amber-200 text-amber-700 text-sm px-4 py-3 rounded-lg">
                    No elections found. <a href="<?= BASE_URL ?>/admin/elections/create" class="font-semibold underline">Create an election first</a>.
                </div>
                <?php else: ?>
                <select name="election_id" id="electionSelect" required
                        class="field-input">
                    <option value="">— Select Election —</option>
                    <?php foreach ($elections as $e): 
                        $start = !empty($e['voting_start']) ? date('Y-m-d\TH:i', strtotime($e['voting_start'])) : '';
                        $end   = !empty($e['voting_end']) ? date('Y-m-d\TH:i', strtotime($e['voting_end'])) : '';
                    ?>
                    <option value="<?= $e['id'] ?>" data-start="<?= $start ?>" data-end="<?= $end ?>">
                        <?= htmlspecialchars($e['title']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <?php endif; ?>
            </div>

            <!-- Constituency -->
            <div>
                <label class="field-label">
                    Constituency <span class="text-red-500">*</span>
                </label>
                <?php if (empty($constituencies)): ?>
                <div class="bg-amber-50 border border-amber-200 text-amber-700 text-sm px-4 py-3 rounded-lg">
                    No constituencies found. Please seed the database first.
                </div>
                <?php else: ?>
                <select name="constituency_id" id="constituencySelect" required
                        class="field-input">
                    <option value="">— Select Constituency —</option>
                    <?php foreach ($constituencies as $c): ?>
                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php endif; ?>
                <p class="text-xs text-gray-400 mt-1">
                    <i class="fas fa-info-circle"></i>
                    Approved candidates from this constituency will be auto-assigned to the pool.
                </p>
            </div>

            <!-- Pool Type & Election Type side by side -->
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="field-label">
                        Pool Type <span class="text-red-500">*</span>
                    </label>
                    <select name="pool_type" id="poolTypeSelect"
                            class="field-input">
                        <option value="fptp">FPTP — First Past the Post</option>
                        <option value="pr">PR — Proportional Representation</option>
                    </select>
                </div>
                <div>
                    <label class="field-label">
                        Election Level <span class="text-red-500">*</span>
                    </label>
                    <select name="election_type"
                            class="field-input">
                        <option value="national">National</option>
                        <option value="local">Local</option>
                        <option value="by_election">By-Election</option>
                    </select>
                </div>
            </div>

            <!-- Description -->
            <div>
                <label class="field-label">
                    Description <span class="text-gray-400 font-normal">(optional)</span>
                </label>
                <textarea name="description" rows="2"
                          placeholder="Optional details about this pool..."
                          class="field-input resize-none"></textarea>
            </div>
        </div>
    </div>

    <!-- Voting Window -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
        <div class="px-6 py-4 border-b border-gray-100 bg-gray-50">
            <h2 class="font-semibold text-gray-800 flex items-center gap-2">
                <i class="fas fa-clock text-primary text-sm"></i> Voting Window
            </h2>
        </div>
        <div class="p-6 grid grid-cols-2 gap-5">
            <div>
                <label class="field-label">
                    Start Date &amp; Time <span class="text-red-500">*</span>
                </label>
                <input type="datetime-local" id="voting_start" name="voting_start" required
                       class="field-input">
            </div>
            <div>
                <label class="field-label">
                    End Date &amp; Time <span class="text-red-500">*</span>
                </label>
                <input type="datetime-local" id="voting_end" name="voting_end" required
                       class="field-input">
            </div>
        </div>
    </div>

    <!-- Submit -->
    <div class="flex gap-3">
        <a href="<?= BASE_URL ?>/admin/pools"
           class="px-6 py-2.5 border border-gray-300 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-50 transition">
            Cancel
        </a>
        <button type="submit"
                class="px-8 py-2.5 bg-primary text-white rounded-lg text-sm font-semibold hover:opacity-90 transition shadow-sm flex items-center gap-2">
            <i class="fas fa-plus"></i> Create Pool
        </button>
    </div>

</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const electionSelect = document.getElementById('electionSelect');
    const startInput = document.getElementById('voting_start');
    const endInput = document.getElementById('voting_end');

    // 1. Set default start date to current time (if empty)
    if (!startInput.value) {
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        startInput.value = now.toISOString().slice(0, 16);
    }

    // 2. Auto-assign dates when election changes
    if (electionSelect) {
        electionSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const start = selectedOption.getAttribute('data-start');
            const end = selectedOption.getAttribute('data-end');

            if (start) startInput.value = start;
            if (end) endInput.value = end;
        });
    }
});
</script>
