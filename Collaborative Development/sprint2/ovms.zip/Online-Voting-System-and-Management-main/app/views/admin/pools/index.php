<?php
$successMessages = [
    'created'       => 'Pool created successfully.',
    'updated'       => 'Pool updated successfully.',
    'deleted'       => 'Pool deleted successfully.',
    'bulk_deleted'  => 'Successfully deleted ' . ($_GET['count'] ?? '0') . ' pools.',
    'added'         => 'Assignment added successfully.',
    'removed'       => 'Assignment removed from pool.',
    'auto_assigned' => 'Successfully bulk-assigned ' . ($_GET['count'] ?? '0') . ' entities.',
];
$errorMessages = [
    'has_votes'    => 'Cannot delete pools that already have votes cast.',
    'not_found'    => 'Pool not found.',
    'no_selection' => 'Please select at least one pool for bulk actions.',
];
?>

<div class="flex items-center justify-between mb-6">
    <div>
        <h2 class="text-2xl font-bold text-gray-900">Voting Pools Dashboard</h2>
        <p class="text-sm text-gray-500 mt-1">Manage ballots and assign candidates inline</p>
    </div>
    <div class="flex gap-3">
        <a href="<?= BASE_URL ?>/admin/pools/auto-assign"
           onclick="return confirm('Auto-assign all eligible approved candidates (FPTP) and all active parties (PR) to their matching mapped pools?')"
           class="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 px-4 py-2 rounded-lg text-sm font-semibold transition shadow-sm flex items-center gap-2">
            <i class="fas fa-magic"></i> Auto-Assign
        </a>
        <a href="<?= BASE_URL ?>/admin/pools/create"
           class="bg-primary hover:opacity-90 text-white px-4 py-2 rounded-lg text-sm font-semibold transition shadow-sm flex items-center gap-2">
            <i class="fas fa-plus"></i> New Pool
        </a>
    </div>
</div>

<!-- Alerts -->
<?php if (!empty($_GET['success']) && isset($successMessages[$_GET['success']])): ?>
<div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
    <i class="fas fa-check-circle text-green-600"></i>
    <?= $successMessages[$_GET['success']] ?>
</div>
<?php endif; ?>

<?php if (!empty($_GET['error']) && isset($errorMessages[$_GET['error']])): ?>
<div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
    <i class="fas fa-exclamation-circle text-red-500"></i>
    <?= $errorMessages[$_GET['error']] ?>
</div>
<?php endif; ?>

<form method="GET" action="<?= BASE_URL ?>/admin/pools" class="mb-6 flex flex-wrap gap-3 items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200">
    <div class="flex-1 min-w-[200px]">
        <input type="text" name="search" value="<?= htmlspecialchars($search ?? '') ?>" placeholder="Search by pool title or election..." class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary">
    </div>
    <div class="w-48">
        <select name="status" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="">All Statuses</option>
            <option value="upcoming" <?= ($status ?? '') === 'upcoming' ? 'selected' : '' ?>>Upcoming</option>
            <option value="active" <?= ($status ?? '') === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="completed" <?= ($status ?? '') === 'completed' ? 'selected' : '' ?>>Completed</option>
        </select>
    </div>
    <div class="w-48">
        <select name="sort" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="newest" <?= ($sort ?? '') === 'newest' ? 'selected' : '' ?>>Newest First</option>
            <option value="oldest" <?= ($sort ?? '') === 'oldest' ? 'selected' : '' ?>>Oldest First</option>
            <option value="title_asc" <?= ($sort ?? '') === 'title_asc' ? 'selected' : '' ?>>Title (A-Z)</option>
            <option value="title_desc" <?= ($sort ?? '') === 'title_desc' ? 'selected' : '' ?>>Title (Z-A)</option>
        </select>
    </div>
    <button type="submit" class="px-5 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors shadow-sm flex items-center gap-2">
        <i class="fas fa-filter"></i> Filter
    </button>
    <?php if (!empty($search) || !empty($status) || ($sort ?? 'newest') !== 'newest'): ?>
        <a href="<?= BASE_URL ?>/admin/pools" class="px-5 py-2 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors border border-slate-200">
            Clear
        </a>
    <?php endif; ?>
</form>

<div id="bulkToolbar" class="hidden mb-4 p-3 bg-gray-900 border border-gray-800 rounded-xl shadow-lg flex items-center justify-between animate-slide-up sticky top-4 z-[50]">
    <div class="flex items-center gap-3">
        <span class="text-white text-sm font-bold ml-2">
            <span id="selectedCount">0</span> Pools Selected
        </span>
        <div class="h-4 w-px bg-white/20"></div>
        <p class="text-white/60 text-[0.7rem] italic">Perform action on filtered set</p>
    </div>
    <div class="flex gap-2">
        <button type="button" onclick="submitBulk('delete')" class="bg-red-600 hover:bg-red-700 text-white px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2">
            <i class="fas fa-trash-can"></i> Delete Selected
        </button>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
    <?php if (empty($pools)): ?>
    <div class="text-center py-16 text-gray-500">
        <i class="fas fa-search text-4xl mb-3 opacity-30"></i>
        <p class="font-medium">No voting pools found matching your criteria.</p>
    </div>
    <?php else: ?>
    <table class="w-full text-sm">
        <thead>
            <tr class="bg-gray-50 border-b text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <th class="px-4 py-3 w-10">
                    <input type="checkbox" id="selectAll" class="rounded border-gray-300 text-primary">
                </th>
                <th class="px-4 py-3">Ballot Information</th>
                <th class="px-4 py-3">Election Window</th>
                <th class="px-4 py-3">Status</th>
                <th class="px-4 py-3">Assigned Entities (Quick Edit)</th>
                <th class="px-4 py-3 text-right">Row Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
        <?php foreach ($pools as $pool): ?>
        <?php
            $statusColors = [
                'upcoming' => 'bg-blue-50 text-blue-700',
                'active'   => 'bg-green-50 text-green-700',
                'closed'   => 'bg-gray-100 text-gray-500',
            ];
            $sc = $statusColors[$pool['status']] ?? 'bg-gray-100 text-gray-600';
            
            // Parse assigned entities
            $isPR = ($pool['pool_type'] === 'pr');
            $assignedStr = $isPR ? ($pool['assigned_parties_list'] ?? '') : ($pool['assigned_candidates_list'] ?? '');
            $assigned = [];
            if ($assignedStr) {
                foreach (explode('|', $assignedStr) as $pair) {
                    $parts = explode(':', $pair);
                    if (count($parts) === 2) {
                        $assigned[] = ['name' => $parts[0], 'id' => $parts[1]];
                    }
                }
            }
        ?>
        <tr class="hover:bg-gray-50 transition">
            <td class="px-4 py-3">
                <input type="checkbox" value="<?= $pool['id'] ?>" class="pool-checkbox rounded border-gray-300 text-primary">
            </td>
            <td class="px-4 py-3">
                <div class="font-bold text-gray-900"><?= htmlspecialchars($pool['title']) ?></div>
                <div class="text-[0.7rem] text-gray-400 font-medium uppercase tracking-tight mt-0.5">
                    <?= htmlspecialchars($pool['constituency_name']) ?> · <span class="bg-gray-100 px-1 rounded"><?= strtoupper($pool['pool_type']) ?></span>
                </div>
            </td>
            <td class="px-4 py-3">
                <div class="text-[0.75rem] text-gray-700 font-medium"><?= htmlspecialchars($pool['election_title']) ?></div>
                <div class="text-[0.65rem] text-gray-400 mt-1 italic">
                    <?= date('M d, H:i', strtotime($pool['voting_start'])) ?> - <?= date('M d, H:i', strtotime($pool['voting_end'])) ?>
                </div>
            </td>
            <td class="px-4 py-3">
                <span class="px-2 py-0.5 rounded-full text-[0.65rem] font-black uppercase tracking-wider <?= $sc ?>">
                    <?= $pool['status'] ?>
                </span>
            </td>
            <td class="px-4 py-3">
                <div class="flex flex-wrap gap-1 mb-2">
                    <?php if (empty($assigned)): ?>
                        <span class="text-[0.7rem] text-gray-400 italic">No <?= $isPR ? 'parties' : 'candidates' ?> assigned</span>
                    <?php else: ?>
                        <?php foreach ($assigned as $item): ?>
                            <span class="inline-flex items-center gap-1 <?= $isPR ? 'bg-indigo-50 text-indigo-700 border-indigo-100' : 'bg-teal-50 text-teal-700 border-teal-100' ?> border px-2 py-0.5 rounded text-[0.7rem] font-bold">
                                <?= htmlspecialchars($item['name']) ?>
                                <a href="<?= BASE_URL ?>/admin/pools/candidates/remove?pool_id=<?= $pool['id'] ?>&<?= $isPR ? 'pp_id' : 'pc_id' ?>=<?= $item['id'] ?>" 
                                   onclick="return confirm('Remove assignment?')"
                                   class="text-red-400 hover:text-red-600 transition">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <!-- Quick Add Dropdown -->
                <form method="POST" action="<?= BASE_URL ?>/admin/pools/candidates/add" class="mt-1">
                    <input type="hidden" name="pool_id" value="<?= $pool['id'] ?>">
                    <?php if ($isPR): ?>
                        <select name="party_id" onchange="this.form.submit()" 
                                class="text-[0.65rem] font-bold border-gray-200 rounded-lg px-2 py-1 bg-gray-50 focus:border-primary focus:ring-1 focus:ring-primary/20 w-fit cursor-pointer hover:bg-white transition shadow-sm">
                            <option value="">＋ ADD PARTY</option>
                            <?php foreach ($allParties as $p): ?>
                                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php else: ?>
                        <select name="candidate_id" onchange="this.form.submit()" 
                                class="text-[0.65rem] font-bold border-gray-200 rounded-lg px-2 py-1 bg-gray-50 focus:border-primary focus:ring-1 focus:ring-primary/20 w-fit cursor-pointer hover:bg-white transition shadow-sm">
                            <option value="">＋ ADD CANDIDATE</option>
                            <?php foreach ($eligibleByConst[$pool['constituency_id']] ?? [] as $ec): ?>
                                <?php if ($ec['election_type'] === $pool['pool_type']): ?>
                                    <option value="<?= $ec['id'] ?>"><?= htmlspecialchars($ec['full_name']) ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                </form>
            </td>
            <td class="px-4 py-3 text-right">
                <div class="flex items-center justify-end gap-2">
                    <a href="<?= BASE_URL ?>/admin/pools/<?= $pool['id'] ?>/candidates" 
                       class="inline-flex items-center gap-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 px-3 py-1 rounded-md font-bold transition shadow-sm border border-indigo-100 text-[0.75rem]">
                        <i class="fas fa-users-cog"></i> Edit/Manage
                    </a>
                    <a href="<?= BASE_URL ?>/admin/pools/edit?id=<?= $pool['id'] ?>" 
                       class="inline-flex items-center gap-1 bg-blue-50 hover:bg-blue-100 text-blue-700 px-3 py-1 rounded-md font-bold transition shadow-sm border border-blue-100 text-[0.75rem]">
                        <i class="fas fa-cog"></i> Settings
                    </a>
                    <a href="<?= BASE_URL ?>/admin/pools/delete?id=<?= $pool['id'] ?>" 
                       onclick="return confirm('Permanently delete this specific pool? This action is irreversible.')"
                       class="inline-flex items-center gap-1 bg-red-50 hover:bg-red-100 text-red-600 px-3 py-1 rounded-md font-black transition shadow-sm border border-red-100 uppercase italic text-[0.65rem] tracking-tighter">
                        <i class="fas fa-trash-alt"></i> Delete
                    </a>
                </div>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    
    <?php if (($totalPages ?? 0) > 1): ?>
        <div class="p-4 border-t border-slate-100 flex flex-wrap justify-between items-center bg-slate-50/50 rounded-b-xl gap-4">
            <div class="text-sm text-slate-500 font-medium">
                Showing page <?= $page ?> of <?= $totalPages ?> (Total: <?= $totalRows ?? 0 ?>)
            </div>
            <div class="flex gap-1">
                <?php
                $qs = $_GET;
                for ($i = 1; $i <= $totalPages; $i++): 
                    $qs['page'] = $i;
                    $url = BASE_URL . '/admin/pools?' . http_build_query($qs);
                    
                    if ($totalPages > 7 && $i > 2 && $i < $totalPages - 1 && abs($i - $page) > 1) {
                        if ($i == 3 || $i == $totalPages - 2) {
                            echo '<span class="px-2 py-1 text-slate-400">...</span>';
                        }
                        continue;
                    }
                ?>
                    <a href="<?= $url ?>" class="min-w-[32px] h-8 flex items-center justify-center px-2 border rounded-md text-sm font-medium transition-colors <?= $i === $page ? 'bg-primary text-white border-primary shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-50 border-slate-200' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Hidden form for bulk actions -->
<form id="bulkActionForm" method="POST" action="<?= BASE_URL ?>/admin/pools/bulk-action" class="hidden">
    <input type="hidden" name="action" id="bulkActionInput" value="">
    <div id="bulkIdsContainer"></div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.pool-checkbox');
    const bulkToolbar = document.getElementById('bulkToolbar');
    const selectedCount = document.getElementById('selectedCount');
    const bulkForm = document.getElementById('bulkActionForm');
    const bulkActionInput = document.getElementById('bulkActionInput');
    const bulkIdsContainer = document.getElementById('bulkIdsContainer');

    window.submitBulk = function(action) {
        const checked = document.querySelectorAll('.pool-checkbox:checked');
        if (checked.length === 0) {
            alert('Please select at least one pool.');
            return;
        }

        if (confirm(`CRITICAL: You are about to ${action} ${checked.length} pools. Continue?`)) {
            bulkActionInput.value = action;
            bulkIdsContainer.innerHTML = '';
            checked.forEach(cb => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'pool_ids[]';
                input.value = cb.value;
                bulkIdsContainer.appendChild(input);
            });
            bulkForm.submit();
        }
    }

    function updateBulkUI() {
        const checkedCount = document.querySelectorAll('.pool-checkbox:checked').length;
        if (checkedCount > 0) {
            bulkToolbar.classList.remove('hidden');
            selectedCount.textContent = checkedCount;
        } else {
            bulkToolbar.classList.add('hidden');
        }
    }

    if (selectAll) {
        selectAll.addEventListener('change', function() {
            checkboxes.forEach(cb => cb.checked = this.checked);
            updateBulkUI();
        });
    }

    checkboxes.forEach(cb => {
        cb.addEventListener('change', updateBulkUI);
    });
});
</script>

<style>
@keyframes slide-up {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}
.animate-slide-up {
    animation: slide-up 0.3s ease-out forwards;
}
</style>
