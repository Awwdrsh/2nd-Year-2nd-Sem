<div class="section-header">
    <div>
        <h4>Edit Election — <?= htmlspecialchars($election['title']) ?></h4>
        <p>Modify scheduling and status parameters</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= asset('admin/elections') ?>" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-chevron-left"></i> Back to List
        </a>
    </div>
</div>

<div class="panel">
    <div class="panel-header panel-header--bordered">
        <h5 class="panel-title">
            <i class="fas fa-edit panel-icon--accent"></i>
            Manage Election State
        </h5>
    </div>
    <div class="panel-body">
        <form action="<?= asset('admin/elections/update') ?>" method="POST" class="max-w-2xl">
            <input type="hidden" name="id" value="<?= $election['id'] ?>">

            <div class="mb-5">
                <label class="field-label">Election Title</label>
                <input type="text" name="title" value="<?= htmlspecialchars($election['title']) ?>"
                       class="field-input" required>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-5">
                <div>
                    <label class="field-label">Election Status</label>
                    <select name="status" class="field-input cursor-pointer">
                        <option value="draft"     <?= $election['status'] === 'draft'     ? 'selected' : '' ?>>Draft</option>
                        <option value="active"    <?= $election['status'] === 'active'    ? 'selected' : '' ?>>Active (Open for Voting)</option>
                        <option value="completed" <?= $election['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                        <option value="cancelled" <?= $election['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-6">
                <div>
                    <label class="field-label">Voting Starts At</label>
                    <input type="datetime-local" name="voting_start"
                           value="<?= date('Y-m-d\TH:i', strtotime($election['voting_start'])) ?>"
                           class="field-input" required>
                </div>
                <div>
                    <label class="field-label">Voting Ends At</label>
                    <input type="datetime-local" name="voting_end"
                           value="<?= date('Y-m-d\TH:i', strtotime($election['voting_end'])) ?>"
                           class="field-input" required>
                </div>
            </div>

            <div class="border-t border-slate-100 pt-4 flex justify-end">
                <button type="submit" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0; padding: 10px 24px;">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
</div>
