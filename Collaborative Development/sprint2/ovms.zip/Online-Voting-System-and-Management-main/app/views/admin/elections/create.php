<div class="section-header">
    <div>
        <h4>Create Election</h4>
        <p>Define a new voting event and set its duration</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/elections" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-chevron-left"></i> Back to List
        </a>
    </div>
</div>

<div class="panel">
    <div class="panel-header panel-header--bordered">
        <h5 class="panel-title">
            <i class="fas fa-plus panel-icon--accent"></i>
            Election Details (Draft Only)
        </h5>
    </div>
    <div class="panel-body">
        <form action="<?= BASE_URL ?>/admin/elections/store" method="POST" class="max-w-2xl">
            <div class="mb-5">
                <label class="field-label">Election Title</label>
                <input type="text" name="title" placeholder="e.g., General Election 2026"
                       class="field-input" required autofocus>
            </div>

            <div class="mb-5">
                <label class="field-label">Election Setup Preset (Auto-Generate Pools)</label>
                <select name="setup_preset" class="field-input">
                    <option value="custom">Custom / Manual Setup (No pools created initially)</option>
                    <option value="national_fptp">National FPTP Only (Auto-generate all FPTP constituencies)</option>
                    <option value="national_pr">National PR Only (Auto-generate all PR lists)</option>
                </select>
                <p class="text-[0.7rem] text-text-muted mt-1">If a preset is chosen, the system will instantly generate the required local voting pools mapped to this election.</p>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-5">
                <div>
                    <label class="field-label">Voting Starts At</label>
                    <input type="datetime-local" id="voting_start" name="voting_start" class="field-input" required>
                </div>
                <div>
                    <label class="field-label">Voting Ends At</label>
                    <input type="datetime-local" name="voting_end" class="field-input" required>
                </div>
            </div>

            <div class="bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 mb-5 flex items-start gap-3">
                <i class="fas fa-info-circle text-primary text-[1rem] mt-0.5 flex-shrink-0"></i>
                <p class="text-[0.78rem] text-text-muted m-0">
                    <strong class="text-text-primary">Security Note</strong>: Elections are created in <strong>Draft</strong> status by default.
                    You must manually transition them to <strong>Active</strong> from the edit screen once all candidates and parameters are finalized.
                </p>
            </div>

            <div class="border-t border-slate-100 pt-4 flex justify-end">
                <button type="submit" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0; padding: 10px 24px;">
                    <i class="fas fa-save"></i> Save &amp; Proceed
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const startInput = document.getElementById('voting_start');
    if (startInput && !startInput.value) {
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        startInput.value = now.toISOString().slice(0, 16);
    }
});
</script>
