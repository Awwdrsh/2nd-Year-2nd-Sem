<?php if (!empty($_GET['error'])): ?>
<div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
    <i class="fas fa-exclamation-circle text-red-500"></i>
    <?= $_GET['error'] === 'in_use' ? 'Cannot delete: this election has associated votes or pools.' : htmlspecialchars($_GET['error']) ?>
</div>
<?php endif; ?>

<div class="section-header">
    <div>
        <h4>Elections Management</h4>
        <p>List and control all system-wide election events</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= asset('admin/elections/create') ?>" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-plus"></i> New Election
        </a>
    </div>
</div>

<form method="GET" action="<?= BASE_URL ?>/admin/elections" class="mb-6 flex flex-wrap gap-3 items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200">
    <div class="flex-1 min-w-[200px]">
        <input type="text" name="search" value="<?= htmlspecialchars($search ?? '') ?>" placeholder="Search by election title..." class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary">
    </div>
    <div class="w-48">
        <select name="status" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="">All Statuses</option>
            <option value="draft" <?= ($status ?? '') === 'draft' ? 'selected' : '' ?>>Draft</option>
            <option value="active" <?= ($status ?? '') === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="completed" <?= ($status ?? '') === 'completed' ? 'selected' : '' ?>>Completed</option>
            <option value="cancelled" <?= ($status ?? '') === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
        </select>
    </div>
    <button type="submit" class="px-5 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors shadow-sm flex items-center gap-2">
        <i class="fas fa-filter"></i> Filter
    </button>
    <?php if (!empty($search) || !empty($status)): ?>
        <a href="<?= BASE_URL ?>/admin/elections" class="px-5 py-2 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors border border-slate-200">
            Clear
        </a>
    <?php endif; ?>
</form>

<?php if (empty($elections)): ?>
    <div class="panel">
        <div class="td-empty">
            <i class="fas fa-vote-yea block text-3xl opacity-20 mb-3"></i>
            No elections found. Create your first election to begin.
        </div>
    </div>
<?php else: ?>
    <div class="panel">
        <div class="panel-body-flush">
            <table class="ovms-table">
                <thead>
                    <tr>
                        <th class="th-pl">Title</th>
                        <th>Created By</th>
                        <th>Status</th>
                        <th>Voting Period</th>
                        <th class="td-pr text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($elections as $election):
                        $statusClass = 'status--' . ($election['status'] ?? 'draft');
                        $startTime   = date('M d, Y H:i', strtotime($election['voting_start']));
                        $endTime     = date('M d, Y H:i', strtotime($election['voting_end']));
                    ?>
                    <tr>
                        <td class="th-pl td-bold"><?= htmlspecialchars($election['title']) ?></td>
                        <td><?= htmlspecialchars($election['created_by_name'] ?? 'System') ?></td>
                        <td>
                            <span class="status-badge <?= $statusClass ?>">
                                <?= ucfirst($election['status']) ?>
                            </span>
                        </td>
                        <td class="td-muted text-[0.75rem]">
                            <?= $startTime ?> — <?= $endTime ?>
                        </td>
                        <td class="td-pr text-right">
                            <div class="flex gap-2 justify-end">
                                <a href="<?= asset('admin/elections/edit?id=' . $election['id']) ?>" class="table-link" title="Edit details">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= asset('admin/elections/delete?id=' . $election['id']) ?>" class="table-link text-red-400"
                                   title="Delete" onclick="return confirm('Are you sure you want to delete this election? Status: <?= $election['status'] ?>');">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if (($totalPages ?? 0) > 1): ?>
            <div class="p-4 border-t border-slate-100 flex flex-wrap justify-between items-center bg-slate-50/50 rounded-b-xl gap-4">
                <div class="text-sm text-slate-500 font-medium">
                    Showing page <?= $page ?> of <?= $totalPages ?> (Total: <?= $totalRows ?? 0 ?>)
                </div>
                <div class="flex gap-1">
                    <?php
                    $qs = $_GET;
                    for ($i = 1; $i <= $totalPages; $i++): 
                        $qs['page'] = $i;
                        $url = BASE_URL . '/admin/elections?' . http_build_query($qs);
                        
                        if ($totalPages > 7 && $i > 2 && $i < $totalPages - 1 && abs($i - $page) > 1) {
                            if ($i == 3 || $i == $totalPages - 2) {
                                echo '<span class="px-2 py-1 text-slate-400">...</span>';
                            }
                            continue;
                        }
                    ?>
                        <a href="<?= $url ?>" class="min-w-[32px] h-8 flex items-center justify-center px-2 border rounded-md text-sm font-medium transition-colors <?= $i === $page ? 'bg-primary text-white border-primary shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-50 border-slate-200' ?>">
                            <?= $i ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
