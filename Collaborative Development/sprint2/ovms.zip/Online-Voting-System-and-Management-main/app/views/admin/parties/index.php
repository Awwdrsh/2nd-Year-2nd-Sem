<div class="section-header">
    <div class="section-header-text">
        <h4>Political Parties</h4>
        <p>Registry of registered political organizations for election participation</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/parties/create" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-plus"></i> Add New Party
        </a>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <i class="fas fa-check-circle info-icon--green"></i>
            <span class="text-emerald-700 font-semibold">Party details saved successfully.</span>
        </div>
    </div>
<?php endif; ?>

<form method="GET" action="<?= BASE_URL ?>/admin/parties" class="mb-6 flex flex-wrap gap-3 items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200">
    <div class="flex-1 min-w-[200px]">
        <input type="text" name="search" value="<?= htmlspecialchars($search ?? '') ?>" placeholder="Search by party name or abbreviation..." class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary">
    </div>
    <div class="w-48">
        <select name="status" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="">All Statuses</option>
            <option value="active" <?= ($status ?? '') === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= ($status ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
        </select>
    </div>
    <div class="w-48">
        <select name="sort" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="name_asc" <?= ($sort ?? '') === 'name_asc' ? 'selected' : '' ?>>Name (A-Z)</option>
            <option value="name_desc" <?= ($sort ?? '') === 'name_desc' ? 'selected' : '' ?>>Name (Z-A)</option>
            <option value="newest" <?= ($sort ?? '') === 'newest' ? 'selected' : '' ?>>Newest First</option>
        </select>
    </div>
    <button type="submit" class="px-5 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors shadow-sm flex items-center gap-2">
        <i class="fas fa-filter"></i> Filter
    </button>
    <?php if (!empty($search) || !empty($status) || ($sort ?? 'name_asc') !== 'name_asc'): ?>
        <a href="<?= BASE_URL ?>/admin/parties" class="px-5 py-2 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors border border-slate-200">
            Clear
        </a>
    <?php endif; ?>
</form>

<div class="panel">
    <div class="panel-body-flush">
        <table class="ovms-table">
            <thead>
                <tr>
                    <th class="th-pl">Logo / Symbol</th>
                    <th>Party Name &amp; Abbr.</th>
                    <th>Status</th>
                    <th>Date Registered</th>
                    <th class="td-pr text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($parties)): ?>
                    <tr>
                        <td colspan="5" class="td-empty py-8">
                            <i class="fas fa-search block text-3xl opacity-20 mb-3"></i>
                            No political parties found matching your criteria.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($parties as $party): ?>
                        <tr>
                            <td class="th-pl">
                                <div class="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center border border-slate-200">
                                    <?php if ($party['symbol_url']): ?>
                                        <?php 
                                            $symbolUrl = $party['symbol_url'];
                                            if (!filter_var($symbolUrl, FILTER_VALIDATE_URL) && strpos($symbolUrl, 'data:image') !== 0 && !str_starts_with($symbolUrl, '/')) {
                                                $symbolUrl = BASE_URL . '/' . ltrim($symbolUrl, '/');
                                            }
                                        ?>
                                        <img src="<?= htmlspecialchars($symbolUrl) ?>" alt="Symbol" class="max-w-[30px] max-h-[30px] object-contain">
                                    <?php else: ?>
                                        <i class="fas fa-flag text-slate-300"></i>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div class="flex flex-col gap-0.5">
                                    <span class="td-bold"><?= htmlspecialchars($party['name']) ?></span>
                                    <span class="activity-module"><?= htmlspecialchars($party['abbreviation']) ?></span>
                                </div>
                            </td>
                            <td>
                                <?php if ($party['is_active']): ?>
                                    <span class="status-badge status--active">Active</span>
                                <?php else: ?>
                                    <span class="status-badge status--cancelled">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="td-muted"><?= date('d M Y', strtotime($party['created_at'])) ?></span>
                            </td>
                            <td class="td-pr text-right">
                                <div class="flex gap-2 justify-end">
                                    <a href="<?= BASE_URL ?>/admin/parties/edit?id=<?= $party['id'] ?>" class="table-link" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= BASE_URL ?>/admin/parties/delete?id=<?= $party['id'] ?>"
                                       class="table-link text-red-400"
                                       onclick="return confirm('Delete this party? All associated candidates will lose their party affiliation.')"
                                       title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if (($totalPages ?? 0) > 1): ?>
        <div class="p-4 border-t border-slate-100 flex flex-wrap justify-between items-center bg-slate-50/50 rounded-b-xl gap-4">
            <div class="text-sm text-slate-500 font-medium">
                Showing page <?= $page ?> of <?= $totalPages ?> (Total: <?= $totalRows ?? 0 ?>)
            </div>
            <div class="flex gap-1">
                <?php
                $qs = $_GET;
                for ($i = 1; $i <= $totalPages; $i++): 
                    $qs['page'] = $i;
                    $url = BASE_URL . '/admin/parties?' . http_build_query($qs);
                    
                    if ($totalPages > 7 && $i > 2 && $i < $totalPages - 1 && abs($i - $page) > 1) {
                        if ($i == 3 || $i == $totalPages - 2) {
                            echo '<span class="px-2 py-1 text-slate-400">...</span>';
                        }
                        continue;
                    }
                ?>
                    <a href="<?= $url ?>" class="min-w-[32px] h-8 flex items-center justify-center px-2 border rounded-md text-sm font-medium transition-colors <?= $i === $page ? 'bg-primary text-white border-primary shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-50 border-slate-200' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
