<div class="section-header">
    <div>
        <h4>Edit Political Party</h4>
        <p>Update organization details and participation status</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/parties" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>
</div>

<?php if (isset($_GET['error'])): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <i class="fas fa-exclamation-circle info-icon--red"></i>
            <span class="text-red-600 font-semibold">
                <?php
                    if ($_GET['error'] === 'missing_fields') echo "Required fields are missing. Please complete all fields.";
                    if ($_GET['error'] === 'exists')         echo "This party name or abbreviation already exists.";
                ?>
            </span>
        </div>
    </div>
<?php endif; ?>

<div class="panel">
    <div class="panel-header panel-header--bordered">
        <h5 class="panel-title"><i class="fas fa-edit panel-icon--accent"></i> Update Party: <?= htmlspecialchars($party['name']) ?></h5>
    </div>
    <div class="panel-body">
        <form action="<?= BASE_URL ?>/admin/parties/update" method="POST" class="max-w-xl">
            <input type="hidden" name="id" value="<?= $party['id'] ?>">

            <div class="mb-4">
                <label for="name" class="field-label">Party Full Name</label>
                <input type="text" id="name" name="name" class="field-input"
                       value="<?= htmlspecialchars($party['name']) ?>" required>
            </div>

            <div class="mb-4">
                <label for="abbreviation" class="field-label">Abbreviation</label>
                <input type="text" id="abbreviation" name="abbreviation" class="field-input"
                       value="<?= htmlspecialchars($party['abbreviation']) ?>" required>
            </div>

            <div class="mb-4">
                <label for="symbol_url" class="field-label">Symbol URL (Logo)</label>
                <input type="url" id="symbol_url" name="symbol_url" class="field-input"
                       value="<?= htmlspecialchars($party['symbol_url'] ?? '') ?>" placeholder="https://example.com/logo.png">
            </div>

            <div class="mb-6">
                <label class="flex items-center gap-2.5 cursor-pointer">
                    <input type="checkbox" name="is_active" value="1" <?= $party['is_active'] ? 'checked' : '' ?>
                           class="w-4 h-4 rounded border-slate-300 text-primary focus:ring-primary/20">
                    <span class="text-[0.82rem] font-semibold text-text-primary">Party is active and eligible for elections</span>
                </label>
            </div>

            <div class="border-t border-slate-100 pt-4 flex justify-end gap-2.5">
                <a href="<?= BASE_URL ?>/admin/parties" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">Cancel Edit</a>
                <button type="submit" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
                    <i class="fas fa-check"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
</div>
