<div class="section-header">
    <div>
        <h4>Register Political Party</h4>
        <p>Introduce a new political organization to the election registry</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/parties" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>
</div>

<?php if (isset($_GET['error'])): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <i class="fas fa-exclamation-circle info-icon--red"></i>
            <span class="text-red-600 font-semibold">
                <?php
                    if ($_GET['error'] === 'missing_fields') echo "Required fields are missing. Please complete all fields.";
                    if ($_GET['error'] === 'email_exists')   echo "This party name or abbreviation already exists.";
                ?>
            </span>
        </div>
    </div>
<?php endif; ?>

<div class="panel">
    <div class="panel-header panel-header--bordered">
        <h5 class="panel-title"><i class="fas fa-flag panel-icon--accent"></i> Organisation Details</h5>
    </div>
    <div class="panel-body">
        <form action="<?= BASE_URL ?>/admin/parties/store" method="POST" class="max-w-xl">
            <div class="mb-4">
                <label for="name" class="field-label">Party Full Name</label>
                <input type="text" id="name" name="name" class="field-input" required placeholder="Ex: Nepali Congress">
            </div>

            <div class="mb-4">
                <label for="abbreviation" class="field-label">Abbreviation / Code</label>
                <input type="text" id="abbreviation" name="abbreviation" class="field-input" required placeholder="Ex: NC">
            </div>

            <div class="mb-6">
                <label for="symbol_url" class="field-label">Party Symbol URL (Logo)</label>
                <input type="url" id="symbol_url" name="symbol_url" class="field-input" placeholder="https://example.com/logo.png">
                <p class="text-[0.71rem] text-text-muted mt-1">Enter the direct URL to the party symbol or logo image.</p>
            </div>

            <div class="border-t border-slate-100 pt-4 flex justify-end gap-2.5">
                <a href="<?= BASE_URL ?>/admin/parties" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">Cancel Registration</a>
                <button type="submit" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
                    <i class="fas fa-save"></i> Register Party
                </button>
            </div>
        </form>
    </div>
</div>
