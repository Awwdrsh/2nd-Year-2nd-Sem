<div class="section-header">
    <div>
        <h4>Add System Officer</h4>
        <p>Assign a new administrator to the voting management platform</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/officers" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>
</div>

<?php if (isset($_GET['error'])): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <i class="fas fa-exclamation-circle info-icon--red"></i>
            <span class="text-red-600 font-semibold">
                <?php
                    if ($_GET['error'] === 'missing_fields') echo "Required fields are missing. Please complete all fields.";
                    if ($_GET['error'] === 'email_exists')   echo "This email is already registered to another officer.";
                ?>
            </span>
        </div>
    </div>
<?php endif; ?>

<div class="panel">
    <div class="panel-header panel-header--bordered">
        <h5 class="panel-title"><i class="fas fa-user-plus panel-icon--accent"></i> Officer Information</h5>
    </div>
    <div class="panel-body">
        <form action="<?= BASE_URL ?>/admin/officers/store" method="POST" class="max-w-xl">
            <div class="mb-4">
                <label for="full_name" class="field-label">Full Name</label>
                <input type="text" id="full_name" name="full_name" class="field-input" required placeholder="Ex: Rajesh Hamal">
            </div>

            <div class="mb-4">
                <label for="email" class="field-label">Email Address</label>
                <input type="email" id="email" name="email" class="field-input" required placeholder="Ex: admin@example.com">
            </div>

            <div class="mb-4">
                <label for="role" class="field-label">Administrative Role</label>
                <select id="role" name="role" class="field-input cursor-pointer">
                    <option value="Officer" selected>Election Officer (Staff)</option>
                    <option value="Admin">System Administrator (Full Control)</option>
                </select>
            </div>

            <div class="mb-6">
                <label for="password" class="field-label">Account Password</label>
                <input type="password" id="password" name="password" class="field-input" required placeholder="Min. 8 characters">
                <p class="text-[0.71rem] text-text-muted mt-1">Provide a secure password for this administrative account.</p>
            </div>

            <div class="border-t border-slate-100 pt-4 flex justify-end gap-2.5">
                <a href="<?= BASE_URL ?>/admin/officers" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">Cancel</a>
                <button type="submit" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
                    <i class="fas fa-save"></i> Save Officer
                </button>
            </div>
        </form>
    </div>
</div>
