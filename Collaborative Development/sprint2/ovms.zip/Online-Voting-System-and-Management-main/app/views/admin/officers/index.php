<?php if ($success || $error): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <?php if ($success): ?>
                <i class="fas fa-check-circle info-icon--green"></i>
                <span class="text-emerald-700 font-semibold">
                    <?php
                        if ($success === 'officer_added')   echo "New officer added successfully.";
                        if ($success === 'officer_updated') echo "Officer updated successfully.";
                        if ($success === 'officer_deleted') echo "Officer removed successfully.";
                    ?>
                </span>
            <?php endif; ?>
            <?php if ($error): ?>
                <i class="fas fa-exclamation-triangle info-icon--amber"></i>
                <span class="text-amber-600 font-semibold">
                    <?php
                        if ($error === 'not_found')      echo "Officer not found.";
                        if ($error === 'self_delete')    echo "You cannot delete your own account.";
                        if ($error === 'missing_fields') echo "Please fill in all required fields.";
                    ?>
                </span>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<div class="section-header">
    <div>
        <h4>System Officers</h4>
        <p>Manage administrative staff and their access levels</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/officers/create" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-plus"></i> Add New Officer
        </a>
    </div>
</div>

<form method="GET" action="<?= BASE_URL ?>/admin/officers" class="mb-6 flex flex-wrap gap-3 items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200">
    <div class="flex-1 min-w-[200px]">
        <input type="text" name="search" value="<?= htmlspecialchars($search ?? '') ?>" placeholder="Search by name or email..." class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary">
    </div>
    <div class="w-48">
        <select name="status" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="">All Roles</option>
            <option value="Admin" <?= ($status ?? '') === 'Admin' ? 'selected' : '' ?>>Admin</option>
            <option value="Officer" <?= ($status ?? '') === 'Officer' ? 'selected' : '' ?>>Officer</option>
        </select>
    </div>
    <div class="w-48">
        <select name="sort" class="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary bg-white">
            <option value="newest" <?= ($sort ?? '') === 'newest' ? 'selected' : '' ?>>Newest First</option>
            <option value="oldest" <?= ($sort ?? '') === 'oldest' ? 'selected' : '' ?>>Oldest First</option>
            <option value="name_asc" <?= ($sort ?? '') === 'name_asc' ? 'selected' : '' ?>>Name (A-Z)</option>
            <option value="name_desc" <?= ($sort ?? '') === 'name_desc' ? 'selected' : '' ?>>Name (Z-A)</option>
        </select>
    </div>
    <button type="submit" class="px-5 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors shadow-sm flex items-center gap-2">
        <i class="fas fa-filter"></i> Filter
    </button>
    <?php if (!empty($search) || !empty($status) || ($sort ?? 'newest') !== 'newest'): ?>
        <a href="<?= BASE_URL ?>/admin/officers" class="px-5 py-2 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors border border-slate-200">
            Clear
        </a>
    <?php endif; ?>
</form>

<div class="panel">
    <div class="panel-body-flush">
        <table class="ovms-table">
            <thead>
                <tr>
                    <th class="th-pl">Officer</th>
                    <th>Role</th>
                    <th>Email</th>
                    <th>Last Login</th>
                    <th class="td-pr text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($officers)): ?>
                <tr>
                    <td colspan="5" class="td-empty py-8">
                        <i class="fas fa-search block text-3xl opacity-20 mb-3"></i>
                        No officers found matching your criteria.
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($officers as $off):
                    $isSelf = ($off['id'] == $_SESSION['admin_id']);
                ?>
                <tr>
                    <td class="th-pl">
                        <div class="flex items-center gap-2.5">
                            <div class="sidebar-avatar text-[0.75rem]">
                                <?= strtoupper(substr($off['full_name'], 0, 1)) ?>
                            </div>
                            <span class="td-bold"><?= htmlspecialchars($off['full_name']) ?></span>
                            <?php if ($isSelf): ?>
                                <span class="status-badge status--active text-[10px] px-1.5 py-0.5">YOU</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <span class="status-badge <?= $off['role'] === 'Admin' ? 'status--completed' : 'status--draft' ?>">
                            <?= strtoupper($off['role']) ?>
                        </span>
                    </td>
                    <td class="td-muted"><?= htmlspecialchars($off['email']) ?></td>
                    <td class="td-muted">
                        <?= $off['last_login'] ? date('d M, H:i', strtotime($off['last_login'])) : 'Never' ?>
                    </td>
                    <td class="td-pr text-right">
                        <div class="flex gap-2 justify-end">
                            <a href="<?= BASE_URL ?>/admin/officers/edit?id=<?= $off['id'] ?>" class="table-link" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php if (!$isSelf): ?>
                            <a href="<?= BASE_URL ?>/admin/officers/delete?id=<?= $off['id'] ?>" class="table-link text-red-400"
                               onclick="return confirm('Permanently remove this officer?');">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if (($totalPages ?? 0) > 1): ?>
        <div class="p-4 border-t border-slate-100 flex flex-wrap justify-between items-center bg-slate-50/50 rounded-b-xl gap-4">
            <div class="text-sm text-slate-500 font-medium">
                Showing page <?= $page ?> of <?= $totalPages ?> (Total: <?= $totalRows ?? 0 ?>)
            </div>
            <div class="flex gap-1">
                <?php
                $qs = $_GET;
                for ($i = 1; $i <= $totalPages; $i++): 
                    $qs['page'] = $i;
                    $url = BASE_URL . '/admin/officers?' . http_build_query($qs);
                    
                    if ($totalPages > 7 && $i > 2 && $i < $totalPages - 1 && abs($i - $page) > 1) {
                        if ($i == 3 || $i == $totalPages - 2) {
                            echo '<span class="px-2 py-1 text-slate-400">...</span>';
                        }
                        continue;
                    }
                ?>
                    <a href="<?= $url ?>" class="min-w-[32px] h-8 flex items-center justify-center px-2 border rounded-md text-sm font-medium transition-colors <?= $i === $page ? 'bg-primary text-white border-primary shadow-sm' : 'bg-white text-slate-600 hover:bg-slate-50 border-slate-200' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
