<div class="section-header">
    <div>
        <h4>Edit System Officer</h4>
        <p>Modify administrative details and security credentials</p>
    </div>
    <div class="section-header-actions">
        <a href="<?= BASE_URL ?>/admin/officers" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>
</div>

<?php if (isset($_GET['error'])): ?>
    <div class="info-strip mb-5">
        <div class="info-strip-item">
            <i class="fas fa-exclamation-circle info-icon--red"></i>
            <span class="text-red-600 font-semibold">
                <?php
                    if ($_GET['error'] === 'missing_fields') echo "Required fields are missing. Please complete all fields.";
                    if ($_GET['error'] === 'email_exists')   echo "This email is already registered to another officer.";
                ?>
            </span>
        </div>
    </div>
<?php endif; ?>

<div class="panel">
    <div class="panel-header panel-header--bordered">
        <h5 class="panel-title"><i class="fas fa-user-edit panel-icon--accent"></i> Update Officer: <?= htmlspecialchars($officer['full_name']) ?></h5>
    </div>
    <div class="panel-body">
        <form action="<?= BASE_URL ?>/admin/officers/update" method="POST" class="max-w-xl">
            <input type="hidden" name="id" value="<?= $officer['id'] ?>">

            <div class="mb-4">
                <label for="full_name" class="field-label">Full Name</label>
                <input type="text" id="full_name" name="full_name" class="field-input"
                       value="<?= htmlspecialchars($officer['full_name']) ?>" required>
            </div>

            <div class="mb-4">
                <label for="email" class="field-label">Email Address</label>
                <input type="email" id="email" name="email" class="field-input"
                       value="<?= htmlspecialchars($officer['email']) ?>" required>
            </div>

            <div class="mb-4">
                <label for="role" class="field-label">Administrative Role</label>
                <select id="role" name="role" class="field-input cursor-pointer"
                        <?= $officer['id'] == $_SESSION['admin_id'] ? 'disabled' : '' ?>>
                    <option value="Officer" <?= $officer['role'] === 'Officer' ? 'selected' : '' ?>>Election Officer (Staff)</option>
                    <option value="Admin"   <?= $officer['role'] === 'Admin'   ? 'selected' : '' ?>>System Administrator (Full Control)</option>
                </select>
                <?php if ($officer['id'] == $_SESSION['admin_id']): ?>
                    <input type="hidden" name="role" value="<?= $officer['role'] ?>">
                    <p class="text-[0.71rem] text-amber-500 mt-1">You cannot change your own administrative role level.</p>
                <?php endif; ?>
            </div>

            <div class="mb-6">
                <label for="password" class="field-label">Change Password</label>
                <input type="password" id="password" name="password" class="field-input"
                       placeholder="Leave blank to keep same password">
                <p class="text-[0.71rem] text-text-muted mt-1">Only provide a password if you want to reset this officer's current password.</p>
            </div>

            <div class="border-t border-slate-100 pt-4 flex justify-end gap-2.5">
                <a href="<?= BASE_URL ?>/admin/officers" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">Cancel Edit</a>
                <button type="submit" class="action-btn action-btn--primary" style="width: auto; margin-bottom: 0;">
                    <i class="fas fa-check"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
</div>
