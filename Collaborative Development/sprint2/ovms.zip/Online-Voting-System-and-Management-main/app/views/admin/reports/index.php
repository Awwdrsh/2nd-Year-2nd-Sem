<div class="section-header">
    <div>
        <h4>System Reports &amp; Analytics</h4>
        <p>Comprehensive overview of election participation and results</p>
    </div>
    <div class="section-header-actions">
        <div class="flex gap-2">
            <a href="<?= BASE_URL ?>/admin/reports/export?type=turnout" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
                <i class="fas fa-file-csv"></i> Export Turnout
            </a>
            <a href="<?= BASE_URL ?>/admin/reports/export?type=candidates" class="action-btn action-btn--outline" style="width: auto; margin-bottom: 0;">
                <i class="fas fa-file-csv"></i> Export Candidates
            </a>
        </div>
    </div>
</div>

<!-- KPI summary cards -->
<div class="grid grid-cols-2 xl:grid-cols-4 gap-3 mb-5">
    <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3 shadow-sm">
        <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-users text-[0.88rem]"></i>
        </div>
        <div>
            <div class="text-[0.6rem] font-bold uppercase tracking-widest text-text-muted mb-0.5">Registered Voters</div>
            <div class="text-[1.4rem] font-bold text-text-primary leading-none tabular-nums"><?= number_format($stats['total_voters']) ?></div>
            <div class="text-[0.68rem] text-text-muted">Total records in system</div>
        </div>
    </div>
    <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3 shadow-sm">
        <div class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-vote-yea text-[0.88rem]"></i>
        </div>
        <div>
            <div class="text-[0.6rem] font-bold uppercase tracking-widest text-text-muted mb-0.5">Total Votes Cast</div>
            <div class="text-[1.4rem] font-bold text-text-primary leading-none tabular-nums"><?= number_format($stats['total_votes']) ?></div>
            <div class="text-[0.68rem] text-text-muted">Verified ballot submissions</div>
        </div>
    </div>
    <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3 shadow-sm">
        <div class="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-chart-line text-[0.88rem]"></i>
        </div>
        <div>
            <div class="text-[0.6rem] font-bold uppercase tracking-widest text-text-muted mb-0.5">Overall Turnout</div>
            <div class="text-[1.4rem] font-bold text-text-primary leading-none tabular-nums"><?= $stats['turnout_rate'] ?>%</div>
            <div class="text-[0.68rem] text-text-muted">Active voters / Registered</div>
        </div>
    </div>
    <div class="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3 shadow-sm">
        <div class="w-10 h-10 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-shield-halved text-[0.88rem]"></i>
        </div>
        <div>
            <div class="text-[0.6rem] font-bold uppercase tracking-widest text-text-muted mb-0.5">Total Elections</div>
            <div class="text-[1.4rem] font-bold text-text-primary leading-none tabular-nums"><?= number_format($stats['total_elections']) ?></div>
            <div class="text-[0.68rem] text-text-muted">Managed via admin portal</div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
    <!-- Turnout by District -->
    <div class="panel">
        <div class="panel-header panel-header--bordered">
            <h6 class="panel-title">
                <i class="fas fa-map-marked-alt panel-icon--accent"></i>Voter Turnout by District
            </h6>
        </div>
        <div class="panel-body-flush">
            <table class="ovms-table">
                <thead>
                    <tr>
                        <th class="th-pl">District Name</th>
                        <th class="td-pr text-right">Registered Voters</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($districtTurnout)): ?>
                        <tr><td colspan="2" class="td-empty">No voter records found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($districtTurnout as $d): ?>
                        <tr>
                            <td class="th-pl td-bold"><?= htmlspecialchars($d['district'] ?: 'Unknown') ?></td>
                            <td class="td-pr text-right font-semibold"><?= number_format($d['total_voters']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Top Performing Candidates -->
    <div class="panel">
        <div class="panel-header panel-header--bordered">
            <h6 class="panel-title">
                <i class="fas fa-crown panel-icon--amber"></i>Top Performing Candidates
            </h6>
        </div>
        <div class="panel-body-flush">
            <table class="ovms-table">
                <thead>
                    <tr>
                        <th class="th-pl">Candidate</th>
                        <th>Party</th>
                        <th class="td-pr text-right">Vote Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($candidateVotes)): ?>
                        <tr><td colspan="3" class="td-empty">No votes recorded yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($candidateVotes as $c): ?>
                        <tr>
                            <td class="th-pl">
                                <span class="td-bold"><?= htmlspecialchars($c['full_name']) ?></span>
                                <div class="text-[0.68rem] text-text-muted"><?= htmlspecialchars($c['election_title']) ?></div>
                            </td>
                            <td>
                                <span class="status-badge status--completed">
                                    <?= htmlspecialchars($c['party_name']) ?>
                                </span>
                            </td>
                            <td class="td-pr text-right">
                                <span class="td-bold text-primary"><?= number_format($c['vote_count']) ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Party Performance -->
    <div class="panel">
        <div class="panel-header panel-header--bordered">
            <h6 class="panel-title">
                <i class="fas fa-flag panel-icon--teal"></i>Party Performance (PR + FPTP)
            </h6>
        </div>
        <div class="panel-body-flush">
            <table class="ovms-table">
                <thead>
                    <tr>
                        <th class="th-pl">Political Party</th>
                        <th>Abbr.</th>
                        <th class="td-pr text-right">Total Votes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($partyPerformance)): ?>
                        <tr><td colspan="3" class="td-empty">No votes recorded for parties yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($partyPerformance as $p): ?>
                        <tr>
                            <td class="th-pl">
                                <div class="flex items-center gap-3">
                                    <?php if (!empty($p['symbol_url'])): ?>
                                        <img src="<?= htmlspecialchars($p['symbol_url']) ?>" class="w-6 h-6 object-contain" alt="">
                                    <?php endif; ?>
                                    <span class="td-bold"><?= htmlspecialchars($p['name']) ?></span>
                                </div>
                            </td>
                            <td>
                                <span class="status-badge status--upcoming">
                                    <?= htmlspecialchars($p['party']) ?>
                                </span>
                            </td>
                            <td class="td-pr text-right">
                                <span class="td-bold text-emerald-600"><?= number_format($p['vote_count']) ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Demographic Voting Analysis -->
<div class="panel mt-6">
    <div class="panel-header panel-header--bordered">
        <h6 class="panel-title">
            <i class="fas fa-chart-area panel-icon--accent"></i> Demographic Analysis: Votes Cast per Region
        </h6>
    </div>
    <div class="p-6">
        <div class="flex flex-col lg:flex-row gap-8 items-center">
            <div class="w-full lg:w-7/12" style="height: 320px;">
                <canvas id="votesRegionChart"></canvas>
            </div>
            <div class="w-full lg:w-5/12">
                <div class="space-y-4">
                    <h5 class="text-sm font-bold text-gray-700 uppercase tracking-wider">Regional Distribution</h5>
                    <div class="grid grid-cols-1 gap-3">
                        <?php 
                        $colors = ['#2d8f9f', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#3b82f6'];
                        foreach ($votesByRegion as $index => $r): 
                            $percentage = $stats['total_votes'] > 0 ? round(($r['vote_count'] / $stats['total_votes']) * 100, 1) : 0;
                            $color = $colors[$index % count($colors)];
                        ?>
                        <div class="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                            <div class="flex items-center gap-3">
                                <div class="w-3 h-3 rounded-full" style="background-color: <?= $color ?>"></div>
                                <span class="text-[0.82rem] font-semibold text-slate-700"><?= htmlspecialchars($r['region']) ?></span>
                            </div>
                            <div class="text-right">
                                <div class="text-[0.82rem] font-bold text-slate-900"><?= number_format($r['vote_count']) ?></div>
                                <div class="text-[0.65rem] text-slate-400 font-medium"><?= $percentage ?>% of total</div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        
                        <?php if (empty($votesByRegion)): ?>
                        <div class="py-12 text-center text-slate-400">
                            <i class="fas fa-chart-pie text-3xl mb-3 opacity-20"></i>
                            <p class="text-sm italic">No votes have been cast yet to display demographic data.</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('votesRegionChart');
    if (!ctx) return;

    const data = {
        labels: <?= json_encode(array_column($votesByRegion, 'region')) ?>,
        datasets: [{
            label: 'Votes Cast',
            data: <?= json_encode(array_column($votesByRegion, 'vote_count')) ?>,
            backgroundColor: [
                'rgba(45, 143, 159, 0.7)',
                'rgba(16, 185, 129, 0.7)',
                'rgba(245, 158, 11, 0.7)',
                'rgba(239, 68, 68, 0.7)',
                'rgba(139, 92, 246, 0.7)',
                'rgba(59, 130, 246, 0.7)'
            ],
            borderColor: [
                '#2d8f9f',
                '#10b981',
                '#f59e0b',
                '#ef4444',
                '#8b5cf6',
                '#3b82f6'
            ],
            borderWidth: 2,
            borderRadius: 6,
            hoverOffset: 15
        }]
    };

    new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1e293b',
                    titleFont: { size: 13, weight: 'bold' },
                    bodyFont: { size: 12 },
                    padding: 12,
                    cornerRadius: 8,
                    displayColors: false
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { font: { size: 10, weight: '600' }, color: '#94a3b8' }
                },
                y: {
                    grid: { color: 'rgba(0,0,0,0.03)' },
                    ticks: { font: { size: 11, weight: '600' }, color: '#475569' }
                }
            }
        }
    });
});
</script>
