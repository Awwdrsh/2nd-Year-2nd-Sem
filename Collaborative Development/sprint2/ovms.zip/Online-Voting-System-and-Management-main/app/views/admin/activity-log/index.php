<?php
// Map each action constant to a CSS badge class and an icon
$actionIcon = [
    'CREATE' => 'fa-plus-circle',
    'UPDATE' => 'fa-pen',
    'DELETE' => 'fa-trash',
    'READ'   => 'fa-eye',
    'LOGIN'  => 'fa-sign-in-alt',
    'LOGOUT' => 'fa-sign-out-alt',
];

$actionColors = [
    'CREATE' => 'bg-[#dcfce7] text-[#15803d]',
    'UPDATE' => 'bg-[#dbeafe] text-[#1d4ed8]',
    'DELETE' => 'bg-[#fee2e2] text-[#b91c1c]',
    'READ'   => 'bg-[#f1f5f9] text-[#475569]',
    'LOGIN'  => 'bg-[#fef9c3] text-[#854d0e]',
    'LOGOUT' => 'bg-[#f1f5f9] text-[#475569]',
];

// Preserve active filters across pagination links
$filterQs = http_build_query(array_filter([
    'action' => $filterAction,
    'module' => $filterModule,
    'q'      => $search,
]));
$filterQs = $filterQs ? '&' . $filterQs : '';
?>

<!-- Page header -->
<div class="flex items-start justify-between mb-[18px]">
    <div>
        <h4 class="text-[1.02rem] font-bold text-text-primary m-0 mb-[2px]">Audit Log</h4>
        <p class="text-[0.76rem] text-text-muted m-0">
            Complete history of all administrative actions &mdash;
            <?= number_format($totalRows) ?> <?= $totalRows === 1 ? 'entry' : 'entries' ?> recorded
        </p>
    </div>
</div>

<!-- Filter bar -->
<form method="GET" action="" class="flex flex-wrap items-center gap-[10px] mb-[18px]">

    <div class="relative flex-1 min-w-[220px]">
        <i class="fas fa-search absolute left-[11px] top-1/2 -translate-y-1/2 text-text-muted text-[0.79rem] pointer-events-none"></i>
        <input
            type="text"
            name="q"
            class="w-full p-[7px_12px_7px_32px] border border-border rounded-[7px] text-[0.82rem] text-text-primary bg-card-bg outline-none transition-colors duration-150 focus:border-primary"
            placeholder="Search description or admin name&hellip;"
            value="<?= htmlspecialchars($search) ?>"
        >
    </div>

    <select name="action" class="p-[7px_12px] border border-border rounded-[7px] text-[0.82rem] text-text-primary bg-card-bg outline-none cursor-pointer transition-colors duration-150 focus:border-primary">
        <option value="">All actions</option>
        <?php foreach (array_keys($actionIcon) as $act): ?>
        <option value="<?= $act ?>" <?= $filterAction === $act ? 'selected' : '' ?>>
            <?= $act ?>
        </option>
        <?php endforeach; ?>
    </select>

    <?php if (!empty($modules)): ?>
    <select name="module" class="p-[7px_12px] border border-border rounded-[7px] text-[0.82rem] text-text-primary bg-card-bg outline-none cursor-pointer transition-colors duration-150 focus:border-primary">
        <option value="">All modules</option>
        <?php foreach ($modules as $mod): ?>
        <option value="<?= htmlspecialchars($mod) ?>" <?= $filterModule === $mod ? 'selected' : '' ?>>
            <?= htmlspecialchars($mod) ?>
        </option>
        <?php endforeach; ?>
    </select>
    <?php endif; ?>

    <button type="submit" class="inline-flex items-center gap-[6px] p-[7px_16px] rounded-[7px] text-[0.8rem] font-semibold bg-primary text-white border-none cursor-pointer transition-opacity duration-150 hover:opacity-[0.86]">
        <i class="fas fa-filter"></i> Filter
    </button>

    <?php if ($filterAction || $filterModule || $search): ?>
    <a href="?" class="inline-flex items-center gap-[6px] p-[7px_16px] rounded-[7px] text-[0.8rem] font-semibold bg-border text-text-muted no-underline transition-opacity duration-150 hover:opacity-[0.86]">
        <i class="fas fa-times"></i> Clear
    </a>
    <?php endif; ?>

</form>

<!-- Log table -->
<div class="panel">
    <div class="panel-body-flush">
        <table class="ovms-table">
            <thead>
                <tr>
                    <th class="pl-5">Time</th>
                    <th>Admin</th>
                    <th>Action</th>
                    <th>Module</th>
                    <th>Description</th>
                    <th>Record</th>
                    <th class="pr-4">IP Address</th>
                </tr>
            </thead>
            <tbody>

            <?php if (empty($logs)): ?>
                <tr>
                    <td colspan="7">
                        <div class="text-center py-[52px] px-[20px] text-text-muted">
                            <i class="fas fa-clipboard-list block text-[2rem] opacity-[0.28] mb-[10px]"></i>
                            <p class="text-[0.83rem] m-0">
                                <?= ($filterAction || $filterModule || $search)
                                    ? 'No entries match your current filters.'
                                    : 'No administrative activity has been recorded yet.' ?>
                            </p>
                        </div>
                    </td>
                </tr>

            <?php else: ?>
            <?php foreach ($logs as $log):
                $icon = $actionIcon[$log['action']] ?? 'fa-circle';
                $color = $actionColors[$log['action']] ?? 'bg-[#f1f5f9] text-[#475569]';
            ?>
                <tr>
                    <td class="pl-5 whitespace-nowrap min-w-[110px]">
                        <span class="block text-[0.74rem] text-text-muted"><?= date('d M Y', strtotime($log['created_at'])) ?></span>
                        <span class="block text-[0.8rem] font-semibold text-text-primary"><?= date('H:i:s',  strtotime($log['created_at'])) ?></span>
                    </td>
                    <td class="font-semibold"><?= htmlspecialchars($log['admin_name']) ?></td>
                    <td>
                        <span class="inline-flex items-center gap-[5px] text-[0.67rem] font-bold tracking-[0.4px] px-[9px] py-[3px] rounded-pill whitespace-nowrap <?= $color ?>">
                            <i class="fas <?= $icon ?> text-[0.59rem]"></i>
                            <?= $log['action'] ?>
                        </span>
                    </td>
                    <td class="text-[0.79rem] text-text-muted"><?= htmlspecialchars($log['module']) ?></td>
                    <td class="max-w-[320px]"><?= htmlspecialchars($log['description']) ?></td>
                    <td class="text-[0.79rem] text-text-muted">
                        <?= $log['record_id'] ? '#' . (int) $log['record_id'] : '&mdash;' ?>
                    </td>
                    <td class="pr-4">
                        <span class="font-mono text-[0.73rem] text-text-muted bg-[#f1f5f9] py-[2px] px-[6px] rounded-[4px]"><?= htmlspecialchars($log['ip_address']) ?></span>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php endif; ?>

            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="flex items-center justify-between p-[12px_20px] border-t border-border">
        <span class="text-[0.77rem] text-text-muted">
            Page <?= $page ?> of <?= $totalPages ?> &mdash; <?= number_format($totalRows) ?> total entries
        </span>
        <div class="flex gap-[6px]">
            <?php if ($page > 1): ?>
                <a href="?page=<?= ($page - 1) . $filterQs ?>" class="inline-flex items-center p-[5px_13px] border border-border rounded-[6px] text-[0.77rem] font-semibold text-primary no-underline bg-card-bg transition-all duration-150 hover:bg-primary hover:text-white hover:border-primary">&larr; Previous</a>
            <?php endif; ?>
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= ($page + 1) . $filterQs ?>" class="inline-flex items-center p-[5px_13px] border border-border rounded-[6px] text-[0.77rem] font-semibold text-primary no-underline bg-card-bg transition-all duration-150 hover:bg-primary hover:text-white hover:border-primary">Next &rarr;</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
