<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP | OVMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        :root {
            --color-sidebar: #1c2b3a;
            --color-primary: #2d8f9f;
        }
        .bg-sidebar  { background-color: var(--color-sidebar); }
        .bg-primary  { background-color: var(--color-primary); }
        .text-primary  { color: var(--color-primary); }
        .border-primary { border-color: var(--color-primary); }

        /* OTP digit box — individual character input */
        .otp-box {
            width: 48px;
            height: 58px;
            text-align: center;
            font-size: 1.5rem;
            font-weight: 700;
            border: 2px solid #cbd5e1;
            border-radius: 10px;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
            color: #1e293b;
            background: #f8fafc;
        }
        .otp-box:focus {
            border-color: var(--color-primary);
            box-shadow: 0 0 0 3px rgba(45, 143, 159, 0.18);
            background: #fff;
        }
        .otp-box.filled {
            border-color: var(--color-primary);
            background: #fff;
        }

        /* Shake animation for wrong OTP */
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%       { transform: translateX(-6px); }
            40%       { transform: translateX(6px); }
            60%       { transform: translateX(-4px); }
            80%       { transform: translateX(4px); }
        }
        .shake { animation: shake 0.4s ease; }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">

    <!-- Top Status Bar — matches login.php -->
    <div class="bg-sidebar text-white/60 text-[0.68rem] font-medium tracking-wide h-[28px] flex items-center px-5">
        Election Commission of Nepal &mdash; Central Administrative Portal
    </div>

    <!-- Site Header — matches login.php -->
    <header class="bg-white border-b border-slate-200 h-[58px] flex items-stretch shadow-sm">
        <div class="w-[220px] flex-shrink-0 flex items-center gap-2.5 px-4 border-r border-slate-200">
            <div class="w-8 h-8 rounded-lg bg-primary text-white text-[0.82rem] flex items-center justify-center flex-shrink-0">
                <i class="fas fa-shield-halved"></i>
            </div>
            <div class="flex flex-col leading-tight">
                <span class="text-[0.82rem] font-bold text-slate-800">Nepal E-Voting</span>
                <span class="text-[0.6rem] text-slate-400">ECN Administration</span>
            </div>
        </div>
        <div class="flex-1"></div>
        <div class="flex items-center gap-4 px-5 flex-shrink-0">
            <span class="text-[0.65rem] font-bold tracking-wide px-2.5 py-1 rounded-full bg-slate-800 text-white flex items-center gap-1.5">
                <i class="fas fa-lock text-[0.6rem]"></i> Secure Area
            </span>
        </div>
    </header>

    <!-- Main Content — same split-panel layout as login.php -->
    <main class="flex flex-col md:flex-row min-h-[calc(100vh-86px)]">

        <!-- Left Info Panel -->
        <div class="bg-slate-900 text-white w-full md:w-1/2 p-10 md:p-16 flex flex-col justify-center">

            <div class="mb-6 inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-primary/20 text-primary">
                <i class="fas fa-envelope-open-text text-xl"></i>
            </div>

            <h2 class="text-3xl font-semibold mb-4 text-white">Two-Factor Verification</h2>
            <p class="text-slate-400 text-sm mb-8 max-w-md">
                A 6-digit verification code has been sent to the email address associated with your admin account.
                Enter it within 10 minutes to complete your sign-in.
            </p>

            <!-- Masked email display -->
            <div class="border border-white/10 bg-white/5 rounded-xl p-5 mb-6">
                <div class="text-[0.68rem] font-bold text-slate-500 uppercase tracking-widest mb-2">Code sent to</div>
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <i class="fas fa-envelope text-primary text-xs"></i>
                    </div>
                    <span class="text-white font-semibold text-sm"><?= htmlspecialchars($masked_email ?? '***@***') ?></span>
                </div>
            </div>

            <!-- Expiry countdown -->
            <div class="border border-white/10 bg-white/5 rounded-xl p-5">
                <h3 class="text-sm font-semibold mb-4 text-white uppercase tracking-wider opacity-80">Security Notes</h3>
                <ul class="space-y-4 text-sm text-slate-300">
                    <li class="flex items-start">
                        <i class="fas fa-clock mt-0.5 mr-3 text-primary"></i>
                        <span>Code expires in <strong id="countdown" class="text-white"><?= (int)($otp_remaining ?? 600) ?></strong> seconds</span>
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-shield-halved mt-0.5 mr-3 text-primary"></i>
                        <span>Maximum 5 attempts — account locks on excess failures</span>
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-rotate mt-0.5 mr-3 text-primary"></i>
                        <span>Use the resend link if the email did not arrive within 60 seconds</span>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Right Form Panel -->
        <div class="w-full md:w-1/2 flex items-center justify-center p-8 bg-white">
            <div class="max-w-md w-full">

                <div class="mb-8">
                    <h2 class="text-2xl font-bold text-slate-800 mb-1">Enter Verification Code</h2>
                    <p class="text-sm text-slate-500">Check your inbox and type the 6-digit code below</p>
                </div>

                <!-- Alert Messages -->
                <?php if (($error ?? '') === 'invalid_otp'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-exclamation-circle"></i>
                        <span>Incorrect or expired code. Please try again.</span>
                    </div>
                <?php elseif (($error ?? '') === 'empty_otp'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-exclamation-circle"></i>
                        <span>Please enter the 6-digit code before submitting.</span>
                    </div>
                <?php elseif (($error ?? '') === 'expired'): ?>
                    <div class="alert bg-amber-50 border-l-4 border-amber-500 text-amber-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-clock"></i>
                        <span>Your code has expired. Please sign in again to request a new one.</span>
                    </div>
                <?php elseif (($error ?? '') === 'locked'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-lock"></i>
                        <span>Too many failed attempts. Please sign in again.</span>
                    </div>
                <?php elseif (($error ?? '') === 'resend_wait'): ?>
                    <div class="alert bg-amber-50 border-l-4 border-amber-500 text-amber-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-hourglass-half"></i>
                        <span>Please wait 60 seconds before requesting a new code.</span>
                    </div>
                <?php elseif (($error ?? '') === 'resend_failed'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-triangle-exclamation"></i>
                        <span>Failed to resend the code. Check mail configuration.</span>
                    </div>
                <?php elseif (($success ?? '') === 'resent'): ?>
                    <div class="alert bg-emerald-50 border-l-4 border-emerald-500 text-emerald-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-check-circle"></i>
                        <span>A new verification code has been sent to your email.</span>
                    </div>
                <?php endif; ?>

                <!-- OTP Entry Form -->
                <form action="<?= BASE_URL ?>/admin/otp/verify" method="POST" id="otp-form">
                    <!-- Hidden field carries the assembled 6-digit code on submit -->
                    <input type="hidden" name="otp" id="otp-hidden">

                    <div class="mb-8">
                        <label class="block text-[0.7rem] font-bold text-slate-500 uppercase tracking-widest mb-4">
                            6-Digit Verification Code
                        </label>

                        <!-- Six individual digit boxes -->
                        <div class="flex gap-2 justify-center" id="otp-boxes">
                            <input class="otp-box" type="text" inputmode="numeric" maxlength="1" autocomplete="off" id="otp-0">
                            <input class="otp-box" type="text" inputmode="numeric" maxlength="1" autocomplete="off" id="otp-1">
                            <input class="otp-box" type="text" inputmode="numeric" maxlength="1" autocomplete="off" id="otp-2">

                            <!-- Visual separator between digit groups -->
                            <div class="flex items-center text-slate-300 font-bold text-lg px-1">—</div>

                            <input class="otp-box" type="text" inputmode="numeric" maxlength="1" autocomplete="off" id="otp-3">
                            <input class="otp-box" type="text" inputmode="numeric" maxlength="1" autocomplete="off" id="otp-4">
                            <input class="otp-box" type="text" inputmode="numeric" maxlength="1" autocomplete="off" id="otp-5">
                        </div>
                    </div>

                    <!-- Submit Button — same style as login.php -->
                    <button type="submit" id="submit-btn"
                            class="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-xl active:scale-[0.98] flex items-center justify-center gap-3 text-sm tracking-wide disabled:opacity-50 disabled:cursor-not-allowed"
                            disabled>
                        <i class="fas fa-shield-check"></i> Verify &amp; Access Portal
                    </button>
                </form>

                <!-- Action Links -->
                <div class="mt-6 flex items-center justify-between">
                    <a href="<?= BASE_URL ?>/admin/otp/resend"
                       class="text-xs text-primary hover:underline flex items-center gap-1.5 transition-colors">
                        <i class="fas fa-rotate text-[0.65rem]"></i> Resend Code
                    </a>
                    <a href="<?= BASE_URL ?>/admin/login"
                       class="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1.5 transition-colors">
                        <i class="fas fa-arrow-left text-[0.65rem]"></i> Back to Login
                    </a>
                </div>

                <div class="mt-8 pt-6 border-t border-slate-100 text-center">
                    <p class="text-[0.7rem] text-slate-400 flex items-center justify-center gap-2">
                        <i class="fas fa-shield-check text-emerald-500"></i>
                        Encrypted Connection &bull; Audit Logging Active
                    </p>
                </div>
            </div>
        </div>
    </main>

    <script>
        // ── OTP Box Controller ─────────────────────────────────────────────
        // Handles auto-advance, backspace navigation, paste, and assembles
        // all 6 digits into the hidden input before form submission.

        const boxes     = Array.from(document.querySelectorAll('.otp-box'));
        const hidden    = document.getElementById('otp-hidden');
        const submitBtn = document.getElementById('submit-btn');
        const form      = document.getElementById('otp-form');

        // Rebuilds the hidden OTP value and toggles the submit button state
        function syncHidden() {
            const value = boxes.map(b => b.value).join('');
            hidden.value = value;
            submitBtn.disabled = (value.length < 6 || value.includes(' '));

            // Mark filled boxes visually
            boxes.forEach(b => {
                b.classList.toggle('filled', b.value.length === 1);
            });
        }

        // Allow only digits 0–9 in each box, auto-advance on valid entry
        boxes.forEach((box, idx) => {
            box.addEventListener('input', () => {
                // Strip any non-digit characters pasted or typed
                box.value = box.value.replace(/\D/g, '').slice(-1);

                if (box.value && idx < boxes.length - 1) {
                    boxes[idx + 1].focus();
                }
                syncHidden();
            });

            // Backspace on empty box moves focus to the previous box
            box.addEventListener('keydown', e => {
                if (e.key === 'Backspace' && !box.value && idx > 0) {
                    boxes[idx - 1].focus();
                }
                // Enter key submits if all 6 digits are filled
                if (e.key === 'Enter' && !submitBtn.disabled) {
                    form.submit();
                }
            });
        });

        // Handle clipboard paste on any box — fills all boxes in sequence
        boxes[0].addEventListener('paste', e => {
            e.preventDefault();
            const pasted = (e.clipboardData || window.clipboardData)
                            .getData('text')
                            .replace(/\D/g, '')
                            .slice(0, 6);
            pasted.split('').forEach((ch, i) => {
                if (boxes[i]) boxes[i].value = ch;
            });
            syncHidden();
            // Move focus to the next unfilled box (or the last one)
            const nextEmpty = boxes.find(b => !b.value);
            (nextEmpty || boxes[boxes.length - 1]).focus();
        });

        // Shake the input row if an error param is present in the URL
        (function markError() {
            const params = new URLSearchParams(window.location.search);
            if (params.get('error') === 'invalid_otp') {
                document.getElementById('otp-boxes').classList.add('shake');
                // Clear all boxes so user starts fresh
                boxes.forEach(b => { b.value = ''; b.classList.remove('filled'); });
                syncHidden();
                boxes[0].focus();
            }
        })();

        // Focus the first box on page load
        boxes[0].focus();

        // ── OTP Expiry Countdown ──────────────────────────────────────────
        // Reads the remaining-seconds value rendered by PHP and ticks down.
        // When it hits zero, redirects to the login page with an error flag.

        let remaining = parseInt('<?= (int)($otp_remaining ?? 600) ?>', 10);
        const countdownEl = document.getElementById('countdown');

        function formatSeconds(s) {
            const m = Math.floor(s / 60);
            const sec = s % 60;
            return m + ':' + String(sec).padStart(2, '0');
        }

        if (countdownEl) {
            countdownEl.textContent = formatSeconds(remaining);
            const timer = setInterval(() => {
                remaining--;
                if (remaining <= 0) {
                    clearInterval(timer);
                    countdownEl.textContent = '0:00';
                    window.location.href = '<?= BASE_URL ?>/admin/login?error=otp_expired';
                } else {
                    countdownEl.textContent = formatSeconds(remaining);
                    // Turn countdown red in the last 60 seconds
                    if (remaining <= 60) {
                        countdownEl.style.color = '#ef4444';
                    }
                }
            }, 1000);
        }

        // Auto-dismiss alert messages after 6 seconds
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.alert').forEach(el => {
                setTimeout(() => {
                    el.style.opacity = '0';
                    el.style.transition = 'opacity 0.5s';
                    setTimeout(() => el.remove(), 500);
                }, 6000);
            });
        });
    </script>

</body>
</html>
