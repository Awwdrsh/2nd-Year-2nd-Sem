<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Voter Login | OVMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        :root {
            --color-sidebar: #1c2b3a;
            --color-primary: #2d8f9f;
        } 
        .bg-sidebar { background-color: var(--color-sidebar); }
        .bg-primary  { background-color: var(--color-primary); }
        .text-primary { color: var(--color-primary); }
        .border-primary { border-color: var(--color-primary); }
        input:focus { outline: none; border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(45,143,159,0.15); }
    </style>
</head>
<body class="bg-gray-100">

    <div class="bg-sidebar text-white/60 text-[0.68rem] font-medium tracking-wide h-[28px] flex items-center px-5">
        Election Commission of Nepal &mdash; Voter Portal
    </div>

    <header class="bg-white border-b border-slate-200 h-[58px] flex items-stretch shadow-sm">
        <div class="w-[220px] flex-shrink-0 flex items-center gap-2.5 px-4 border-r border-slate-200">
            <div class="w-8 h-8 rounded-lg bg-primary text-white text-[0.82rem] flex items-center justify-center flex-shrink-0">
                <i class="fas fa-vote-yea"></i>
            </div>
            <div class="flex flex-col leading-tight">
                <span class="text-[0.82rem] font-bold text-slate-800">Nepal E-Voting</span>
                <span class="text-[0.6rem] text-slate-400">Election Commission of Nepal</span>
            </div>
        </div>
        <div class="flex-1"></div>
        <div class="flex items-center gap-4 px-5 flex-shrink-0">
            <a href="<?= asset('results') ?>" class="text-sm font-semibold text-slate-600 hover:text-primary transition-colors flex items-center gap-1.5"><i class="fas fa-chart-bar"></i> Live Results</a>
            <span class="text-[0.65rem] font-bold tracking-wide px-2.5 py-1 rounded-full bg-primary text-white">
                Voter Portal
            </span>
        </div>
    </header>

    <main class="flex flex-col md:flex-row min-h-[calc(100vh-86px)]">

        <div class="bg-slate-900 text-white w-full md:w-1/2 p-10 md:p-16 flex flex-col justify-center">
            <h2 class="text-3xl font-semibold mb-4 text-white">Sign in to cast your vote</h2>
            <p class="text-white text-sm mb-8">
                Only registered voters with a valid Nepal citizenship number may access this portal.
            </p>
            <div class="border border-white/20 rounded-xl p-6">
                <h3 class="text-sm font-medium mb-3 text-white">Your rights as a voter</h3>
                <ul class="space-y-2 text-sm text-white">
                    <li><i class="fas fa-check mr-2 text-primary"></i> Your vote is secret</li>
                    <li><i class="fas fa-check mr-2 text-primary"></i> One vote per election</li>
                    <li><i class="fas fa-check mr-2 text-primary"></i> You get a confirmation receipt</li>
                </ul>
            </div>
        </div>

        <div class="w-full md:w-1/2 flex items-center justify-center p-8 bg-white">
            <div class="max-w-md w-full">

                <div class="flex items-center gap-2 mb-2">
                    <i class="fas fa-vote-yea text-primary text-xl"></i>
                    <h2 class="text-2xl font-semibold text-slate-800">Voter Sign in</h2>
                </div>
                <p class="text-sm text-primary mb-6">Use your citizenship number and voter ID</p>

                <?php
                $errorMessages = [
                    'invalid'          => ['icon' => 'fa-exclamation-circle', 'msg' => 'Invalid NID or Voter ID. Please try again.'],
                    'invalid_nid'      => ['icon' => 'fa-exclamation-circle', 'msg' => 'NID must be 10–13 digits with numbers only.'],
                    'locked'           => ['icon' => 'fa-lock',               'msg' => 'Account locked for 15 minutes after 5 failed attempts.'],
                    'already_voted'    => ['icon' => 'fa-ban',                'msg' => 'You have already voted in all active polls.'],
                    'timeout'          => ['icon' => 'fa-clock',              'msg' => 'Your session expired after 5 minutes of inactivity. Please sign in again.'],
                    'concurrent'       => ['icon' => 'fa-triangle-exclamation','msg' => 'You have been signed out because another login was detected for this account.'],
                    'voting_completed' => ['icon' => 'fa-ban',                'msg' => 'Login disabled: Voting completed. You have already cast your vote in all available elections.'],
                ];
                if (!empty($error) && isset($errorMessages[$error])):
                    $e = $errorMessages[$error];
                    $isCompleted = ($error === 'voting_completed');
                ?>
                <div class="<?= $isCompleted
                    ? 'bg-blue-50 border-l-4 border-blue-500 text-blue-700'
                    : 'bg-red-50 border-l-4 border-red-500 text-red-700'
                ?> p-3 mb-5 text-sm rounded">
                    <i class="fas <?= $e['icon'] ?> mr-2"></i> <?= $e['msg'] ?>
                </div>
                <?php endif; ?>

                <form method="POST" action="<?= asset('voter/login/submit') ?>">
                    <div class="mb-4">
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                            Citizenship Number (NID)
                        </label>
                        <div class="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20">
                            <span class="px-3 text-slate-400 border-r border-slate-300 py-2.5">
                                <i class="fas fa-id-card text-sm"></i>
                            </span>
                            <input type="text" name="nid" required maxlength="13"
                                   class="flex-1 px-3 py-2.5 text-sm border-0 focus:ring-0 focus:outline-none"
                                   placeholder="e.g. xxxxxxxxxxxxx">
                        </div>
                        <p class="text-xs text-slate-400 mt-1">10–13 digit numeric ID on your citizenship card</p>
                    </div>

                    <div class="mb-4">
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                            Voter ID
                        </label>
                        <div class="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20">
                            <span class="px-3 text-slate-400 border-r border-slate-300 py-2.5">
                                <i class="fas fa-vote-yea text-sm"></i>
                            </span>
                            <input type="text" name="voter_id" required
                                   class="flex-1 px-3 py-2.5 text-sm border-0 focus:ring-0 focus:outline-none"
                                   placeholder="e.g. VTR-xxxx-xxxxxx">
                        </div>
                    </div>

                    <div class="mb-6">
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                            Password
                        </label>
                        <div class="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20">
                            <span class="px-3 text-slate-400 border-r border-slate-300 py-2.5">
                                <i class="fas fa-lock text-sm"></i>
                            </span>
                            <input type="password" name="password" required
                                   class="flex-1 px-3 py-2.5 text-sm border-0 focus:ring-0 focus:outline-none"
                                   placeholder="••••••••">
                        </div>
                        <p class="text-[0.65rem] text-slate-400 mt-1">Format: <code>pwd(Citizenship Number)</code></p>
                    </div>

                    <button type="submit"
                            class="w-full bg-primary hover:opacity-90 text-white font-semibold py-2.5 rounded-lg transition flex items-center justify-center gap-2 text-sm">
                        <i class="fas fa-arrow-right-to-bracket"></i> Sign in
                    </button>
                </form>

                <div class="mt-6 text-center text-xs text-slate-400 border-t pt-4">
                    <i class="fas fa-shield-alt mr-1"></i>
                    Secured connection • Sessions expire after 5 minutes
                </div>
            </div>
        </div>
    </main>
</body>
</html>
