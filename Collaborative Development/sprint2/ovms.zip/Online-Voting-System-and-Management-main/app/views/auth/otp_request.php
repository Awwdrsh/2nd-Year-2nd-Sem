<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request OTP | OVMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        :root { --color-sidebar: #1c2b3a; --color-primary: #2d8f9f; }
        .bg-sidebar  { background-color: var(--color-sidebar); }
        .bg-primary  { background-color: var(--color-primary); }
        .text-primary  { color: var(--color-primary); }
        .border-primary { border-color: var(--color-primary); }
        input:focus { outline: none; border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(45,143,159,0.15); }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">

    <!-- Top Status Bar -->
    <div class="bg-sidebar text-white/60 text-[0.68rem] font-medium tracking-wide h-[28px] flex items-center px-5">
        Election Commission of Nepal &mdash; Central Administrative Portal
    </div>

    <!-- Header -->
    <header class="bg-white border-b border-slate-200 h-[58px] flex items-stretch shadow-sm">
        <div class="w-[220px] flex-shrink-0 flex items-center gap-2.5 px-4 border-r border-slate-200">
            <div class="w-8 h-8 rounded-lg bg-primary text-white text-[0.82rem] flex items-center justify-center flex-shrink-0">
                <i class="fas fa-shield-halved"></i>
            </div>
            <div class="flex flex-col leading-tight">
                <span class="text-[0.82rem] font-bold text-slate-800">Nepal E-Voting</span>
                <span class="text-[0.6rem] text-slate-400">ECN Administration</span>
            </div>
        </div>
        <div class="flex-1"></div>
        <div class="flex items-center gap-4 px-5 flex-shrink-0">
            <span class="text-[0.65rem] font-bold tracking-wide px-2.5 py-1 rounded-full bg-slate-800 text-white flex items-center gap-1.5">
                <i class="fas fa-lock text-[0.6rem]"></i> Secure Area
            </span>
        </div>
    </header>

    <!-- Main Split Panel -->
    <main class="flex flex-col md:flex-row min-h-[calc(100vh-86px)]">

        <!-- Left Info Panel -->
        <div class="bg-slate-900 text-white w-full md:w-1/2 p-10 md:p-16 flex flex-col justify-center">

            <div class="mb-6 inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-primary/20 text-primary">
                <i class="fas fa-paper-plane text-xl"></i>
            </div>

            <h2 class="text-3xl font-semibold mb-4 text-white">Step 2 of 3 — Email Verification</h2>
            <p class="text-slate-400 text-sm mb-8 max-w-md">
                Your credentials have been verified. To proceed, confirm your registered email address
                below. A one-time verification code will be sent to that address.
            </p>

            <div class="border border-white/10 bg-white/5 rounded-xl p-6">
                <h3 class="text-sm font-semibold mb-4 text-white uppercase tracking-wider opacity-80">How it works</h3>
                <ul class="space-y-4 text-sm text-slate-300">
                    <li class="flex items-start">
                        <i class="fas fa-check-circle mt-0.5 mr-3 text-primary"></i>
                        <span>Enter the email address linked to your admin account</span>
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle mt-0.5 mr-3 text-primary"></i>
                        <span>A 6-digit code is sent to that address via secure mail</span>
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle mt-0.5 mr-3 text-primary"></i>
                        <span>Enter the code on the next page to complete sign-in</span>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Right Form Panel -->
        <div class="w-full md:w-1/2 flex items-center justify-center p-8 bg-white">
            <div class="max-w-md w-full">

                <div class="mb-8">
                    <h2 class="text-2xl font-bold text-slate-800 mb-1">Confirm Your Email</h2>
                    <p class="text-sm text-slate-500">Enter your registered admin email to receive the OTP</p>
                </div>

                <!-- Alert Messages -->
                <?php if (($error ?? '') === 'email_mismatch'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-exclamation-circle"></i>
                        <span>That email does not match your registered account address. Please try again.</span>
                    </div>
                <?php elseif (($error ?? '') === 'send_failed'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm">
                        <i class="fas fa-triangle-exclamation"></i>
                        <span>The OTP email could not be delivered. Please check your mail configuration.</span>
                    </div>
                <?php endif; ?>

                <!-- Email Submission Form -->
                <form action="<?= BASE_URL ?>/admin/otp/request/submit" method="POST">

                    <div class="mb-6">
                        <label class="block text-[0.7rem] font-bold text-slate-500 uppercase tracking-widest mb-2">
                            Registered Email Address
                        </label>
                        <div class="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                            <span class="px-3.5 text-slate-400 border-r border-slate-300 py-3 bg-slate-50">
                                <i class="fas fa-envelope text-sm"></i>
                            </span>
                            <input type="email" name="email" required autofocus
                                   class="flex-1 px-4 py-3 text-[0.95rem] border-0 focus:ring-0 focus:outline-none placeholder-slate-300"
                                   placeholder="admin@ovms.gov.np">
                        </div>
                    </div>

                    <button type="submit"
                            class="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-xl active:scale-[0.98] flex items-center justify-center gap-3 text-sm tracking-wide">
                        <i class="fas fa-paper-plane"></i> Send Verification Code
                    </button>
                </form>

                <div class="mt-6 text-center">
                    <a href="<?= BASE_URL ?>/admin/login"
                       class="text-xs text-slate-400 hover:text-slate-600 flex items-center justify-center gap-1.5 transition-colors">
                        <i class="fas fa-arrow-left text-[0.65rem]"></i> Back to Login
                    </a>
                </div>

                <div class="mt-8 pt-6 border-t border-slate-100 text-center">
                    <p class="text-[0.7rem] text-slate-400 flex items-center justify-center gap-2">
                        <i class="fas fa-shield-check text-emerald-500"></i>
                        Encrypted Connection &bull; Audit Logging Active
                    </p>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Auto-dismiss alerts after 6 seconds
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.alert').forEach(el => {
                setTimeout(() => {
                    el.style.opacity = '0';
                    el.style.transition = 'opacity 0.5s';
                    setTimeout(() => el.remove(), 500);
                }, 6000);
            });
        });
    </script>

</body>
</html>
