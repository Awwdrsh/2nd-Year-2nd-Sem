<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | OVMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        :root {
            --color-sidebar: #1c2b3a;
            --color-primary: #2d8f9f;
        } 
        .bg-sidebar { background-color: var(--color-sidebar); }
        .bg-primary  { background-color: var(--color-primary); }
        .text-primary { color: var(--color-primary); }
        .border-primary { border-color: var(--color-primary); }
        input:focus { outline: none; border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(45,143,159,0.15); }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">

    <!-- Top Status Bar -->
    <div class="bg-sidebar text-white/60 text-[0.68rem] font-medium tracking-wide h-[28px] flex items-center px-5">
        Election Commission of Nepal &mdash; Central Administrative Portal
    </div>

    <!-- Header -->
    <header class="bg-white border-b border-slate-200 h-[58px] flex items-stretch shadow-sm">
        <div class="w-[220px] flex-shrink-0 flex items-center gap-2.5 px-4 border-r border-slate-200">
            <div class="w-8 h-8 rounded-lg bg-primary text-white text-[0.82rem] flex items-center justify-center flex-shrink-0">
                <i class="fas fa-shield-halved"></i>
            </div>
            <div class="flex flex-col leading-tight">
                <span class="text-[0.82rem] font-bold text-slate-800">Nepal E-Voting</span>
                <span class="text-[0.6rem] text-slate-400">ECN Administration</span>
            </div>
        </div>
        <div class="flex-1"></div>
        <div class="flex items-center gap-4 px-5 flex-shrink-0">
            <a href="<?= asset('results') ?>" class="text-sm font-semibold text-slate-600 hover:text-primary transition-colors flex items-center gap-1.5">
                <i class="fas fa-chart-bar"></i> Live Results
            </a>
            <span class="text-[0.65rem] font-bold tracking-wide px-2.5 py-1 rounded-full bg-slate-800 text-white flex items-center gap-1.5">
                <i class="fas fa-lock text-[0.6rem]"></i> Secure Area
            </span>
        </div>
    </header>

    <main class="flex flex-col md:flex-row min-h-[calc(100vh-86px)]">

        <!-- Left Info Panel -->
        <div class="bg-slate-900 text-white w-full md:w-1/2 p-10 md:p-16 flex flex-col justify-center">
            <div class="mb-6 inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-primary/20 text-primary">
                <i class="fas fa-user-shield text-xl"></i>
            </div>
            <h2 class="text-3xl font-semibold mb-4 text-white">System Administration</h2>
            <p class="text-slate-400 text-sm mb-8 max-w-md">
                This portal is for authorized Election Commission officers only. All administrative actions are recorded in the system audit log for security purposes.
            </p>
            
            <div class="border border-white/10 bg-white/5 rounded-xl p-6">
                <h3 class="text-sm font-semibold mb-4 text-white uppercase tracking-wider opacity-80">Officer Responsibilities</h3>
                <ul class="space-y-4 text-sm text-slate-300">
                    <li class="flex items-start">
                        <i class="fas fa-check-circle mt-0.5 mr-3 text-primary"></i>
                        <span>Maintain system integrity and voter confidentiality</span>
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle mt-0.5 mr-3 text-primary"></i>
                        <span>Monitor live election metrics and participation</span>
                    </li>
                    <li class="flex items-start">
                        <i class="fas fa-check-circle mt-0.5 mr-3 text-primary"></i>
                        <span>Manage candidate nominations and election pools</span>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Right Form Panel -->
        <div class="w-full md:w-1/2 flex items-center justify-center p-8 bg-white">
            <div class="max-w-md w-full">
                
                <div class="mb-8">
                    <h2 class="text-2xl font-bold text-slate-800 mb-1">Admin Sign in</h2>
                    <p class="text-sm text-slate-500">Access the administrative dashboard</p>
                </div>

                <!-- Alert Messages -->
                <?php if ($error === 'invalid'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm transition-all duration-300">
                        <i class="fas fa-exclamation-circle"></i>
                        <span>Invalid email or password. Please try again.</span>
                    </div>
                <?php elseif ($error === 'invalid_captcha'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm transition-all duration-300">
                        <i class="fas fa-shield-virus"></i>
                        <span>Security code incorrect. Please refresh and try again.</span>
                    </div>
                <?php elseif ($error === 'locked'): ?>
                    <div class="alert bg-red-50 border-l-4 border-red-500 text-red-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm transition-all duration-300">
                        <i class="fas fa-lock"></i>
                        <span>Account locked. Try again in <?= htmlspecialchars($locked) ?> mins.</span>
                    </div>
                <?php elseif ($error === 'timeout'): ?>
                    <div class="alert bg-amber-50 border-l-4 border-amber-500 text-amber-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm transition-all duration-300">
                        <i class="fas fa-clock"></i>
                        <span>Session expired. Please sign in again.</span>
                    </div>
                <?php elseif ($error === 'concurrent'): ?>
                    <div class="alert bg-amber-50 border-l-4 border-amber-500 text-amber-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm transition-all duration-300">
                        <i class="fas fa-triangle-exclamation"></i>
                        <span>You have been signed out because another login was detected for this account.</span>
                    </div>
                <?php elseif ($logout): ?>
                    <div class="alert bg-emerald-50 border-l-4 border-emerald-500 text-emerald-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm transition-all duration-300">
                        <i class="fas fa-check-circle"></i>
                        <span>Successfully signed out.</span>
                    </div>
                <?php elseif (isset($_GET['success']) && $_GET['success'] === 'db_synced'): ?>
                    <div class="alert bg-emerald-50 border-l-4 border-emerald-500 text-emerald-700 p-3 mb-6 text-sm flex items-center gap-3 rounded shadow-sm transition-all duration-300">
                        <i class="fas fa-database"></i>
                        <span>Database synchronized! Voter passwords and candidate fields have been updated.</span>
                    </div>
                <?php endif; ?>

                <form action="<?= asset('admin/login/submit') ?>" method="POST">
                    <div class="mb-5">
                        <label class="block text-[0.7rem] font-bold text-slate-500 uppercase tracking-widest mb-2">
                            Work Email
                        </label>
                        <div class="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                            <span class="px-3.5 text-slate-400 border-r border-slate-300 py-3 bg-slate-50">
                                <i class="fas fa-envelope text-sm"></i>
                            </span>
                            <input type="email" name="email" required autofocus
                                   class="flex-1 px-4 py-3 text-[0.95rem] border-0 focus:ring-0 focus:outline-none placeholder-slate-300"
                                   placeholder="admin@ovms.gov.np" value="<?= htmlspecialchars($email) ?>">
                        </div>
                    </div>

                    <div class="mb-6">
                        <label class="block text-[0.7rem] font-bold text-slate-500 uppercase tracking-widest mb-2">
                            Password
                        </label>
                        <div class="flex items-center border border-slate-300 rounded-lg overflow-hidden focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                            <span class="px-3.5 text-slate-400 border-r border-slate-300 py-3 bg-slate-50">
                                <i class="fas fa-key text-sm"></i>
                            </span>
                            <input type="password" name="password" required
                                   class="flex-1 px-4 py-3 text-[0.95rem] border-0 focus:ring-0 focus:outline-none placeholder-slate-300"
                                   placeholder="••••••••">
                        </div>
                    </div>

                    <!-- Captcha Section -->
                    <div class="mb-8 p-4 bg-slate-50 border border-slate-200 rounded-xl">
                        <label class="block text-[0.7rem] font-bold text-slate-500 uppercase tracking-widest mb-3">
                            Security Verification
                        </label>
                        <div class="flex gap-4 items-center mb-4">
                            <div class="relative group">
                                <img src="<?= asset('admin/captcha') ?>" alt="Captcha" 
                                     class="rounded-lg border border-slate-300 h-12 shadow-sm" 
                                     id="captcha-img">
                                <div class="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg pointer-events-none"></div>
                            </div>
                            <button type="button" onclick="document.getElementById('captcha-img').src='<?= asset('admin/captcha') ?>?'+Math.random();"
                                    class="w-10 h-10 flex items-center justify-center rounded-full bg-white border border-slate-200 text-primary hover:bg-primary hover:text-white hover:border-primary transition-all shadow-sm"
                                    title="Refresh security code">
                                <i class="fas fa-rotate text-sm"></i>
                            </button>
                        </div>
                        <div class="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                            <span class="px-3.5 text-slate-400 border-r border-slate-300 py-3">
                                <i class="fas fa-shield-halved text-sm"></i>
                            </span>
                            <input type="text" name="captcha" required
                                   class="flex-1 px-4 py-3 text-[0.95rem] border-0 focus:ring-0 focus:outline-none"
                                   placeholder="Type the code EXACTLY as shown (case-sensitive)">
                        </div>
                    </div>

                    <button type="submit"
                            class="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-xl active:scale-[0.98] flex items-center justify-center gap-3 text-sm tracking-wide">
                        <i class="fas fa-sign-in-alt"></i> Authenticate & Access Portal
                    </button>
                </form>

                <div class="mt-8 pt-6 border-t border-slate-100 text-center">
                    <p class="text-[0.7rem] text-slate-400 flex items-center justify-center gap-2">
                        <i class="fas fa-shield-check text-emerald-500"></i>
                         Encrypted Connection • Audit Logging Active
                    </p>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Auto-hide alert messages after 5 seconds
        document.addEventListener('DOMContentLoaded', () => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateY(-10px)';
                    setTimeout(() => alert.remove(), 500);
                }, 5000);
            });
        });
    </script>

</body>
</html>
