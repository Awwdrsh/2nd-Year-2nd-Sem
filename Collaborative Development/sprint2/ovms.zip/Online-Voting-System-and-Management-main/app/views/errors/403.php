<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>403 Forbidden — OVMS</title></head>
<body style="font-family:sans-serif;text-align:center;padding:60px">
    <h1>403</h1>
    <p>You do not have permission to view this page.</p>
    <a href="/">Go Home</a>
</body>
</html>
