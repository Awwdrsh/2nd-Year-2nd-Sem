<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>404 Not Found — OVMS</title></head>
<body style="font-family:sans-serif;text-align:center;padding:60px">
    <h1>404</h1>
    <p>Page not found.</p>
    <a href="/">Go Home</a>
</body>
</html>
