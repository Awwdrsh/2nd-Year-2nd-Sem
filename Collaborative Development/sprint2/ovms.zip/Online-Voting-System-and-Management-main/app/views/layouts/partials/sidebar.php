<aside id="admin-sidebar" class="fixed top-[28px] lg:top-[28px] bottom-0 left-0 w-[220px] bg-sidebar flex flex-col overflow-y-auto no-scrollbar z-[200] transition-transform duration-300 -translate-x-full lg:translate-x-0">

    <!-- Brand block -->
    <div class="flex items-center gap-2.5 px-4 py-4 border-b border-white/[0.06] flex-shrink-0">
        <div
            class="w-8 h-8 rounded-lg bg-primary text-white text-[0.82rem] flex items-center justify-center flex-shrink-0">
            <i class="fas fa-shield-halved"></i>
        </div>
        <div class="flex flex-col leading-tight">
            <span class="text-[0.82rem] font-bold text-white">Nepal E-Voting</span>
            <span class="text-[0.6rem] text-white/40">ECN Central Administration</span>
        </div>
    </div>

    <nav class="py-3 flex-1 flex flex-col gap-3 px-2">

        <!-- Unified Navigation Container -->
        <div
            style="background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); border-radius:10px; padding: 6px 0 6px 0;">
            
            <!-- Unified Menu List -->
            <?php
            $adminLinks = [
                // Primary
                ['/admin/dashboard', 'fa-gauge-high', 'Dashboard'],
                ['/admin/voters', 'fa-magnifying-glass', 'Voter Search'],
                ['/admin/voters/activity', 'fa-user-clock', 'Voter Activity'],
                ['/admin/candidates', 'fa-users-gear', 'Candidates'],
                ['/admin/pools',     'fa-layer-group', 'Election Pools'],
                ['/admin/reports', 'fa-chart-pie', 'Result and Analysis'],
                // Management
                ['/admin/elections', 'fa-vote-yea', 'Elections'],
                ['/admin/officers', 'fa-user-shield', 'Officers'],
                ['/admin/parties', 'fa-flag', 'Political parties'],
                // Security
                ['/admin/profile', 'fa-user-circle', 'My Profile'],
                ['/admin/activity-log', 'fa-book', 'Audit log'],
            ];

            foreach ($adminLinks as [$path, $icon, $label]):
                $href = asset($path);
                $uriPath = parse_url($uri, PHP_URL_PATH);
                
                // Exact match first
                $isActive = ($uriPath === $href);
                
                // Prefix match for sub-pages (e.g. /admin/voters/show should highlight /admin/voters)
                // But avoid highlighting if a more specific link (like /admin/voters/activity) exists
                if (!$isActive && strpos($uriPath, $href . '/') === 0) {
                    $isActive = true;
                    foreach ($adminLinks as [$p, $i, $l]) {
                        $h = asset($p);
                        if ($h !== $href && strpos($uriPath, $h) === 0 && strlen($h) > strlen($href)) {
                            $isActive = false;
                            break;
                        }
                    }
                }

                $active = $isActive
                    ? 'text-white bg-primary font-semibold'
                    : 'text-white/50 hover:text-white/80 hover:bg-white/5';
                ?>
                <a href="<?= $href ?>"
                    class="flex items-center gap-2.5 mx-1 px-3 py-[7px] rounded-lg text-[0.79rem] no-underline transition-all <?= $active ?>">
                    <i class="fas <?= $icon ?> w-4 text-[0.75rem] text-center flex-shrink-0"></i>
                    <span class="whitespace-nowrap"><?= $label ?></span>
                </a>
            <?php endforeach; ?>
        </div>

    </nav>

    <!-- Version info -->
    <div class="px-4 py-3 border-t border-white/[0.06] flex-shrink-0">
        <div class="flex items-center gap-2 text-[0.6rem] text-white/20">
            <i class="fas fa-circle text-[0.35rem]"></i>
            <span>Nepal E-Voting v1.0</span>
        </div>
    </div>

</aside>