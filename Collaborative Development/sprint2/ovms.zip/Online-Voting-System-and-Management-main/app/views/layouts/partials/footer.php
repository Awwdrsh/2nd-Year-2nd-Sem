<footer class="ml-[220px] p-6 border-t border-slate-100 text-center text-[0.7rem] text-text-muted">
    &copy; <?= date('Y') ?> Election Commission of Nepal. All rights reserved.
</footer>
