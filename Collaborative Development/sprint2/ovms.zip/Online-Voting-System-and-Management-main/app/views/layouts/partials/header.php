<!-- Fixed top bar -->
<div class="fixed top-0 left-0 right-0 h-[28px] bg-sidebar text-white/70 text-[0.68rem] font-medium tracking-wide flex items-center px-5 z-[400]">
    Election Commission of Nepal &mdash; Central Administration
</div>

<header class="fixed top-[28px] left-0 lg:left-[220px] right-0 h-[58px] bg-white border-b border-slate-200 flex items-stretch z-[300]">
    <!-- Mobile Toggle -->
    <button class="sidebar-toggle flex lg:hidden items-center justify-center px-4 text-text-muted hover:text-primary transition-colors border-r border-slate-100">
        <i class="fas fa-bars-staggered text-[1.1rem]"></i>
    </button>

    <!-- Contextual Stats Bar -->
    <div class="flex-1 flex items-center divide-x divide-slate-100 overflow-x-auto no-scrollbar">
        <div class="px-4 lg:px-6 flex flex-col justify-center min-w-[140px] lg:min-w-[160px]">
            <span class="text-[0.55rem] text-text-muted uppercase tracking-[0.05em] font-bold mb-0.5">Session Identity</span>
            <span class="text-[0.8rem] lg:text-[0.88rem] font-bold text-text-primary leading-tight truncate">Welcome, Admin</span>
        </div>
    </div>

    <!-- Right: admin identity -->
    <div class="hidden md:flex items-center gap-3 px-5 flex-shrink-0 text-[0.8rem]">
        <a href="<?= asset('voter/results') ?>" class="flex items-center gap-2 px-3 py-1.5 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg transition no-underline mr-2">
            <i class="fas fa-chart-pie text-[0.8rem]"></i>
            <span class="text-[0.65rem] font-black uppercase tracking-[0.05em]">See Results</span>
        </a>
        <span class="bg-primary/10 text-primary text-[0.65rem] font-bold tracking-wide px-2.5 py-1 rounded-full"><?= htmlspecialchars($adminRole) ?></span>
        <a href="<?= asset('admin/profile') ?>" class="font-semibold text-text-primary no-underline hover:text-primary transition-colors"><?= htmlspecialchars($adminName) ?></a>
        <a href="<?= asset('admin/logout') ?>" class="text-[0.75rem] text-text-muted no-underline hover:text-red-500 transition-colors ml-1">Sign out</a>
    </div>

    <!-- Mobile Admin Icon -->
    <div class="flex md:hidden items-center px-4 border-l border-slate-100">
        <a href="<?= asset('admin/profile') ?>" class="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-text-muted">
            <i class="fas fa-user-circle text-[1.1rem]"></i>
        </a>
    </div>
</header>
