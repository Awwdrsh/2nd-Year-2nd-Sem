<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? 'Admin Dashboard') ?> — OVMS</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- External Dependencies -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= asset('public/assets/css/style.css') ?>" rel="stylesheet">
    
    <!-- CSS Strategy: Optimized for Subfolder Hosting -->
    <script>
        window.OVMS_BASE = '<?= BASE_URL ?>';
    </script>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#2d8f9f',
                        sidebar: '#1c2b3a',
                        'text-primary': '#0f172a',
                        'text-muted': '#64748b',
                    },
                    fontFamily: {
                        inter: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>

    <!-- Essential Component Styles (Fail-safe for Hosting Issues) -->
    <style>
        :root {
            --primary: #2d8f9f;
            --sidebar: #1c2b3a;
            --text-main: #0f172a;
            --text-sub: #64748b;
            --bg-page: #f8fafc;
        }
        
        body { font-family: 'Inter', sans-serif; background-color: var(--bg-page); color: var(--text-main); line-height: 1.5; margin: 0; }

        /* Layout & Sidebar */
        .bg-sidebar { background-color: var(--sidebar) !important; }
        .bg-primary { background-color: var(--primary) !important; }
        .text-primary { color: var(--primary) !important; }
        .border-primary { border-color: var(--primary) !important; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        
        /* Headers */
        .section-header { margin-bottom: 1.5rem; display: flex; align-items: flex-start; justify-content: space-between; }
        .section-header h4 { font-size: 1.1rem; font-weight: 700; margin: 0 0 0.25rem 0; color: var(--text-main); }
        .section-header p { font-size: 0.78rem; color: var(--text-sub); margin: 0; }

        /* Tables */
        .ovms-table { width: 100%; border-collapse: collapse; font-size: 0.82rem; background: white; }
        .ovms-table thead th { 
            background: #f8fafc; padding: 0.875rem 1rem; text-align: left; 
            font-size: 0.68rem; font-weight: 700; text-transform: uppercase; 
            letter-spacing: 0.8px; color: #94a3b8; border-bottom: 1px solid #e2e8f0;
        }
        .ovms-table tbody td { padding: 0.875rem 1rem; border-bottom: 1px solid #f1f5f9; color: var(--text-main); vertical-align: middle; }
        .ovms-table tbody tr:hover { background: #f8fafc; }
        .th-pl { padding-left: 1.5rem !important; }
        .td-pr { padding-right: 1.5rem !important; }
        .td-bold { font-weight: 700; }
        .td-medium { font-weight: 600; }
        .td-muted { color: var(--text-sub); }
        .td-empty { padding: 3rem; text-align: center; color: var(--text-sub); font-size: 0.85rem; }

        /* Panels */
        .panel { background: white; border: 1px solid #e2e8f0; border-radius: 0.8rem; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .panel-header { padding: 1.1rem 1.5rem; border-bottom: 1px solid #f1f5f9; display: flex; align-items: center; justify-content: space-between; }
        .panel-title { font-size: 0.85rem; font-weight: 700; color: var(--text-main); margin: 0; display: flex; align-items: center; gap: 0.6rem; }
        .panel-body-flush { padding: 0; }
        
        /* Badges & Buttons */
        .status-badge { display: inline-flex; align-items: center; gap: 0.3rem; border-radius: 50px; padding: 0.25rem 0.75rem; font-size: 0.68rem; font-weight: 700; }
        .status--active { background: #ecfdf5; color: #047857; }
        .status--cancelled { background: #fef2f2; color: #b91c1c; }
        .status--draft { background: #f1f5f9; color: #64748b; }
        
        .table-link { font-size: 0.75rem; font-weight: 600; text-decoration: none; color: var(--text-sub); transition: color 0.2s; display: inline-flex; align-items: center; gap: 0.4rem; }
        .table-link:hover { color: var(--primary); }
        
        /* Form Fields */
        .panel-body { padding: 1.25rem; }
        .field-group { margin-bottom: 1rem; }
        .field-label { display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-sub); margin-bottom: 0.375rem; }
        .field-input { 
            width: 100%; border-radius: 0.5rem; border: 1px solid #e2e8f0; background-color: #fff; 
            padding: 0.625rem 0.75rem; font-size: 0.875rem; color: var(--text-main); transition: all 0.15s; 
        }
        .field-input:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(45, 143, 159, 0.1); }
        textarea.field-input { min-height: 120px; resize: vertical; }

        /* Grid System Fallback */
        .grid { display: grid; }
        .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
        .gap-4 { gap: 1rem; }
        .gap-6 { gap: 1.5rem; }
        .mb-4 { margin-bottom: 1rem; }
        .mb-6 { margin-bottom: 1.5rem; }
        
        @media (min-width: 768px) {
            .md\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (min-width: 1024px) {
            .lg\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
            .lg\:col-span-2 { grid-column: span 2 / span 2; }
            .lg\:col-span-1 { grid-column: span 1 / span 1; }
        }

        /* Utility Helpers */
        .flex { display: flex; }
        .items-center { align-items: center; }
        .justify-end { justify-content: flex-end; }
        .gap-2 { gap: 0.5rem; }
        .gap-2\.5 { gap: 0.625rem; }
        .gap-4 { gap: 1rem; }
        .bg-slate-50 { background-color: #f8fafc; }
        .rounded-xl { border-radius: 0.75rem; }
        .border { border: 1px solid #e2e8f0; }
        .border-slate-200 { border-color: #e2e8f0; }
        .p-4 { padding: 1rem; }
        .pt-4 { padding-top: 1rem; }
        .border-t { border-top: 1px solid #f1f5f9; }

        /* Buttons */
        .action-btn { 
            display: inline-flex; items-center; gap: 0.5rem; padding: 0.625rem 1rem; 
            border-radius: 0.5rem; font-size: 0.8rem; font-weight: 600; cursor: pointer; 
            transition: all 0.15s; border: none; text-decoration: none; 
        }
        .action-btn--primary { background-color: var(--primary); color: white; }
        .action-btn--primary:hover { opacity: 0.9; }
        .action-btn--outline { background-color: transparent; border: 1px solid #e2e8f0; color: var(--text-main); }
        .action-btn--outline:hover { background-color: #f8fafc; }
    </style>
</head>
