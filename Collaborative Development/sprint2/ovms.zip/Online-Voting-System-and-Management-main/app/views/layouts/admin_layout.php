<?php
/**
 * Admin Layout Template
 *
 * This file serves as the main structure for the administrative dashboard.
 * It is modularized into partials for better maintainability and collaboration.
 */

// Common variables used across layout partials
$uri = $_SERVER['REQUEST_URI'] ?? '';
$adminName = $_SESSION['admin_name'] ?? 'Chief Admin';
$adminRole = $_SESSION['admin_role'] ?? 'CA';

// Calculate initials for avatars
$nameParts = explode(' ', trim($adminName));
$adminInitials = strtoupper(
    substr($nameParts[0], 0, 1) .
    (count($nameParts) > 1 ? substr(end($nameParts), 0, 1) : '')
);

// Fetch global stats for the header if not already provided (e.g. by AdminController)
if (!isset($stats)) {
    $db = Database::getInstance();
    $stats = [
        'total_voters'    => (int) ($db->query("SELECT COUNT(*) AS c FROM users")->fetch()['c'] ?? 0),
        'active_voters'   => (int) ($db->query("SELECT COUNT(DISTINCT voter_hash) AS c FROM votes")->fetch()['c'] ?? 0),
        'total_candidacy' => (int) ($db->query("SELECT COUNT(*) AS c FROM candidates")->fetch()['c'] ?? 0),
        'active_pools'    => (int) ($db->query("SELECT COUNT(*) AS c FROM pools WHERE (status = 'active' OR (status = 'upcoming' AND voting_start <= NOW())) AND status != 'closed'")->fetch()['c'] ?? 0),
    ];
}

require_once __DIR__ . '/partials/head.php';
?>

<body class="bg-slate-50 text-text-primary font-inter leading-normal overflow-x-hidden">

    <?php require_once __DIR__ . '/partials/header.php'; ?>

    <div id="sidebar-overlay" class="fixed inset-0 bg-black/50 z-[150] hidden opacity-0 transition-opacity duration-300 lg:hidden"></div>

    <!-- Layout shell -->
    <div class="flex min-h-screen pt-[86px]">

        <?php require_once __DIR__ . '/partials/sidebar.php'; ?>

        <main class="flex-1 min-w-0 flex flex-col lg:ml-[220px]">
            <div class="p-4 lg:p-6 flex-1">
                <?php require $view_path; ?>
            </div>

            <?php require_once __DIR__ . '/partials/footer.php'; ?>
        </main>

    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.getElementById('admin-sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        const toggles = document.querySelectorAll('.sidebar-toggle');

        function toggleSidebar() {
            if (!sidebar) return;
            sidebar.classList.toggle('-translate-x-full');
            if (overlay) {
                if (overlay.classList.contains('hidden')) {
                    overlay.classList.remove('hidden');
                    setTimeout(() => overlay.classList.remove('opacity-0'), 10);
                } else {
                    overlay.classList.add('opacity-0');
                    setTimeout(() => overlay.classList.add('hidden'), 300);
                }
            }
        }

        toggles.forEach(btn => btn.addEventListener('click', toggleSidebar));
        if (overlay) overlay.addEventListener('click', toggleSidebar);
    });
    </script>

    <?php require_once __DIR__ . '/partials/scripts.php'; ?>
</body>

</html>