<?php 
$current_url = $_SERVER['REQUEST_URI'];
$is_dash = (strpos($current_url, 'dashboard') !== false);
$is_profile = (strpos($current_url, 'profile') !== false);
$is_results = (strpos($current_url, 'results') !== false);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? 'Voter Portal') ?> — OVMS</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- External Dependencies -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#2d8f9f',
                        sidebar: '#1c2b3a',
                    }
                }
            }
        }
    </script>

    <style>
        :root {
            --primary-color: #2d8f9f;
            --primary-hover: #267a88;
            --sidebar-color: #1c2b3a;
            --bg-slate-50: #f8fafc;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-slate-50);
            color: #0f172a;
            overflow-x: hidden;
            -webkit-tap-highlight-color: transparent;
        }

        /* Smooth Page Entrance */
        .page-enter {
            animation: slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #cbd5e1; }

        /* Container Tweaks */
        .container-main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1.5rem;
            min-height: calc(100vh - 64px - 100px);
        }

        @media (max-width: 768px) {
            .container-main {
                padding: 1rem;
                padding-bottom: 5rem; /* Space for bottom nav */
            }
        }

        /* Bottom Nav Glassmorphism */
        .bottom-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-top: 1px solid rgba(226, 232, 240, 0.8);
        }
        
        .nav-item-active {
            color: var(--primary-color);
        }
        .nav-item-active i {
            transform: translateY(-2px);
            text-shadow: 0 4px 10px rgba(45, 143, 159, 0.3);
        }
    </style>
</head>
<body class="bg-slate-50">

<!-- Top Header Bar -->
<header class="h-[64px] bg-white/90 backdrop-blur-md border-b border-slate-200 flex items-center px-4 md:px-6 sticky top-0 z-[100] shadow-sm">
    <div class="flex items-center gap-2 md:gap-3">
        <div class="w-9 h-9 md:w-10 md:h-10 rounded-xl bg-[#2d8f9f] text-white flex items-center justify-center shadow-lg shadow-[#2d8f9f]/20">
            <i class="fas fa-vote-yea text-sm md:text-base"></i>
        </div>
        <div>
            <h1 class="text-xs md:text-sm font-black text-slate-900 leading-none mb-1 uppercase tracking-tight">OVMS</h1>
            <p class="text-[8px] md:text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">Voter Portal</p>
        </div>
    </div>

    <!-- Desktop Actions -->
    <div class="ms-auto hidden md:flex items-center gap-4">


        <a href="javascript:void(0)" onclick="confirmResultsLogout()" class="flex items-center gap-2 px-3 py-1.5 bg-[#2d8f9f]/10 hover:bg-[#2d8f9f]/20 text-[#2d8f9f] rounded-lg no-underline transition-all group">
            <i class="fas fa-chart-pie text-xs group-hover:rotate-12 transition-transform"></i>
            <span class="text-[10px] font-black uppercase tracking-widest">See Results</span>
        </a>


    </div>

    <!-- Mobile Action (Results) -->
    <div class="ms-auto flex md:hidden items-center gap-2">
        <a href="javascript:void(0)" onclick="confirmResultsLogout()" class="w-10 h-10 flex items-center justify-center bg-slate-50 text-[#2d8f9f] rounded-xl border border-slate-100 shadow-sm">
            <i class="fas fa-chart-line"></i>
        </a>
    </div>
</header>

<main class="container-main page-enter">
    <?php require $view_path; ?>
</main>

<!-- Mobile Bottom Navigation -->
<nav class="bottom-nav fixed bottom-0 left-0 right-0 h-[72px] md:hidden flex items-center justify-around px-4 z-[100] pb-safe">

    <a href="<?= BASE_URL ?>/voter/dashboard" class="flex flex-col items-center gap-1 no-underline transition-all <?= $is_dash ? 'nav-item-active' : 'text-slate-400' ?>">
        <i class="fas fa-th-large text-xl transition-transform"></i>
        <span class="text-[10px] font-black uppercase tracking-widest">Dashboard</span>
    </a>
    <a href="javascript:void(0)" onclick="confirmResultsLogout()" class="flex flex-col items-center gap-1 no-underline transition-all <?= $is_results ? 'nav-item-active' : 'text-slate-400' ?>">
        <i class="fas fa-chart-pie text-xl transition-transform"></i>
        <span class="text-[10px] font-black uppercase tracking-widest">Results</span>
    </a>

    <a href="<?= BASE_URL ?>/voter/logout" class="flex flex-col items-center gap-1 no-underline text-slate-400 hover:text-red-500 transition-all">
        <i class="fas fa-power-off text-xl"></i>
        <span class="text-[10px] font-black uppercase tracking-widest">Logout</span>
    </a>
</nav>

<footer class="bg-white border-t py-8 text-center mt-12 mb-20 md:mb-0">
    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-0 px-6">
        &copy; 2026 Online Voting Management System (OVMS) &mdash; Election Commission of Nepal
    </p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Global Session Logic -->
<?php if (Auth::isVoter() && isset($_SESSION['login_time'])): ?>
<script>
(function() {
    const loginTime = <?= (int) $_SESSION['login_time'] ?>;
    const limitSeconds = 10 * 60;

    function updateTimer() {
        const display = document.getElementById('timerDisplay');
        const now = Math.floor(Date.now() / 1000);
        const elapsed = now - loginTime;
        let remaining = limitSeconds - elapsed;

        if (remaining <= 0) {
            window.location.href = '<?= BASE_URL ?>/voter/logout?error=timeout';
            return;
        }

        const minutes = Math.floor(remaining / 60);
        const seconds = remaining % 60;
        if (display) {
            display.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
    }
    updateTimer();
    setInterval(updateTimer, 1000);
})();

function confirmResultsLogout() {
    if (confirm("You are about to exit voter portal and go to results for security purpose. Do you want to proceed?")) {
        window.location.href = "<?= BASE_URL ?>/voter/logout?goto=/results";
    }
}

// Mobile Haptic Feedback Simulation
document.querySelectorAll('a, button').forEach(el => {
    el.addEventListener('touchstart', () => {
        if (window.navigator.vibrate) window.navigator.vibrate(10);
    }, {passive: true});
});
</script>
<?php endif; ?>

</body>
</html>
