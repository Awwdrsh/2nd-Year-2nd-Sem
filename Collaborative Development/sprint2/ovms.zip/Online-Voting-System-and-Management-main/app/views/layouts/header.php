<?php
$currentUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$sessionAdmin = isset($_SESSION['admin_id']);
$sessionVoter = isset($_SESSION['user']);

$timeLeft = 0;
if (($sessionVoter || $sessionAdmin) && isset($_SESSION['last_activity'])) {
    $timeout = $sessionAdmin ? Auth::ADMIN_TIMEOUT : Auth::VOTER_TIMEOUT;
    $elapsed = time() - $_SESSION['last_activity'];
    
    if ($elapsed < $timeout) {
        $timeLeft = $timeout - $elapsed;
    } else {
        $timeLeft = 0;
    }
}

// Route-aware role detection to prevent layout overlap
$onAdminRoute = str_contains($currentUri, '/admin/');
$onVoterRoute = str_contains($currentUri, '/voter/');

if ($onAdminRoute) {
    $isAdmin = $sessionAdmin;
    $isVoter = false;
} else {
    // For Voter routes or Public pages (like /results), prioritize Voter session
    if ($sessionVoter) {
        $isVoter = true;
        $isAdmin = false;
    } else {
        $isAdmin = $sessionAdmin;
        $isVoter = false;
    }
}

$isGuest    = !$isAdmin && !$isVoter;

$displayName = $isAdmin
    ? htmlspecialchars($_SESSION['admin_name'] ?? 'Admin')
    : ($isVoter ? htmlspecialchars($_SESSION['user']['name'] ?? 'Voter') : 'Guest');

$displayRole = $isAdmin ? 'Admin' : ($isVoter ? 'Voter' : 'Public');

// --- THE FIX IS HERE ---
if ($isAdmin) {
    $logoutUrl = asset('admin/logout');           // Admin logout route
} elseif ($isVoter) {
    $logoutUrl = asset('voter/logout');     // Voter logout route
} else {
    $logoutUrl = asset('voter/login');      // Guest login route
}
// -----------------------
$dashboardUrl = $isAdmin 
    ? asset('admin/dashboard') 
    : ($isVoter ? asset('voter/dashboard') : asset(''));

$navItems = [];
if ($isAdmin) {
    $navItems = [
        [asset('admin/dashboard'),    'Dashboard'],
        [asset('admin/elections'),    'Elections'],
        [asset('admin/candidates'),   'Candidates'],
        [asset('admin/voters'),       'Voters'],
        [asset('admin/officers'),     'Officers'],
        [asset('admin/parties'),      'Parties'],
        [asset('admin/reports'),      'Reports'],
        [asset('admin/activity-log'), 'Audit'],
        [asset('voter/results'),            'Results']
    ];
} else if ($isVoter) {
    $navItems = [
        [asset('voter/dashboard'), 'My Ballot'],
        [asset('voter/results'),         'Results']
    ];
    if ($sessionAdmin) {
        $navItems[] = [asset('admin/dashboard'), 'Admin Portal'];
    }
} else {
    $navItems = [
        [asset('voter/results'),         'Results']
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OVMS Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-slate-50">
<style>
    :root {
        --color-sidebar: #1c2b3a;
        --color-primary: #2d8f9f;
        --color-text:    #1e293b;
        --color-muted:   #64748b;
    }
    .bg-sidebar     { background-color: var(--color-sidebar); }
    .text-primary   { color: var(--color-primary) !important; }
    .bg-primary     { background-color: var(--color-primary); }
    .border-primary { border-color: var(--color-primary); }
    .no-scrollbar::-webkit-scrollbar { display: none; }
    body { padding-top: 86px; font-family: 'Inter', sans-serif; }
</style>

<div class="fixed top-0 left-0 right-0 h-[28px] bg-sidebar text-white/60 text-[0.68rem] font-medium tracking-wide flex items-center px-5 z-[400]">
    Election Commission of Nepal &mdash; <?= $isAdmin ? 'Central Administration' : 'Voter Portal' ?>
</div>

<header class="fixed top-[28px] left-0 right-0 h-[58px] bg-white border-b border-slate-200 flex items-stretch z-[300] shadow-sm">
    <a href="<?= $dashboardUrl ?>" class="w-[220px] flex-shrink-0 flex items-center gap-2.5 px-4 border-r border-slate-200 no-underline text-inherit hover:opacity-80 transition-opacity">
        <div class="w-8 h-8 rounded-lg bg-primary text-white text-[0.82rem] flex items-center justify-center flex-shrink-0">
            <i class="fas <?= $isAdmin ? 'fa-shield-halved' : 'fa-vote-yea' ?>"></i>
        </div>
        <div class="flex flex-col leading-tight">
            <span class="text-[0.82rem] font-bold" style="color: var(--color-text)">Nepal E-Voting</span>
            <span class="text-[0.6rem]" style="color: var(--color-muted)"><?= $isAdmin ? 'ECN Central Administration' : 'Election Commission of Nepal' ?></span>
        </div>
    </a>

    <nav class="flex-1 flex items-stretch px-2 overflow-x-auto no-scrollbar">
        <?php foreach ($navItems as [$href, $label]):
            $path = parse_url($href, PHP_URL_PATH);
            $active = str_starts_with($currentUri, $path);
        ?>
        <a href="<?= $href ?>"
           class="inline-flex items-center px-4 text-[0.79rem] font-medium no-underline border-b-2 transition-colors whitespace-nowrap <?= $active ? 'border-primary text-primary font-semibold' : 'border-transparent hover:border-slate-300' ?>"
           style="<?= !$active ? 'color: var(--color-muted)' : '' ?>">
            <?= $label ?>
        </a>
        <?php endforeach; ?>
    </nav>

    <div class="flex items-center gap-3 px-5 flex-shrink-0">
        <?php if ($isVoter): ?>
        <a href="javascript:void(0)" onclick="confirmResultsLogout()" class="flex items-center gap-2 px-3 py-1.5 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg transition no-underline mr-2">
            <i class="fas fa-chart-pie text-[0.8rem]"></i>
            <span class="text-[0.65rem] font-black uppercase tracking-[0.05em]">See Results</span>
        </a>
        <?php elseif ($isAdmin): ?>
        <a href="<?= asset('results') ?>" class="flex items-center gap-2 px-3 py-1.5 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg transition no-underline mr-2">
            <i class="fas fa-chart-pie text-[0.8rem]"></i>
            <span class="text-[0.65rem] font-black uppercase tracking-[0.05em]">See Results</span>
        </a>
        <?php endif; ?>

        <?php if ($isVoter && !$isAdmin): ?>
        <div class="hidden md:flex flex-col items-center">
            <span class="text-[0.6rem]" style="color: var(--color-muted)">Session</span>
            <span id="header-timer" class="text-[0.78rem] font-bold text-primary"><?= floor(Auth::VOTER_TIMEOUT / 60) ?>:00</span>
        </div>
        <div class="w-px h-6 bg-slate-200"></div>
        <?php endif; ?>

        <span class="text-[0.65rem] font-bold tracking-wide px-2.5 py-1 rounded-full bg-primary text-white uppercase"><?= $displayRole ?></span>
        <span class="text-[0.82rem] font-black tracking-tight" style="color: var(--color-text)"><?= $displayName ?></span>
        <a href="<?= $logoutUrl ?>" class="text-[0.75rem] font-bold uppercase tracking-widest no-underline transition-colors hover:text-red-500" style="color: var(--color-muted)"><?= $isGuest ? 'Sign in' : 'Sign out' ?></a>
    </div>
</header>

<?php if ($isVoter && !$isAdmin && $timeLeft > 0): ?>
<script>
(function() {
    let secondsLeft = <?= (int)$timeLeft ?>;
    const display = document.getElementById('header-timer');
    const logoutUrl = '<?= $logoutUrl ?>?error=timeout';

    if (!display) return;

    function updateTimer() {
        if (secondsLeft <= 0) {
            window.location.href = logoutUrl;
            return;
        }

        const minutes = Math.floor(secondsLeft / 60);
        const seconds = secondsLeft % 60;
        display.innerText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        if (secondsLeft <= 60) {
            display.classList.add('text-red-500');
            display.classList.remove('text-primary');
        }
        
        secondsLeft--;
    }

    updateTimer();
    setInterval(updateTimer, 1000);
})();

function confirmResultsLogout() {
    if (confirm("You are about to exit voter portal and go to results for security purpose. Do you want to proceed?")) {
        window.location.href = "<?= BASE_URL ?>/voter/logout?goto=/results";
    }
}
</script>
<?php endif; ?>