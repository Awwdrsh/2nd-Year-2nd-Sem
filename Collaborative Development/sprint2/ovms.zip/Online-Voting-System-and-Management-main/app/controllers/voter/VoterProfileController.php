<?php
/**
 * VoterProfileController
 * Voter can view their profile and apply for candidacy.
 */
class VoterProfileController extends Controller {

    public function index(): void {
        Auth::requireVoter();

        $userId = $_SESSION['user']['id'] ?? 0;
        $db = Database::getInstance();
        $stmt = $db->prepare(
            "SELECT u.id, u.voter_id, u.nid, u.constituency_id, u.created_at,
                    ci.full_name, ci.date_of_birth, ci.citizenship_no, ci.district,
                    ci.municipality, ci.ward_no, ci.photo_url,
                    co.name AS constituency_name
             FROM users u
             JOIN citizens ci ON u.nid = ci.nid
             LEFT JOIN constituencies co ON u.constituency_id = co.id
             WHERE u.id = ?"
        );
        $stmt->execute([$userId]);
        $voter = $stmt->fetch();

        if (!$voter) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=invalid');
        }

        $this->view('voter/profile/index', [
            'title' => 'My Profile',
            'voter' => $voter,
        ]);
    }

    public function update(): void {
        Auth::requireVoter();
        // TODO: Allow voter to update allowed fields (e.g. candidacy application)
    }
}
