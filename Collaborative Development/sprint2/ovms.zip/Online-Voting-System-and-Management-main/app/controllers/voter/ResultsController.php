<?php
class ResultsController extends Controller
{
    public function index(): void
    {
        $db = Database::getInstance();
        $selectedDistrict = $_GET['district'] ?? '';
        $selectedPoolId = (int) ($_GET['pool_id'] ?? 0);

        // 1. Fetch all unique districts for the first filter dropdown
        $districts = $db->query("SELECT DISTINCT district FROM constituencies ORDER BY district")->fetchAll(PDO::FETCH_COLUMN);

        // 2. Fetch pools for the second filter dropdown (optionally filtered by district)
        $poolsQuery = "SELECT p.id, p.title, p.status, c.district 
                       FROM pools p 
                       JOIN constituencies c ON p.constituency_id = c.id";
        $params = [];
        if ($selectedDistrict) {
            $poolsQuery .= " WHERE c.district = ?";
            $params[] = $selectedDistrict;
        }
        $poolsQuery .= " ORDER BY p.voting_end DESC";

        $stmt = $db->prepare($poolsQuery);
        $stmt->execute($params);
        $allPools = $stmt->fetchAll();

        // 3. Determine which pool to show or if we show overall
        $isOverall = false;
        if ($selectedDistrict == '' && !$selectedPoolId) {
            $isOverall = true;
        }

        // 4. Fetch details
        $poolData = null;
        $results = [];

        if ($isOverall) {
            $results = Voting::getOverallPartyResults();
            $poolData = [
                'title' => 'Overall Party Performance',
                'election_title' => 'National Aggregate',
                'constituency_name' => 'All Districts',
                'district' => 'National',
                'pool_type' => 'Aggregate',
                'status' => 'active' // Just to keep badges working
            ];
            $this->log(ActivityLog::READ, 'Results', "Viewed overall national party performance");
        } elseif ($selectedPoolId) {
            $stmt = $db->prepare(
                "SELECT p.*, e.title AS election_title, c.name AS constituency_name, c.district
                 FROM pools p
                 JOIN elections e ON p.election_id = e.id
                 JOIN constituencies c ON p.constituency_id = c.id
                 WHERE p.id = ?"
            );
            $stmt->execute([$selectedPoolId]);
            $poolData = $stmt->fetch();

            if ($poolData) {
                $results = Voting::getVotingResults($selectedPoolId);
                $this->log(ActivityLog::READ, 'Results', "Viewed results for pool #{$selectedPoolId}");
            }
        } elseif ($selectedDistrict) {
            // If district is selected but no pool picked, default to the first pool in that district
            if (!empty($allPools)) {
                $selectedPoolId = (int) $allPools[0]['id'];
                $stmt = $db->prepare(
                    "SELECT p.*, e.title AS election_title, c.name AS constituency_name, c.district
                     FROM pools p
                     JOIN elections e ON p.election_id = e.id
                     JOIN constituencies c ON p.constituency_id = c.id
                     WHERE p.id = ?"
                );
                $stmt->execute([$selectedPoolId]);
                $poolData = $stmt->fetch();

                if ($poolData) {
                    $results = Voting::getVotingResults($selectedPoolId);
                }
            }
        }

        // 5. Render the unified view
        $this->view('voter/results_list', [
            'title' => 'Election Results',
            'districts' => $districts,
            'selectedDistrict' => $selectedDistrict,
            'pools' => $allPools,
            'selectedPoolId' => $selectedPoolId,
            'pool' => $poolData,
            'results' => $results,
            'isOverall' => $isOverall,
            'hide_navbar' => true
        ]);
    }
}
