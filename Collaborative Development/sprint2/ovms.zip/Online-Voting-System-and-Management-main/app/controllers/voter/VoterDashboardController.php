<?php
class VoterDashboardController extends Controller
{

    private function checkSession(): void
    {
        if (!isset($_SESSION['user'])) {
            $this->redirect(BASE_URL . '/voter/login');
        }
        $timeout = 10 * 60;
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
            unset($_SESSION['user']);
            session_destroy();
            $this->redirect(BASE_URL . '/voter/login?error=timeout');
        }
        $_SESSION['last_activity'] = time();
    }

    public function index(): void
    {
        $this->checkSession();

        $db = Database::getInstance();
        $userId = $_SESSION['user']['id'];
        $constituencyId = $_SESSION['user']['constituency_id'];

        // Get voter info
        $stmt = $db->prepare(
            "SELECT u.id, u.nid, u.voter_id, ci.full_name, ci.photo_url,
                   con.name AS constituency_name,
                   COALESCE(ci.district, con.district) AS district,
                   COALESCE(ci.municipality, '') AS municipality,
                   COALESCE(ci.ward_no, '') AS ward_no,
                   con.province
             FROM users u
             LEFT JOIN citizens ci ON u.nid = ci.nid
             JOIN constituencies con ON u.constituency_id = con.id
             WHERE u.id = ?"
        );
        $stmt->execute([$userId]);
        $voter = $stmt->fetch(PDO::FETCH_ASSOC);

        $pools = Voting::getActivePools($userId, $constituencyId, $voter['province'] ?? '', $voter['district'] ?? '');

        // Force all active pools into a single side-by-side card for the voter
        $groupedElections = [];
        foreach ($pools as $pool) {
            // Use a constant group key to merge everything into one card
            $groupKey = 'current_ballot';
            if (!isset($groupedElections[$groupKey])) {
                $groupedElections[$groupKey] = [
                    'group_key'   => $groupKey,
                    'title'       => 'Active Voting Ballot', // Generic title
                    'voting_end'  => $pool['voting_end'],
                    'fptp_pool'   => null,
                    'pr_pool'     => null,
                    'fptp_candidates' => [],
                    'pr_candidates'   => []
                ];
            }
            
            // Prefer a more descriptive title if available
            if (str_contains(strtolower($pool['title']), 'election')) {
                $groupedElections[$groupKey]['title'] = $pool['title'];
            }

            $poolId = $pool['id'];
            $pool['voted'] = (bool)$pool['has_voted'];

            if ($pool['pool_type'] === 'pr') {
                $groupedElections[$groupKey]['pr_pool'] = $pool;
                $parties = Voting::getPartiesForPool($poolId);
                foreach ($parties as $p) {
                    $groupedElections[$groupKey]['pr_candidates'][] = [
                        'pool_id'        => $poolId,
                        'full_name'      => $p['party_name'],
                        'candidate_type' => 'pr',
                        'party_name'     => $p['abbreviation'],
                        'photo_url'      => $p['symbol_url'],
                        'manifesto_url'  => null,
                        'party_logo'     => $p['symbol_url']
                    ];
                }
            } else {
                $groupedElections[$groupKey]['fptp_pool'] = $pool;
                $candidates = Voting::getCandidatesForPool($poolId);
                foreach ($candidates as $c) {
                    $groupedElections[$groupKey]['fptp_candidates'][] = [
                        'pool_id'        => $poolId,
                        'full_name'      => $c['candidate_name'],
                        'candidate_type' => 'fptp',
                        'party_name'     => $c['party_name'],
                        'photo_url'      => $c['photo_path'],
                        'manifesto_url'  => $c['manifesto'],
                        'party_logo'     => $c['symbol_url']
                    ];
                }
            }
        }

        $this->view('voter/dashboard', [
            'voter' => $voter,
            'groupedElections' => $groupedElections,
            'userId' => $userId
        ]);
    }
}