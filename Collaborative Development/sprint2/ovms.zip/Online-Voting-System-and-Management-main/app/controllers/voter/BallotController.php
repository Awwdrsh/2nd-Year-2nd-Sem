<?php

class BallotController extends Controller {

    private function getVoterInfo(int $userId): array {
        $db = Database::getInstance();
        $stmt = $db->prepare("
            SELECT u.id, u.nid, u.voter_id, ci.full_name, ci.photo_url,
                   con.name AS constituency_name,
                   COALESCE(ci.district, con.district) AS district,
                   COALESCE(ci.municipality, '') AS municipality,
                   COALESCE(ci.ward_no, '') AS ward_no,
                   con.province
            FROM users u
            LEFT JOIN citizens ci ON u.nid = ci.nid
            JOIN constituencies con ON u.constituency_id = con.id
            WHERE u.id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }

    public function index(): void {
        if (!isset($_SESSION['user'])) {
            $this->redirect(BASE_URL . '/voter/login');
        }

        $userId = $_SESSION['user']['id'];
        $constituencyId = $_SESSION['user']['constituency_id'];
        $poolId = (int) ($_GET['pool_id'] ?? 1);

        $voter = $this->getVoterInfo($userId);
        $province = $voter['province'] ?? '';
        $district = $voter['district'] ?? '';

        // Validate pool using unified logic
        $pool = Voting::getPoolById($poolId, $constituencyId, $province, $district);

        if (!$pool) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=pool_not_found');
        }

        // Require secondary verification before showing the ballot
        if (empty($_SESSION['vote_verification'])
            || $_SESSION['vote_verification']['pool_id'] !== $poolId
            || ($_SESSION['vote_verification']['expires'] ?? 0) < time()
        ) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=verify_required');
        }

        // Get candidates or parties based on pool type
        $candidates = [];
        $parties = [];
        if ($pool['pool_type'] === 'pr') {
            $parties = Voting::getPartiesForPool($poolId);
        } else {
            $candidates = Voting::getCandidatesForPool($poolId);
        }

        // Check already voted
        if (Voting::hasUserVotedInPool($userId, $poolId)) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=already_voted_in_pool');
        }

        $this->view('voter/ballot', [
            'voter' => $voter,
            'pool' => $pool,
            'candidates' => $candidates,
            'parties' => array_values($parties),
            'poolId' => $poolId,
            'step' => 'grid'
        ]);
    }

    public function submit(): void {
        if (!isset($_SESSION['user'])) {
            $this->redirect(BASE_URL . '/voter/login');
        }

        $userId = $_SESSION['user']['id'];
        $constituencyId = $_SESSION['user']['constituency_id'];

        $voter = $this->getVoterInfo($userId);
        $province = $voter['province'] ?? '';
        $district = $voter['district'] ?? '';

        $step = $_POST['step'] ?? 'grid';
        $poolId = (int) ($_POST['pool_id'] ?? 0);
        $poolCandidateId = (int) ($_POST['pool_candidate_id'] ?? 0);
        $partyId = (int) ($_POST['party_id'] ?? 0);

        // Validate pool using unified logic
        $pool = Voting::getPoolById($poolId, $constituencyId, $province, $district);

        if (!$pool) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=pool_invalid');
        }

        if (empty($_SESSION['vote_verification'])
            || $_SESSION['vote_verification']['pool_id'] !== $poolId
            || ($_SESSION['vote_verification']['expires'] ?? 0) < time()
        ) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=verify_required');
        }

        // Get candidates or parties
        $candidates = [];
        if ($pool['pool_type'] !== 'pr') {
            $candidates = Voting::getCandidatesForPool($poolId);
        }

        // STEP → SUMMARY
        if ($step === 'summary') {
            $selected = null;
            if ($pool['pool_type'] === 'pr') {
                $db = Database::getInstance();
                $stmt = $db->prepare("SELECT id AS party_id, name AS party_name, abbreviation, symbol_url FROM parties WHERE id = ?");
                $stmt->execute([$partyId]);
                $selected = $stmt->fetch();
            } else {
                foreach ($candidates as $c) {
                    if ($c['pool_candidate_id'] == $poolCandidateId) {
                        $selected = $c;
                        break;
                    }
                }
            }

            $this->view('voter/ballot', [
                'voter' => $voter,
                'pool' => $pool,
                'candidates' => $candidates,
                'poolId' => $poolId,
                'step' => 'summary',
                'selected' => $selected
            ]);
            return;
        }

        // STEP → CONFIRM
        if ($step === 'confirm') {
            if ($pool['pool_type'] === 'pr') {
                $result = Voting::castVote($userId, $poolId, null, $partyId);
            } else {
                $result = Voting::castVote($userId, $poolId, $poolCandidateId);
            }
            unset($_SESSION['vote_verification']);

            $this->view('voter/ballot', [
                'voter' => $voter,
                'pool' => $pool,
                'candidates' => $candidates,
                'poolId' => $poolId,
                'step' => 'confirm',
                'success' => $result['success'],
                'receipt' => $result['receipt'] ?? ''
            ]);
            return;
        }

        $this->redirect(BASE_URL . '/voter/dashboard');
    }
}