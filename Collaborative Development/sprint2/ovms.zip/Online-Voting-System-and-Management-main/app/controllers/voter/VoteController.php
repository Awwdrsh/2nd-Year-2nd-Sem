<?php
class VoteController extends Controller {

    public function cast(): void {
        if (!isset($_SESSION['user'])) {
            $this->redirect(BASE_URL . '/voter/login');
        }

        $timeout = 10 * 60;
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
            unset($_SESSION['user']);
            session_destroy();
            $this->redirect(BASE_URL . '/voter/login?error=timeout');
        }
        $_SESSION['last_activity'] = time();

        $userId         = $_SESSION['user']['id'];
        $constituencyId = $_SESSION['user']['constituency_id'];
        $secret         = VOTE_SECRET;

        $poolId          = (int) ($_POST['pool_id'] ?? 0);
        $poolCandidateId = (int) ($_POST['pool_candidate_id'] ?? 0);

        if (!$poolId || !$poolCandidateId) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=invalid');
        }

        $db = Database::getInstance();

        // Get voter location for validation
        $stmt = $db->prepare("
            SELECT con.province, con.district 
            FROM users u 
            JOIN constituencies con ON u.constituency_id = con.id 
            WHERE u.id = ?
        ");
        $stmt->execute([$userId]);
        $loc = $stmt->fetch();
        $province = $loc['province'] ?? '';
        $district = $loc['district'] ?? '';

        // Validate pool using unified logic
        $pool = Voting::getPoolById($poolId, $constituencyId, $province, $district);
        if (!$pool) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=pool_closed');
        }

        $stmt = $db->prepare("SELECT id FROM pool_candidates WHERE id = ? AND pool_id = ?");
        $stmt->execute([$poolCandidateId, $poolId]);
        if (!$stmt->fetch()) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=invalid');
        }

        $voterHash = hash('sha256', $userId . $poolId . $secret);
        $stmt = $db->prepare("SELECT id FROM votes WHERE pool_id = ? AND voter_hash = ?");
        $stmt->execute([$poolId, $voterHash]);
        if ($stmt->fetch()) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=already_voted');
        }

        $receiptCode = strtoupper(bin2hex(random_bytes(8)));

        $stmt = $db->prepare(
            "INSERT INTO votes (pool_id, pool_candidate_id, voter_hash, receipt_code, ip_address)
             VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->execute([
            $poolId,
            $poolCandidateId,
            $voterHash,
            $receiptCode,
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);

        $this->redirect(BASE_URL . '/voter/dashboard?success=1&receipt=' . urlencode($receiptCode));
    }

    public function verify(): void {
        if (!isset($_SESSION['user'])) {
            $this->redirect(BASE_URL . '/voter/login');
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/voter/dashboard');
        }

        $poolId = (int) ($_POST['pool_id'] ?? 0);
        $verification = trim($_POST['verification_code'] ?? '');
        $user = $_SESSION['user'];

        if (!$poolId || !preg_match('/^\d{4}$/', $verification)) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=invalid_verification');
        }

        $expected = substr($user['nid'] ?? '', -4);
        if ($expected === '' || $verification !== $expected) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=invalid_verification');
        }

        $db = Database::getInstance();
        // Get voter location for validation
        $stmt = $db->prepare("
            SELECT con.province, con.district 
            FROM users u 
            JOIN constituencies con ON u.constituency_id = con.id 
            WHERE u.id = ?
        ");
        $stmt->execute([$user['id']]);
        $loc = $stmt->fetch();
        $province = $loc['province'] ?? '';
        $district = $loc['district'] ?? '';

        // Validate pool using unified logic
        $pool = Voting::getPoolById($poolId, $user['constituency_id'], $province, $district);
        if (!$pool) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=pool_not_found');
        }

        if (Voting::hasUserVotedInPool($user['id'], $poolId)) {
            $this->redirect(BASE_URL . '/voter/dashboard?error=already_voted_in_pool');
        }

        $_SESSION['vote_verification'] = [
            'pool_id' => $poolId,
            'expires' => time() + 600,
        ];

        $this->redirect(BASE_URL . '/voter/ballot?pool_id=' . $poolId);
    }
}
