<?php

class AdminController extends Controller {

    public function dashboard(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();



        $totalVoters    = (int) $db->query("SELECT COUNT(*) AS c FROM users")->fetch()['c'];
        $totalVotesCast = (int) $db->query("SELECT COUNT(*) AS c FROM votes")->fetch()['c'];
        $activeVoters   = (int) $db->query("SELECT COUNT(DISTINCT voter_hash) AS c FROM votes")->fetch()['c'];

        $participationRate = $totalVoters > 0
            ? round(($activeVoters / $totalVoters) * 100, 1)
            : 0;

        $stats = [
            'total_voters'        => $totalVoters,
            'active_voters'       => $activeVoters,
            'total_candidacy'     => (int) $db->query("SELECT COUNT(*) AS c FROM candidates")->fetch()['c'],
            'active_pools'        => (int) $db->query("SELECT COUNT(*) AS c FROM pools WHERE (status = 'active' OR (status = 'upcoming' AND voting_start <= NOW())) AND status != 'closed'")->fetch()['c'],
            'total_votes_cast'    => $totalVotesCast,
            'participation_rate'  => $participationRate,
            'active_elections'    => (int) $db->query("SELECT COUNT(*) AS c FROM elections WHERE status = 'active'")->fetch()['c'],
            'pending_nominations' => (int) $db->query("SELECT COUNT(*) AS c FROM candidates WHERE nomination_status = 'pending'")->fetch()['c'],
            'total_parties'       => (int) $db->query("SELECT COUNT(*) AS c FROM parties")->fetch()['c'],
            'total_officers'      => (int) $db->query("SELECT COUNT(*) AS c FROM admins")->fetch()['c'],
        ];


        $recentElections = $db->query(
            "SELECT e.*, a.full_name AS created_by_name
             FROM   elections e
             LEFT JOIN admins a ON e.created_by = a.id
             ORDER BY e.created_at DESC LIMIT 5"
        )->fetchAll();

        $electionStatusCounts = $db->query(
            "SELECT status, COUNT(*) AS count FROM elections GROUP BY status"
        )->fetchAll();

        $votesByPool = $db->query(
            "SELECT p.title, COUNT(v.id) AS vote_count
             FROM   pools p
             LEFT JOIN votes v ON v.pool_id = p.id
             GROUP BY p.id, p.title
             ORDER BY vote_count DESC LIMIT 6"
        )->fetchAll();

        $recentVotes = $db->query(
            "SELECT v.cast_at, v.receipt_code, p.title AS pool_title
             FROM   votes v
             JOIN   pools p ON v.pool_id = p.id
             ORDER BY v.cast_at DESC LIMIT 5"
        )->fetchAll();

        // Fetch the 10 most recent audit log entries for the System Activity panel
        $recentActivity = $db->query(
            "SELECT l.action, l.module, l.description, l.ip_address, l.created_at,
                    a.full_name AS admin_name
             FROM   admin_activity_log l
             JOIN   admins a ON l.admin_id = a.id
             ORDER BY l.created_at DESC
             LIMIT 10"
        )->fetchAll();

        // Log dashboard visit — after fetching activity so this visit appears next time
        $this->log(ActivityLog::READ, 'Dashboard', 'Admin viewed the system overview dashboard');

        $this->view('admin/dashboard', [
            'title'                => 'Admin Dashboard',
            'stats'                => $stats,
            'recentElections'      => $recentElections,
            'electionStatusCounts' => $electionStatusCounts,
            'votesByPool'          => $votesByPool,
            'recentVotes'          => $recentVotes,
            'recentActivity'       => $recentActivity,
        ]);
    }

    // Lightweight JSON endpoint polled every 30 s — intentionally not logged
    // to avoid flooding the audit log with automated requests.
    public function statsApi(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $totalVoters    = (int) $db->query("SELECT COUNT(*) AS c FROM users")->fetch()['c'];
        $activeVoters   = (int) $db->query("SELECT COUNT(DISTINCT voter_hash) AS c FROM votes")->fetch()['c'];
        $totalVotesCast = (int) $db->query("SELECT COUNT(*) AS c FROM votes")->fetch()['c'];

        header('Content-Type: application/json');
        echo json_encode([
            'total_voters'       => $totalVoters,
            'active_voters'      => $activeVoters,
            'total_votes_cast'   => $totalVotesCast,
            'total_candidacy'    => (int) $db->query("SELECT COUNT(*) AS c FROM candidates")->fetch()['c'],
            'active_pools'       => (int) $db->query("SELECT COUNT(*) AS c FROM pools WHERE (status = 'active' OR (status = 'upcoming' AND voting_start <= NOW())) AND status != 'closed'")->fetch()['c'],
            'active_elections'   => (int) $db->query("SELECT COUNT(*) AS c FROM elections WHERE status = 'active'")->fetch()['c'],
            'participation_rate' => $totalVoters > 0 ? round(($activeVoters / $totalVoters) * 100, 1) : 0,
            'total_officers'     => (int) $db->query("SELECT COUNT(*) AS c FROM admins")->fetch()['c'],
            'total_parties'      => (int) $db->query("SELECT COUNT(*) AS c FROM parties")->fetch()['c'],
        ]);
        exit;
    }
}
