<?php

class VoterAuthController extends Controller {

    public static function requireAuth(): void {
        Auth::requireVoter();
    }

    public function showVoterLogin(): void {
        if (isset($_SESSION['user'])) {
            $this->redirect(BASE_URL . '/voter/dashboard');
        }
        $error = $_GET['error'] ?? '';
        $this->view('auth/voter_login', ['error' => $error]);
    }

    public function voterLogin(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/voter/login');
        }

        $nid      = trim($_POST['nid'] ?? '');
        $voter_id = trim($_POST['voter_id'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($nid) || empty($voter_id) || empty($password) || !preg_match('/^\d{10,13}$/', $nid)) {
            $this->redirect(BASE_URL . '/voter/login?error=invalid_nid');
        }

        $db = Database::getInstance();
        $stmt = $db->prepare(
            "SELECT u.id, u.nid, u.voter_id, u.password, u.constituency_id,
                   u.failed_attempts, u.blocked_until, c.full_name
             FROM users u
             JOIN citizens c ON u.nid = c.nid
             WHERE u.nid = ?"
        );
        $stmt->execute([$nid]);
        $user = $stmt->fetch();

        if ($user && $user['blocked_until'] && new DateTime() < new DateTime($user['blocked_until'])) {
            $this->redirect(BASE_URL . '/voter/login?error=locked');
        }

        if (!$user || $user['voter_id'] !== $voter_id || !password_verify($password, $user['password'])) {
            if ($user) {
                $attempts = $user['failed_attempts'] + 1;
                if ($attempts >= 5) {
                    $db->prepare(
                        "UPDATE users
                         SET failed_attempts = ?, blocked_until = DATE_ADD(NOW(), INTERVAL 15 MINUTE)
                         WHERE nid = ?"
                    )->execute([$attempts, $nid]);
                    $this->redirect(BASE_URL . '/voter/login?error=locked');
                }
                $db->prepare("UPDATE users SET failed_attempts = ? WHERE nid = ?")->execute([$attempts, $nid]);
            }
            $this->redirect(BASE_URL . '/voter/login?error=invalid');
        }

        $db->prepare(
            "UPDATE users SET failed_attempts = 0, blocked_until = NULL, last_login = NOW()
             WHERE id = ?"
        )->execute([$user['id']]);
        
        $_SESSION['user'] = [
            'id'              => $user['id'],
            'name'            => $user['full_name'],
            'nid'             => $user['nid'],
            'voter_id'        => $user['voter_id'],
            'constituency_id' => $user['constituency_id'],
        ];
        $_SESSION['login_time']    = time();
        $_SESSION['last_activity'] = time();

        // Update session_id in database for concurrent session control
        $sessionId = session_id();
        try {
            $db->prepare("UPDATE users SET session_id = ? WHERE id = ?")->execute([$sessionId, $user['id']]);
        } catch (Exception $e) {}

        $this->redirect(BASE_URL . '/voter/dashboard');
    }

    public function voterLogout(): void {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();

        $goto = $_GET['goto'] ?? '/voter/login';
        // Ensure the path starts with /
        if (strpos($goto, '/') !== 0) $goto = '/' . $goto;
        
        $this->redirect(BASE_URL . $goto);
    }
}
