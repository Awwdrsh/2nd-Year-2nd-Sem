<?php

/**
 * AuthController
 * Manages the three-step admin authentication flow:
 *   Step 1 — Credential + CAPTCHA validation (login form)
 *   Step 2 — Email confirmation page; OTP is generated and dispatched here
 *   Step 3 — OTP entry and verification; full session is created on success
 *
 * Also handles CAPTCHA image generation and session logout.
 */
class AuthController extends Controller {

    public const  MAX_ATTEMPTS  = 5;
    private const LOCKOUT_MINS  = 15;
    private const SESSION_TTL   = 1800;

    // Enforces authentication on every protected admin route.
    public static function requireAuth(): void {
        Auth::requireAdmin();
    }

    // ── STEP 1: GET /admin/login ─────────────────────────────────────────
    // Displays the login form with email, password, and CAPTCHA fields.
    public function showLogin(): void {
        if (Auth::isAdmin()) {
            $this->redirect(BASE_URL . '/admin/dashboard');
        }
        $error  = $_GET['error']  ?? '';
        $locked = $_GET['locked'] ?? '';
        $email  = $_GET['email']  ?? '';
        $logout = $_GET['logout'] ?? '';
        require BASE_PATH . '/app/views/auth/login.php';
    }

    // ── STEP 1: POST /admin/login/submit ─────────────────────────────────
    // Validates CAPTCHA (case-sensitive), then checks email/password.
    // On success, stores a pending-admin session key and moves to Step 2.
    public function handleLogin(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/login');
        }

        $email        = trim($_POST['email']    ?? '');
        $password     = trim($_POST['password'] ?? '');
        $captchaInput = trim($_POST['captcha']  ?? '');
        $ip           = $this->clientIp();

        if (!$email || !$password) {
            $this->redirect(BASE_URL . '/admin/login?error=missing_fields&email=' . urlencode($email));
        }

        // CAPTCHA is case-sensitive — the user must type the code exactly as shown.
        if (empty($_SESSION['captcha_code']) || $captchaInput !== $_SESSION['captcha_code']) {
            unset($_SESSION['captcha_code']);
            $this->redirect(BASE_URL . '/admin/login?error=invalid_captcha&email=' . urlencode($email));
        }
        unset($_SESSION['captcha_code']);

        $db    = Database::getInstance();
        $admin = $db->query(
            "SELECT id, full_name, email, password, role, failed_attempts, locked_until FROM admins WHERE email = ?",
            [$email]
        )->fetch();

        if (!$admin) {
            $this->redirect(BASE_URL . '/admin/login?error=invalid&email=' . urlencode($email));
        }

        if ($admin['locked_until'] && strtotime($admin['locked_until']) > time()) {
            $remaining = ceil((strtotime($admin['locked_until']) - time()) / 60);
            $this->redirect(BASE_URL . '/admin/login?error=locked&locked=' . $remaining . '&email=' . urlencode($email));
        }

        if (!password_verify($password, $admin['password'])) {
            $attempts = (int) $admin['failed_attempts'] + 1;
            if ($attempts >= self::MAX_ATTEMPTS) {
                $db->query("UPDATE admins SET failed_attempts = ?, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id = ?",
                    [$attempts, self::LOCKOUT_MINS, $admin['id']]);
                ActivityLog::write((int)$admin['id'], ActivityLog::LOGIN, 'Auth', "Account locked after {$attempts} failed attempts from IP {$ip}");
                $this->redirect(BASE_URL . '/admin/login?error=locked&locked=' . self::LOCKOUT_MINS . '&email=' . urlencode($email));
            }
            $db->query("UPDATE admins SET failed_attempts = ? WHERE id = ?", [$attempts, $admin['id']]);
            $this->redirect(BASE_URL . '/admin/login?error=invalid&email=' . urlencode($email));
        }

        // Credentials accepted — Reset failure counters
        try {
            $db->query("UPDATE admins SET failed_attempts = 0, locked_until = NULL WHERE id = ?", [$admin['id']]);
        } catch (Exception $e) {}

        // credentials accepted — start multi-step authentication
        $_SESSION['otp_pending_admin'] = [
            'id'    => (int) $admin['id'],
            'name'  => $admin['full_name'],
            'email' => $admin['email'],
            'role'  => $admin['role'],
            'ip'    => $ip
        ];

        ActivityLog::write((int)$admin['id'], ActivityLog::LOGIN, 'Auth', "Admin credential verification successful; moving to Step 2 (OTP) from IP {$ip}");
        $this->redirect(BASE_URL . '/admin/otp/request');
    }

    // ── STEP 2: GET /admin/otp/request ───────────────────────────────────
    // Shows the email entry form where the admin types their registered email.
    // Entering the correct email triggers OTP dispatch.
    public function showOtpRequest(): void {
        if (empty($_SESSION['otp_pending_admin'])) {
            $this->redirect(BASE_URL . '/admin/login');
        }
        if (Auth::isAdmin()) {
            $this->redirect(BASE_URL . '/admin/dashboard');
        }
        $error = $_GET['error'] ?? '';
        require BASE_PATH . '/app/views/auth/otp_request.php';
    }

    // ── STEP 2: POST /admin/otp/request/submit ───────────────────────────
    // Validates that the submitted email matches the pending admin's registered
    // address, then generates the OTP and dispatches it via Brevo SMTP.
    public function sendOtpToEmail(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/otp/request');
        }
        if (empty($_SESSION['otp_pending_admin'])) {
            $this->redirect(BASE_URL . '/admin/login');
        }

        $submitted  = strtolower(trim($_POST['email'] ?? ''));
        $registered = strtolower($_SESSION['otp_pending_admin']['email']);

        // The submitted email must match the account's registered email exactly.
        if ($submitted !== $registered) {
            $this->redirect(BASE_URL . '/admin/otp/request?error=email_mismatch');
        }

        $admin = $_SESSION['otp_pending_admin'];
        $otp   = otp_generate();
        otp_store($otp);

        $sent = otp_send($admin['name'], $admin['email'], $otp, 'admin');

        if ($sent) {
            $this->redirect(BASE_URL . '/admin/otp');
        } else {
            otp_clear();
            $this->redirect(BASE_URL . '/admin/otp/request?error=send_failed');
        }
    }

    // ── STEP 3: GET /admin/otp ────────────────────────────────────────────
    // Renders the 6-digit OTP entry page.
    public function showOtp(): void {
        if (empty($_SESSION['otp_pending_admin'])) {
            $this->redirect(BASE_URL . '/admin/login');
        }
        if (Auth::isAdmin()) {
            $this->redirect(BASE_URL . '/admin/dashboard');
        }

        $email         = $_SESSION['otp_pending_admin']['email'] ?? '';
        $masked_email  = otp_mask_email($email);
        $otp_remaining = max(0, (int)($_SESSION['otp_expires'] ?? time()) - time());
        $error         = $_GET['error']   ?? '';
        $success       = $_GET['success'] ?? '';

        require BASE_PATH . '/app/views/auth/otp.php';
    }

    // ── STEP 3: POST /admin/otp/verify ───────────────────────────────────
    // Verifies the submitted OTP against the hashed session value.
    // On success, tears down the pending session and creates the full admin session.
    public function verifyOtp(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/otp');
        }
        if (empty($_SESSION['otp_pending_admin'])) {
            $this->redirect(BASE_URL . '/admin/login?error=session_expired');
        }

        $submitted = trim($_POST['otp'] ?? '');

        if (!$submitted || strlen($submitted) < 6) {
            $this->redirect(BASE_URL . '/admin/otp?error=empty_otp');
        }

        if (!otp_verify($submitted)) {
            // If otp_code is gone, otp_verify() cleared it — code expired or locked
            if (empty($_SESSION['otp_code'])) {
                unset($_SESSION['otp_pending_admin']);
                $this->redirect(BASE_URL . '/admin/otp?error=locked');
            }
            $this->redirect(BASE_URL . '/admin/otp?error=invalid_otp');
        }

        // OTP accepted — promote the pending record into a full authenticated session.
        $admin = $_SESSION['otp_pending_admin'];
        otp_clear();
        unset($_SESSION['otp_pending_admin'], $_SESSION['otp_resent_at']);

        session_regenerate_id(true);
        $sessionId = session_id();

        $_SESSION['admin_id']      = $admin['id'];
        $_SESSION['admin_name']    = $admin['name'];
        $_SESSION['admin_email']   = $admin['email'];
        $_SESSION['admin_role']    = $admin['role'];
        $_SESSION['login_ip']      = $admin['ip'];
        $_SESSION['login_at']      = time();
        $_SESSION['last_activity'] = time();

        // Update session_id and last_login in database
        try {
            $db = Database::getInstance();
            $db->query("UPDATE admins SET session_id = ?, last_login = NOW() WHERE id = ?", [$sessionId, $admin['id']]);
        } catch (Exception $e) {}

        ActivityLog::write($admin['id'], ActivityLog::LOGIN, 'Auth', "Admin logged in with OTP from IP {$admin['ip']}");
        $this->redirect(BASE_URL . '/admin/dashboard');
    }

    // ── RESEND: GET /admin/otp/resend ────────────────────────────────────
    // Generates a fresh OTP and resends it. Rate-limited to once per 60 seconds.
    public function resendOtp(): void {
        if (empty($_SESSION['otp_pending_admin'])) {
            $this->redirect(BASE_URL . '/admin/login');
        }
        $lastResent = (int)($_SESSION['otp_resent_at'] ?? 0);
        if ($lastResent && (time() - $lastResent) < 60) {
            $this->redirect(BASE_URL . '/admin/otp?error=resend_wait');
        }

        $admin = $_SESSION['otp_pending_admin'];
        $otp   = otp_generate();
        otp_store($otp);
        $_SESSION['otp_resent_at'] = time();

        $sent = otp_send($admin['name'], $admin['email'], $otp, 'admin');
        $this->redirect($sent
            ? BASE_URL . '/admin/otp?success=resent'
            : BASE_URL . '/admin/otp?error=resend_failed'
        );
    }

    // ── GET /admin/captcha ────────────────────────────────────────────────
    // Generates a 5-character uppercase CAPTCHA image.
    // The login form comparison is case-SENSITIVE — user must match exactly.
    public function captcha(): void {
        if (ob_get_level()) ob_clean();
        header('Content-Type: image/png');
        header('Cache-Control: no-cache, must-revalidate');

        $code = substr(str_shuffle("ABCDEFGHJKLMNPQRSTUVWXYZ23456789"), 0, 5);
        $_SESSION['captcha_code'] = $code;

        $width = 120; $height = 45;
        $image = imagecreatetruecolor($width, $height);
        $white = imagecolorallocate($image, 255, 255, 255);
        $dark  = imagecolorallocate($image, 15, 23, 42);
        $teal  = imagecolorallocate($image, 58, 143, 163);

        imagefilledrectangle($image, 0, 0, $width, $height, $dark);
        for ($i = 0; $i < 4; $i++) {
            imageline($image, rand(0,$width), rand(0,$height), rand(0,$width), rand(0,$height), $teal);
        }
        imagestring($image, 5, 25, 15, $code, $white);
        imagepng($image);
        imagedestroy($image);
        exit;
    }

    // ── GET /admin/logout ─────────────────────────────────────────────────
    public function logout(): void {
        $adminId   = (int)($_SESSION['admin_id']   ?? 0);
        $adminName = $_SESSION['admin_name'] ?? 'Unknown';
        $ip        = $this->clientIp();

        if ($adminId) {
            ActivityLog::write($adminId, ActivityLog::LOGOUT, 'Auth', "Admin \"{$adminName}\" logged out from IP {$ip}");
        }

        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        $this->redirect(BASE_URL . '/admin/login?logout=1');
    }

    // Resolves the real client IP from common proxy headers.
    private function clientIp(): string {
        foreach (['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
            if (!empty($_SERVER[$k])) {
                $ip = trim(explode(',', $_SERVER[$k])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return '0.0.0.0';
    }
}
