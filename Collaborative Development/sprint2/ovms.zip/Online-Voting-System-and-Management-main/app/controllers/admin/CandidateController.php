<?php

class CandidateController extends Controller {

    // ── List all candidates ───────────────────────────────────────────
    public function index(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? '');
        $sort   = trim($_GET['sort'] ?? 'newest');
        $page   = (int) ($_GET['page'] ?? 1);
        $limit  = 10;
        $offset = ($page - 1) * $limit;

        $where  = "WHERE 1=1";
        $params = [];

        if ($search) {
            $where .= " AND (ci.full_name LIKE ? OR p.name LIKE ? OR u.voter_id LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        if ($status === 'pending') {
            $where .= " AND c.nomination_status = 'pending'";
        } elseif ($status === 'approved') {
            $where .= " AND c.nomination_status = 'approved'";
        } elseif ($status === 'rejected') {
            $where .= " AND c.nomination_status = 'rejected'";
        }

        $orderBy = "c.created_at DESC";
        if ($sort === 'oldest') $orderBy = "c.created_at ASC";
        elseif ($sort === 'name_asc') $orderBy = "ci.full_name ASC";
        elseif ($sort === 'name_desc') $orderBy = "ci.full_name DESC";

        // 1. Get total rows for pagination
        $countQuery = "SELECT COUNT(*) FROM candidates c 
                       JOIN users u ON c.user_id = u.id 
                       JOIN citizens ci ON u.nid = ci.nid 
                       LEFT JOIN parties p ON c.party_id = p.id $where";
        $totalRows = $db->query($countQuery, $params)->fetchColumn();
        $totalPages = ceil($totalRows / $limit);
        if ($page > $totalPages && $totalPages > 0) $page = $totalPages;

        // 2. Fetch paginated results
        $candidates = $db->query(
            "SELECT c.*, ci.full_name AS citizen_name, p.name AS party_name,
                    p.symbol_url AS party_symbol, co.name AS constituency_name
             FROM   candidates c
             JOIN   users u  ON c.user_id = u.id
             JOIN   citizens ci ON u.nid   = ci.nid
             LEFT JOIN parties p ON c.party_id = p.id
             LEFT JOIN constituencies co ON c.constituency_id = co.id
             $where
             ORDER BY $orderBy
             LIMIT $limit OFFSET $offset",
            $params
        )->fetchAll();

        $this->log(ActivityLog::READ, 'Candidate', "Viewed candidates list (Search: \"$search\", Page: $page)");

        $this->view('admin/candidates/index', [
            'title'      => 'Candidates',
            'candidates' => $candidates,
            'search'     => $search,
            'status'     => $status,
            'sort'       => $sort,
            'page'       => $page,
            'totalPages' => $totalPages,
            'totalRows'  => $totalRows
        ]);
    }

    // ── Show create form ──────────────────────────────────────────────
    public function create(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $parties = $db->query("SELECT id, name, symbol_url FROM parties WHERE is_active = 1 ORDER BY name ASC")->fetchAll();
        $constituencies = $db->query("SELECT id, name FROM constituencies ORDER BY name ASC")->fetchAll();

        $this->view('admin/candidates/create', [
            'title'          => 'Add Candidate',
            'parties'        => $parties,
            'constituencies' => $constituencies,
        ]);
    }

    // ── Handle create submission ──────────────────────────────────────
    public function store(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/candidates/create');
        }

        $voterId       = trim($_POST['voter_id'] ?? '');
        $partyId       = (int) ($_POST['party_id'] ?? 0);
        $constituencyId = (int) ($_POST['constituency_id'] ?? 0);
        $manifesto     = trim($_POST['manifesto'] ?? '');
        $electionType  = $_POST['election_type'] ?? 'fptp';

        if (!$voterId || !$constituencyId) {
            $this->redirect(BASE_URL . '/admin/candidates/create?error=missing_fields');
        }

        $db = Database::getInstance();

        // Find user by Voter ID
        $user = $db->query("SELECT id, nid FROM users WHERE voter_id = ?", [$voterId])->fetch();
        if (!$user) {
            $this->redirect(BASE_URL . '/admin/candidates/create?error=voter_not_found');
        }

        // Check if already a candidate
        $exists = $db->query("SELECT id FROM candidates WHERE user_id = ?", [$user['id']])->fetch();
        if ($exists) {
            $this->redirect(BASE_URL . '/admin/candidates/create?error=already_candidate');
        }

        $db->query(
            "INSERT INTO candidates (user_id, party_id, constituency_id, election_type, manifesto, nomination_status, is_active) 
             VALUES (?, ?, ?, ?, ?, 'approved', 1)",
            [$user['id'], $partyId ?: null, $constituencyId, $electionType, $manifesto]
        );
        $candidateId = $db->query("SELECT LAST_INSERT_ID() as id")->fetch()['id'];

        $this->log(ActivityLog::CREATE, 'Candidate', "Added new candidate for Voter ID: {$voterId}", $candidateId);
        $this->redirect(BASE_URL . '/admin/candidates?success=added');
    }

    // ── Show edit form ────────────────────────────────────────────────
    public function edit(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? 0);
        $db = Database::getInstance();

        $candidate = $db->query(
            "SELECT c.*, u.voter_id, ci.full_name AS citizen_name, ci.photo_url
             FROM   candidates c
             JOIN   users u  ON c.user_id = u.id
             JOIN   citizens ci ON u.nid = ci.nid
             WHERE  c.id = ?",
            [$id]
        )->fetch();

        if (!$candidate) {
            $this->redirect(BASE_URL . '/admin/candidates?error=not_found');
        }

        $parties = $db->query("SELECT id, name, symbol_url FROM parties WHERE is_active = 1 ORDER BY name ASC")->fetchAll();
        $constituencies = $db->query("SELECT id, name FROM constituencies ORDER BY name ASC")->fetchAll();

        $this->view('admin/candidates/edit', [
            'title'          => 'Edit Candidate',
            'candidate'      => $candidate,
            'parties'        => $parties,
            'constituencies' => $constituencies,
        ]);
    }

    // ── Handle update submission ──────────────────────────────────────
    public function update(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/candidates');
        }

        $id             = (int) ($_POST['id'] ?? 0);
        $partyId        = (int) ($_POST['party_id'] ?? 0);
        $constituencyId = (int) ($_POST['constituency_id'] ?? 0);
        $manifesto      = trim($_POST['manifesto'] ?? '');
        $electionType   = $_POST['election_type'] ?? 'fptp';
        $isActive       = isset($_POST['is_active']) ? 1 : 0;

        $db = Database::getInstance();
        $db->query(
            "UPDATE candidates SET party_id = ?, constituency_id = ?, election_type = ?, 
                    manifesto = ?, is_active = ?, updated_at = NOW() 
             WHERE id = ?",
            [$partyId ?: null, $constituencyId, $electionType, $manifesto, $isActive, $id]
        );

        $this->log(ActivityLog::UPDATE, 'Candidate', "Updated candidate #{$id}", $id);
        $this->redirect(BASE_URL . '/admin/candidates?success=updated');
    }

    // ── Approve a nomination ──────────────────────────────────────────
    public function approve(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $candidate = $db->query(
            "SELECT c.id, ci.full_name
             FROM   candidates c
             JOIN   users u  ON c.user_id = u.id
             JOIN   citizens ci ON u.nid = ci.nid
             WHERE  c.id = ?",
            [$id]
        )->fetch();

        if (!$candidate) {
            $this->redirect(BASE_URL . '/admin/candidates');
        }

        $db->query(
            "UPDATE candidates SET nomination_status = 'approved', updated_at = NOW() WHERE id = ?",
            [$id]
        );

        $this->log(
            ActivityLog::UPDATE,
            'Candidate',
            "Approved nomination for candidate #{$id}: \"{$candidate['full_name']}\"",
            $id
        );

        $this->redirect(BASE_URL . '/admin/candidates');
    }

    // ── Reject a nomination ───────────────────────────────────────────
    public function reject(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $candidate = $db->query(
            "SELECT c.id, ci.full_name
             FROM   candidates c
             JOIN   users u  ON c.user_id = u.id
             JOIN   citizens ci ON u.nid = ci.nid
             WHERE  c.id = ?",
            [$id]
        )->fetch();

        if (!$candidate) {
            $this->redirect(BASE_URL . '/admin/candidates');
        }

        $db->query(
            "UPDATE candidates SET nomination_status = 'rejected', updated_at = NOW() WHERE id = ?",
            [$id]
        );

        $this->log(
            ActivityLog::UPDATE,
            'Candidate',
            "Rejected nomination for candidate #{$id}: \"{$candidate['full_name']}\"",
            $id
        );

        $this->redirect(BASE_URL . '/admin/candidates');
    }

    // ── Delete a candidate record ─────────────────────────────────────
    public function delete(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $candidate = $db->query(
            "SELECT c.id, ci.full_name
             FROM   candidates c
             JOIN   users u  ON c.user_id = u.id
             JOIN   citizens ci ON u.nid = ci.nid
             WHERE  c.id = ?",
            [$id]
        )->fetch();

        if (!$candidate) {
            $this->redirect(BASE_URL . '/admin/candidates');
        }

        // Check for ANY pool association (to prevent FK constraint violation)
        $poolAssociation = $db->query(
            "SELECT p.title, p.status 
             FROM pool_candidates pc 
             JOIN pools p ON pc.pool_id = p.id 
             WHERE pc.candidate_id = ?",
            [$id]
        )->fetch();
 
        if ($poolAssociation) {
            $errCode = ($poolAssociation['status'] === 'active') ? 'tied_to_active_pool' : 'tied_to_pool';
            $this->redirect(BASE_URL . "/admin/candidates?error={$errCode}&pool=" . urlencode($poolAssociation['title']));
            return;
        }

        try {
            $db->query("DELETE FROM candidates WHERE id = ?", [$id]);
        } catch (PDOException $e) {
            // Log the error and redirect with a generic DB error message
            error_log("Candidate Deletion Failed (#{$id}): " . $e->getMessage());
            $this->redirect(BASE_URL . '/admin/candidates?error=db_error');
            return;
        }

        $this->log(
            ActivityLog::DELETE,
            'Candidate',
            "Deleted candidate record #{$id}: \"{$candidate['full_name']}\"",
            $id
        );

        $this->redirect(BASE_URL . '/admin/candidates');
    }

    // ── AJAX: Search voter by ID ──────────────────────────────────────
    public function searchVoter(): void {
        Auth::requireAdmin();
        $voterId = trim($_GET['voter_id'] ?? '');
        $db = Database::getInstance();

        $voter = $db->query(
            "SELECT u.voter_id, ci.full_name, ci.photo_url, co.name AS constituency_name, co.id AS constituency_id
             FROM   users u
             JOIN   citizens ci ON u.nid = ci.nid
             JOIN   constituencies co ON u.constituency_id = co.id
             WHERE  u.voter_id = ?",
            [$voterId]
        )->fetch();

        header('Content-Type: application/json');
        if ($voter) {
            echo json_encode(['success' => true, 'data' => $voter]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Voter not found']);
        }
        exit;
    }
}
