<?php

class ProfileController extends Controller {

    /**
     * Show the profile management page
     */
    public function index(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();
        
        $adminId = $_SESSION['admin_id'];
        $admin = $db->query("SELECT * FROM admins WHERE id = ?", [$adminId])->fetch();

        if (!$admin) {
            $this->redirect(BASE_URL . '/admin/login?error=timeout');
        }

        $this->view('admin/profile', [
            'title'   => 'My Profile',
            'admin'   => $admin,
            'success' => $_GET['success'] ?? '',
            'error'   => $_GET['error']   ?? ''
        ]);
    }

    /**
     * Update admin name and email
     */
    public function update(): void {
        Auth::requireAdmin();
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/profile');
        }

        $db       = Database::getInstance();
        $adminId  = $_SESSION['admin_id'];
        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email']     ?? '');

        if (!$fullName || !$email) {
            $this->redirect(BASE_URL . '/admin/profile?error=missing_fields');
        }

        // Check email uniqueness (excluding current admin)
        $existing = $db->query(
            "SELECT id FROM admins WHERE email = ? AND id != ?",
            [$email, $adminId]
        )->fetch();

        if ($existing) {
            $this->redirect(BASE_URL . '/admin/profile?error=email_exists');
        }

        // Perform update
        $db->query(
            "UPDATE admins SET full_name = ?, email = ?, updated_at = NOW() WHERE id = ?",
            [$fullName, $email, $adminId]
        );

        // Update session data
        $_SESSION['admin_name']  = $fullName;
        $_SESSION['admin_email'] = $email;

        // Log activity
        $this->log(ActivityLog::UPDATE, 'Profile', "Admin updated their profile details (Name: {$fullName}, Email: {$email})");

        $this->redirect(BASE_URL . '/admin/profile?success=profile_updated');
    }

    /**
     * Securely change admin password
     */
    public function changePassword(): void {
        Auth::requireAdmin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/profile');
        }

        $db              = Database::getInstance();
        $adminId         = $_SESSION['admin_id'];
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword     = $_POST['new_password']     ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!$currentPassword || !$newPassword || !$confirmPassword) {
            $this->redirect(BASE_URL . '/admin/profile?error=password_missing');
        }

        if ($newPassword !== $confirmPassword) {
            $this->redirect(BASE_URL . '/admin/profile?error=password_mismatch');
        }

        // Verify current password
        $admin = $db->query("SELECT password FROM admins WHERE id = ?", [$adminId])->fetch();
        if (!password_verify($currentPassword, $admin['password'])) {
            $this->redirect(BASE_URL . '/admin/profile?error=current_password_invalid');
        }

        // Additional security check: new password shouldn't be the same as the old one
        if (password_verify($newPassword, $admin['password'])) {
            $this->redirect(BASE_URL . '/admin/profile?error=password_same_as_old');
        }

        // Hash and update
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $db->query(
            "UPDATE admins SET password = ?, updated_at = NOW() WHERE id = ?",
            [$hashed, $adminId]
        );

        // Log activity
        $this->log(ActivityLog::UPDATE, 'Profile', "Admin changed their account password");

        $this->redirect(BASE_URL . '/admin/profile?success=password_changed');
    }
}
