<?php

class ReportController extends Controller {

    /**
     * Show reports dashboard
     */
    public function index(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        // 1. Registered Voters by District
        $districtTurnout = $db->query(
            "SELECT ci.district, 
                    COUNT(DISTINCT u.id) AS total_voters
             FROM   users u
             JOIN   citizens ci ON u.nid = ci.nid
             GROUP BY ci.district
             ORDER BY total_voters DESC"
        )->fetchAll();

        // 2. Candidate Performance (FPTP Top 10)
        $candidateVotes = $db->query(
            "SELECT c.id, cit.full_name, p.name AS party_name, e.title AS election_title,
                    COUNT(v.id) AS vote_count
             FROM candidates c
             JOIN users u ON c.user_id = u.id
             JOIN citizens cit ON u.nid = cit.nid
             LEFT JOIN parties p ON c.party_id = p.id
             LEFT JOIN pool_candidates pc ON c.id = pc.candidate_id
             LEFT JOIN pools po ON pc.pool_id = po.id
             LEFT JOIN elections e ON po.election_id = e.id
             LEFT JOIN votes v ON pc.id = v.pool_candidate_id
             WHERE c.nomination_status = 'approved'
             GROUP BY c.id, cit.full_name, p.name, e.title
             ORDER BY vote_count DESC
             LIMIT 10"
        )->fetchAll();


        // 2.1 Party Performance (Overall)
        $partyPerformance = Voting::getOverallPartyResults();

        // 3. Overall Stats
        $totalVoters    = (int) $db->query("SELECT COUNT(*) AS c FROM users")->fetch()['c'];
        $totalVotes     = (int) $db->query("SELECT COUNT(*) AS c FROM votes")->fetch()['c'];
        $totalElections = (int) $db->query("SELECT COUNT(*) AS c FROM elections")->fetch()['c'];

        // 4. Demographic: Votes Cast by District
        $votesByRegion = $db->query(
            "SELECT co.district as region, COUNT(v.id) as vote_count
             FROM   votes v
             JOIN   pools p ON v.pool_id = p.id
             JOIN   constituencies co ON p.constituency_id = co.id
             GROUP BY co.district
             ORDER BY vote_count DESC"
        )->fetchAll();

        $this->log(ActivityLog::READ, 'Reports', 'Viewed system reports and analytics');

        $this->view('admin/reports/index', [
            'title'            => 'System Reports',
            'districtTurnout'  => $districtTurnout,
            'candidateVotes'   => $candidateVotes,
            'partyPerformance' => $partyPerformance,
            'votesByRegion'    => $votesByRegion,
            'stats'           => [
                'total_voters'    => $totalVoters,
                'total_votes'     => $totalVotes,
                'total_elections' => $totalElections,
                'turnout_rate'    => $totalVoters > 0 ? round(($totalVotes / $totalVoters) * 100, 1) : 0
            ]
        ]);
    }

    /**
     * Simple CSV export
     */
    public function export(): void {
        Auth::requireAdmin();
        $type = $_GET['type'] ?? 'turnout';
        $db   = Database::getInstance();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="report_' . $type . '_' . date('Ymd') . '.csv"');

        $output = fopen('php://output', 'w');

        if ($type === 'turnout') {
            fputcsv($output, ['District', 'Total Registered']);
            $data = $db->query("SELECT ci.district, COUNT(u.id) as tot 
                                FROM users u 
                                JOIN citizens ci ON u.nid = ci.nid
                                GROUP BY ci.district")->fetchAll();
            foreach ($data as $r) {
                fputcsv($output, [$r['district'], $r['tot']]);
            }
        } elseif ($type === 'candidates') {
            fputcsv($output, ['Candidate Name', 'Party', 'Election', 'Votes']);
            $data = $db->query("SELECT cit.full_name, p.name as party, e.title as election, COUNT(v.id) as votes 
                                FROM candidates c
                                JOIN users u ON c.user_id = u.id
                                JOIN citizens cit ON u.nid = cit.nid
                                LEFT JOIN parties p ON c.party_id = p.id 
                                LEFT JOIN pool_candidates pc ON c.id = pc.candidate_id
                                LEFT JOIN pools po ON pc.pool_id = po.id
                                LEFT JOIN elections e ON po.election_id = e.id
                                LEFT JOIN votes v ON pc.id = v.pool_candidate_id
                                GROUP BY c.id")->fetchAll();
            foreach ($data as $r) {
                fputcsv($output, [$r['full_name'], $r['party'], $r['election'], $r['votes']]);
            }
        }

        fclose($output);
        $this->log(ActivityLog::READ, 'Reports', "Exported report: {$type}");
        exit;
    }
}
