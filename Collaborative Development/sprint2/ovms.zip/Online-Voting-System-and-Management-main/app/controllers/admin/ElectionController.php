<?php

class ElectionController extends Controller {

    // ── List all elections ────────────────────────────────────────────
    public function index(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? '');
        $page   = (int) ($_GET['page'] ?? 1);
        $limit  = 10;
        $offset = ($page - 1) * $limit;

        $where  = "WHERE 1=1";
        $params = [];

        if ($search) {
            $where .= " AND e.title LIKE ?";
            $params[] = "%$search%";
        }

        if ($status) {
            $where .= " AND e.status = ?";
            $params[] = $status;
        }

        // 1. Get total rows
        $countQuery = "SELECT COUNT(*) FROM elections e $where";
        $totalRows = $db->query($countQuery, $params)->fetchColumn();
        $totalPages = ceil($totalRows / $limit);
        if ($page > $totalPages && $totalPages > 0) $page = $totalPages;

        // 2. Fetch paginated data
        $elections = $db->query(
            "SELECT e.*, a.full_name AS created_by_name
             FROM   elections e
             LEFT JOIN admins a ON e.created_by = a.id
             $where
             ORDER BY e.created_at DESC
             LIMIT $limit OFFSET $offset",
            $params
        )->fetchAll();

        $this->log(ActivityLog::READ, 'Election', "Viewed elections list (Search: \"$search\", Page: $page)");

        $this->view('admin/elections/index', [
            'title'      => 'Elections',
            'elections'  => $elections,
            'search'     => $search,
            'status'     => $status,
            'page'       => $page,
            'totalPages' => $totalPages,
            'totalRows'  => $totalRows
        ]);
    }

    // ── Show create form ──────────────────────────────────────────────
    public function create(): void {
        Auth::requireAdmin();
        $this->log(ActivityLog::READ, 'Election', 'Opened create election form');

        $this->view('admin/elections/create', [
            'title' => 'Create Election',
        ]);
    }

    // ── Handle create form submission ─────────────────────────────────
    public function store(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/elections/create');
        }

        $title  = trim($_POST['title'] ?? '');
        $start  = trim($_POST['voting_start'] ?? '');
        $end    = trim($_POST['voting_end']   ?? '');
        $preset = trim($_POST['setup_preset'] ?? 'custom');

        if (!$title || !$start || !$end) {
            $this->redirect(BASE_URL . '/admin/elections/create?error=missing_fields');
        }

        $db      = Database::getInstance();
        $adminId = (int) ($_SESSION['admin_id'] ?? 0);

        $db->query(
            "INSERT INTO elections (title, status, voting_start, voting_end, created_by)
             VALUES (?, 'draft', ?, ?, ?)",
            [$title, $start, $end, $adminId]
        );

        $newId = (int) $db->query("SELECT LAST_INSERT_ID() AS id")->fetch()['id'];

        if ($preset !== 'custom') {
            $query = "SELECT id, name, type, district FROM constituencies";
            if ($preset === 'national_fptp') {
                $query .= " WHERE type = 'fptp'";
            } else if ($preset === 'national_pr') {
                $query .= " WHERE type = 'pr'";
            }
            
            $constituencies = $db->query($query)->fetchAll();
            $poolsCreated = 0;
            
            foreach ($constituencies as $const) {
                // Determine pool title based on type for better clarity
                if ($const['type'] === 'pr') {
                    $poolTitle = $title . ' - ' . $const['name'] . ' (PR)';
                } else {
                    $poolTitle = $title . ' - ' . $const['name'] . ' (FPTP)';
                }
                
                $poolType = $const['type'];
                
                $db->query(
                    "INSERT INTO pools (election_id, constituency_id, title, pool_type, election_type, status, voting_start, voting_end, created_by)
                     VALUES (?, ?, ?, ?, 'national', 'upcoming', ?, ?, ?)",
                    [$newId, $const['id'], $poolTitle, $poolType, $start, $end, $adminId]
                );
                $poolsCreated++;
            }
            
            $this->log(
                ActivityLog::CREATE,
                'Election',
                "Created election: \"{$title}\" with {$poolsCreated} auto-generated pools (Preset: {$preset})",
                $newId
            );
        } else {
            $this->log(
                ActivityLog::CREATE,
                'Election',
                "Created election: \"{$title}\" (status: draft)",
                $newId
            );
        }

        $this->redirect(BASE_URL . '/admin/elections');
    }


    // ── Show edit form ────────────────────────────────────────────────
    public function edit(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? 0);
        $db = Database::getInstance();

        $election = $db->query(
            "SELECT * FROM elections WHERE id = ?", [$id]
        )->fetch();

        if (!$election) {
            http_response_code(404);
            die('Election not found.');
        }

        $this->log(
            ActivityLog::READ,
            'Election',
            "Viewed edit form for election #{$id}: \"{$election['title']}\"",
            $id
        );

        $this->view('admin/elections/edit', [
            'title'    => 'Edit Election',
            'election' => $election,
        ]);
    }

    // ── Handle update form submission ─────────────────────────────────
    public function update(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/elections');
        }

        $id     = (int)   ($_POST['id']           ?? 0);
        $title  = trim(   $_POST['title']          ?? '');
        $status = trim(   $_POST['status']         ?? 'draft');
        $start  = trim(   $_POST['voting_start']   ?? '');
        $end    = trim(   $_POST['voting_end']      ?? '');

        $db = Database::getInstance();

        $before = $db->query("SELECT title, status FROM elections WHERE id = ?", [$id])->fetch();

        $db->query(
            "UPDATE elections
             SET title = ?, status = ?, voting_start = ?, voting_end = ?, updated_at = NOW()
             WHERE id = ?",
            [$title, $status, $start, $end, $id]
        );

        $changes = [];
        if ($before && $before['title']  !== $title)  $changes[] = "title → \"{$title}\"";

        if ($before && $before['status'] !== $status) {
            $changes[] = "status → {$status}";
            // Sync status to associated pools
            $poolStatus = 'upcoming';
            if ($status === 'active') {
                $poolStatus = 'active';
            } elseif (in_array($status, ['completed', 'cancelled'])) {
                $poolStatus = 'closed';
            }
            $db->query("UPDATE pools SET status = ? WHERE election_id = ?", [$poolStatus, $id]);
        }

        $desc = $changes
            ? "Updated election #{$id}: " . implode(', ', $changes)
            : "Updated election #{$id} (no field changes detected)";

        $this->log(ActivityLog::UPDATE, 'Election', $desc, $id);

        $this->redirect(BASE_URL . '/admin/elections');
    }

    // ── Delete an election ────────────────────────────────────────────
    public function delete(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $election = $db->query("SELECT title FROM elections WHERE id = ?", [$id])->fetch();
        if (!$election) {
            $this->redirect(BASE_URL . '/admin/elections?error=not_found');
        }

        try {
            $db->query("DELETE FROM pools WHERE election_id = ?", [$id]);
            $db->query("DELETE FROM elections WHERE id = ?", [$id]);

            $this->log(
                ActivityLog::DELETE,
                'Election',
                "Deleted election #{$id}: \"{$election['title']}\"",
                $id
            );
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $this->redirect(BASE_URL . '/admin/elections?error=in_use');
            }
            throw $e;
        }

        $this->redirect(BASE_URL . '/admin/elections');
    }
}
