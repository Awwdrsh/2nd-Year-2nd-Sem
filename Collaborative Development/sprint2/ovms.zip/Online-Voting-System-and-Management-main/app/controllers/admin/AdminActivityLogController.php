<?php

class AdminActivityLogController extends Controller {

    private const PER_PAGE = 50;

    public function index(): void {
        Auth::requireAdmin();

        $page   = max(1, (int) ($_GET['page']   ?? 1));
        $offset = ($page - 1) * self::PER_PAGE;

        // Optional filters from the query string
        $filterAction = trim($_GET['action'] ?? '');
        $filterModule = trim($_GET['module'] ?? '');
        $search       = trim($_GET['q']      ?? '');

        $logs       = ActivityLog::fetch(self::PER_PAGE, $offset, $filterAction, $filterModule, $search);
        $totalRows  = ActivityLog::count($filterAction, $filterModule, $search);
        $totalPages = (int) ceil($totalRows / self::PER_PAGE);
        $modules    = ActivityLog::modules();   // for the module dropdown

        // Log the audit-log access itself
        $this->log(
            ActivityLog::READ,
            'AuditLog',
            'Admin viewed the activity / audit log'
        );

        $this->view('admin/activity-log/index', [
            'title'        => 'Audit Log',
            'logs'         => $logs,
            'page'         => $page,
            'totalPages'   => $totalPages,
            'totalRows'    => $totalRows,
            'modules'      => $modules,
            'filterAction' => $filterAction,
            'filterModule' => $filterModule,
            'search'       => $search,
        ]);
    }
}
