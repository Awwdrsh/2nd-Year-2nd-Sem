<?php

class PartyController extends Controller {

    // ── List all parties ──────────────────────────────────────────────
    public function index(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? '');
        $sort   = trim($_GET['sort'] ?? 'name_asc');
        $page   = (int) ($_GET['page'] ?? 1);
        $limit  = 10;
        $offset = ($page - 1) * $limit;

        $where  = "WHERE 1=1";
        $params = [];

        if ($search) {
            $where .= " AND (name LIKE ? OR abbreviation LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        if ($status === 'active') {
            $where .= " AND is_active = 1";
        } elseif ($status === 'inactive') {
            $where .= " AND is_active = 0";
        }

        $orderBy = "name ASC";
        if ($sort === 'name_desc') $orderBy = "name DESC";
        elseif ($sort === 'newest') $orderBy = "created_at DESC";

        // 1. Get total rows for pagination
        $countQuery = "SELECT COUNT(*) FROM parties $where";
        $totalRows = $db->query($countQuery, $params)->fetchColumn();
        $totalPages = ceil($totalRows / $limit);
        if ($page > $totalPages && $totalPages > 0) $page = $totalPages;

        // 2. Fetch paginated results
        $parties = $db->query(
            "SELECT * FROM parties $where ORDER BY $orderBy LIMIT $limit OFFSET $offset",
            $params
        )->fetchAll();

        $this->log(ActivityLog::READ, 'Party', "Viewed political parties list (Search: \"$search\", Page: $page)");

        $this->view('admin/parties/index', [
            'title'      => 'Political Parties',
            'parties'    => $parties,
            'search'     => $search,
            'status'     => $status,
            'sort'       => $sort,
            'page'       => $page,
            'totalPages' => $totalPages,
            'totalRows'  => $totalRows
        ]);
    }

    // ── Show create form ──────────────────────────────────────────────
    public function create(): void {
        Auth::requireAdmin();
        $this->log(ActivityLog::READ, 'Party', 'Opened create party form');

        $this->view('admin/parties/create', [
            'title' => 'Add Party',
        ]);
    }

    // ── Handle create submission ──────────────────────────────────────
    public function store(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/parties/create');
        }

        $name   = trim($_POST['name']         ?? '');
        $abbr   = trim($_POST['abbreviation'] ?? '');
        $symbol = trim($_POST['symbol_url']   ?? '');

        if (!$name || !$abbr) {
            $this->redirect(BASE_URL . '/admin/parties/create?error=missing_fields');
        }

        $db = Database::getInstance();
        
        // Check for duplicates
        $existing = $db->query(
            "SELECT id FROM parties WHERE name = ? OR abbreviation = ?",
            [$name, $abbr]
        )->fetch();

        if ($existing) {
            $this->redirect(BASE_URL . '/admin/parties/create?error=exists');
        }

        $db->query(
            "INSERT INTO parties (name, abbreviation, symbol_url, is_active) VALUES (?, ?, ?, 1)",
            [$name, $abbr, $symbol]
        );
        $newId = (int) $db->query("SELECT LAST_INSERT_ID() AS id")->fetch()['id'];

        $this->log(
            ActivityLog::CREATE,
            'Party',
            "Registered political party: \"{$name}\" ({$abbr})",
            $newId
        );

        $this->redirect(BASE_URL . '/admin/parties?success=added');
    }

    // ── Show edit form ────────────────────────────────────────────────
    public function edit(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? 0);
        $db = Database::getInstance();

        $party = $db->query("SELECT * FROM parties WHERE id = ?", [$id])->fetch();
        if (!$party) {
            $this->redirect(BASE_URL . '/admin/parties?error=not_found');
        }

        $this->view('admin/parties/edit', [
            'title' => 'Edit Party',
            'party' => $party,
        ]);
    }

    // ── Handle update submission ──────────────────────────────────────
    public function update(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/parties');
        }

        $id       = (int)  ($_POST['id']           ?? 0);
        $name     = trim(  $_POST['name']           ?? '');
        $abbr     = trim(  $_POST['abbreviation']   ?? '');
        $symbol   = trim(  $_POST['symbol_url']     ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if (!$name || !$abbr) {
            $this->redirect(BASE_URL . "/admin/parties/edit?id={$id}&error=missing_fields");
        }

        $db = Database::getInstance();

        // Check for duplicates (excluding current)
        $existing = $db->query(
            "SELECT id FROM parties WHERE (name = ? OR abbreviation = ?) AND id != ?",
            [$name, $abbr, $id]
        )->fetch();

        if ($existing) {
            $this->redirect(BASE_URL . "/admin/parties/edit?id={$id}&error=exists");
        }

        $before = $db->query("SELECT name, abbreviation, symbol_url, is_active FROM parties WHERE id = ?", [$id])->fetch();

        $db->query(
            "UPDATE parties SET name = ?, abbreviation = ?, symbol_url = ?, is_active = ? WHERE id = ?",
            [$name, $abbr, $symbol, $isActive, $id]
        );

        $changes = [];
        if ($before['name']         !== $name)            $changes[] = "name → \"{$name}\"";
        if ($before['abbreviation'] !== $abbr)            $changes[] = "abbr → {$abbr}";
        if ($before['symbol_url']   !== $symbol)          $changes[] = "symbol updated";
        if ((int) $before['is_active'] !== $isActive)     $changes[] = 'status → ' . ($isActive ? 'Active' : 'Inactive');
        
        $desc = $changes
            ? "Updated party #{$id}: " . implode(', ', $changes)
            : "Updated party #{$id} (no changes)";

        $this->log(ActivityLog::UPDATE, 'Party', $desc, $id);

        $this->redirect(BASE_URL . '/admin/parties?success=updated');
    }

    // ── Delete a party ────────────────────────────────────────────────
    public function delete(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $party = $db->query("SELECT name FROM parties WHERE id = ?", [$id])->fetch();
        if (!$party) {
            $this->redirect(BASE_URL . '/admin/parties');
        }

        $db->query("DELETE FROM parties WHERE id = ?", [$id]);

        $this->log(
            ActivityLog::DELETE,
            'Party',
            "Deleted political party #{$id}: \"{$party['name']}\"",
            $id
        );

        $this->redirect(BASE_URL . '/admin/parties');
    }
}
