<?php

class OfficerController extends Controller {

    /**
     * List all officers (admins)
     */
    public function index(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? ''); // Status here acts as role filter
        $sort   = trim($_GET['sort'] ?? 'newest');
        $page   = (int) ($_GET['page'] ?? 1);
        $limit  = 10;
        $offset = ($page - 1) * $limit;

        $where  = "WHERE 1=1";
        $params = [];

        if ($search) {
            $where .= " AND (full_name LIKE ? OR email LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        if ($status) {
            $where .= " AND role = ?";
            $params[] = $status;
        }

        $orderBy = "created_at DESC";
        if ($sort === 'oldest') $orderBy = "created_at ASC";
        elseif ($sort === 'name_asc') $orderBy = "full_name ASC";
        elseif ($sort === 'name_desc') $orderBy = "full_name DESC";

        // 1. Get total rows
        $countQuery = "SELECT COUNT(*) FROM admins $where";
        $totalRows = $db->query($countQuery, $params)->fetchColumn();
        $totalPages = ceil($totalRows / $limit);
        if ($page > $totalPages && $totalPages > 0) $page = $totalPages;

        // 2. Fetch data
        $officers = $db->query(
            "SELECT id, full_name, email, role, last_login, created_at 
             FROM admins 
             $where 
             ORDER BY $orderBy 
             LIMIT $limit OFFSET $offset",
            $params
        )->fetchAll();

        $this->log(ActivityLog::READ, 'Officers', "Viewed administrative officers list (Search: \"$search\", Page: $page)");

        $this->view('admin/officers/index', [
            'title'      => 'System Officers',
            'officers'   => $officers,
            'search'     => $search,
            'status'     => $status,
            'sort'       => $sort,
            'page'       => $page,
            'totalPages' => $totalPages,
            'totalRows'  => $totalRows,
            'success'    => $_GET['success'] ?? '',
            'error'      => $_GET['error']   ?? ''
        ]);
    }

    /**
     * Show form to create a new officer
     */
    public function create(): void {
        Auth::requireAdmin();
        $this->view('admin/officers/create', [
            'title' => 'Add New Officer'
        ]);
    }

    /**
     * Store a new officer in the database
     */
    public function store(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/officers');
        }

        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email']     ?? '');
        $role     = trim($_POST['role']      ?? 'Officer');
        $password = $_POST['password']       ?? '';

        if (!$fullName || !$email || !$password) {
            $this->redirect(BASE_URL . '/admin/officers/create?error=missing_fields');
        }

        $db = Database::getInstance();
        
        // Check if email exists
        $existing = $db->query("SELECT id FROM admins WHERE email = ?", [$email])->fetch();
        if ($existing) {
            $this->redirect(BASE_URL . '/admin/officers/create?error=email_exists');
        }

        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $db->query(
            "INSERT INTO admins (full_name, email, role, password, created_at) VALUES (?, ?, ?, ?, NOW())",
            [$fullName, $email, $role, $hashed]
        );

        $newId = (int) $db->query("SELECT LAST_INSERT_ID() AS id")->fetch()['id'];

        $this->log(
            ActivityLog::CREATE,
            'Officers',
            "Added new officer: \"{$fullName}\" ({$email})",
            $newId
        );

        $this->redirect(BASE_URL . '/admin/officers?success=officer_added');
    }

    /**
     * Show form to edit an existing officer
     */
    public function edit(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? 0);
        $db = Database::getInstance();

        $officer = $db->query("SELECT id, full_name, email, role FROM admins WHERE id = ?", [$id])->fetch();
        if (!$officer) {
            $this->redirect(BASE_URL . '/admin/officers?error=not_found');
        }

        $this->view('admin/officers/edit', [
            'title'   => 'Edit Officer',
            'officer' => $officer
        ]);
    }

    /**
     * Update an officer's details
     */
    public function update(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/officers');
        }

        $id       = (int)  ($_POST['id']        ?? 0);
        $fullName = trim(  $_POST['full_name']   ?? '');
        $email    = trim(  $_POST['email']       ?? '');
        $role     = trim(  $_POST['role']        ?? 'Officer');
        $password = $_POST['password']           ?? '';

        if (!$fullName || !$email) {
            $this->redirect(BASE_URL . "/admin/officers/edit?id={$id}&error=missing_fields");
        }

        $db = Database::getInstance();
        
        // Check email uniqueness
        $existing = $db->query("SELECT id FROM admins WHERE email = ? AND id != ?", [$email, $id])->fetch();
        if ($existing) {
            $this->redirect(BASE_URL . "/admin/officers/edit?id={$id}&error=email_exists");
        }

        if ($password) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $db->query(
                "UPDATE admins SET full_name = ?, email = ?, role = ?, password = ?, updated_at = NOW() WHERE id = ?",
                [$fullName, $email, $role, $hashed, $id]
            );
        } else {
            $db->query(
                "UPDATE admins SET full_name = ?, email = ?, role = ?, updated_at = NOW() WHERE id = ?",
                [$fullName, $email, $role, $id]
            );
        }

        // Update session if it's the current user
        if ($id === (int) $_SESSION['admin_id']) {
            $_SESSION['admin_name'] = $fullName;
        }

        $this->log(
            ActivityLog::UPDATE,
            'Officers',
            "Updated officer details for: \"{$fullName}\" (#{$id})",
            $id
        );

        $this->redirect(BASE_URL . '/admin/officers?success=officer_updated');
    }

    /**
     * Delete an officer
     */
    public function delete(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        
        // Prevent self-deletion
        if ($id === (int) $_SESSION['admin_id']) {
            $this->redirect(BASE_URL . '/admin/officers?error=self_delete');
        }

        $db = Database::getInstance();
        $officer = $db->query("SELECT full_name FROM admins WHERE id = ?", [$id])->fetch();
        
        if (!$officer) {
            $this->redirect(BASE_URL . '/admin/officers?error=not_found');
        }

        $db->query("DELETE FROM admins WHERE id = ?", [$id]);

        $this->log(
            ActivityLog::DELETE,
            'Officers',
            "Deleted officer: \"{$officer['full_name']}\" (#{$id})",
            $id
        );

        $this->redirect(BASE_URL . '/admin/officers?success=officer_deleted');
    }
}
