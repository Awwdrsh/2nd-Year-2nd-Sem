<?php

class VoterController extends Controller
{

    // ── List all registered voters ────────────────────────────────────
    public function index(): void
    {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? '');
        $sort   = trim($_GET['sort'] ?? 'newest');
        $page   = (int) ($_GET['page'] ?? 1);
        $limit  = 10;
        $offset = ($page - 1) * $limit;

        $where  = "WHERE 1=1";
        $params = [];

        if ($search) {
            $where .= " AND (ci.full_name LIKE ? OR u.voter_id LIKE ? OR u.nid LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        if ($status === 'active') {
            $where .= " AND (u.blocked_until IS NULL OR u.blocked_until <= NOW())";
        } elseif ($status === 'blocked') {
            $where .= " AND (u.blocked_until > NOW())";
        }

        $orderBy = "u.created_at DESC";
        if ($sort === 'oldest') $orderBy = "u.created_at ASC";
        elseif ($sort === 'name_asc') $orderBy = "ci.full_name ASC";
        elseif ($sort === 'name_desc') $orderBy = "ci.full_name DESC";

        // 1. Get total rows for pagination
        $countQuery = "SELECT COUNT(*) FROM users u JOIN citizens ci ON u.nid = ci.nid $where";
        $totalRows = $db->query($countQuery, $params)->fetchColumn();
        $totalPages = ceil($totalRows / $limit);
        if ($page > $totalPages && $totalPages > 0) $page = $totalPages;

        // 2. Fetch paginated results
        $voters = $db->query(
            "SELECT u.id, u.voter_id, u.created_at, u.blocked_until,
                    ci.full_name, ci.district, ci.municipality,
                    co.name AS constituency_name
             FROM   users u
             JOIN   citizens ci ON u.nid = ci.nid
             LEFT JOIN constituencies co ON u.constituency_id = co.id
             $where
             ORDER BY $orderBy
             LIMIT $limit OFFSET $offset",
            $params
        )->fetchAll();

        $this->log(ActivityLog::READ, 'Voter', 'Viewed voter registry list (Search: "' . $search . '", Page: ' . $page . ')');

        $this->view('admin/voters/index', [
            'title'      => 'Voter Registry',
            'voters'     => $voters,
            'search'     => $search,
            'status'     => $status,
            'sort'       => $sort,
            'page'       => $page,
            'totalPages' => $totalPages,
            'totalRows'  => $totalRows
        ]);
    }

    // ── View a single voter's detail ──────────────────────────────────
    public function show(): void
    {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? 0);
        $db = Database::getInstance();

        $voter = $db->query(
            "SELECT u.*, ci.full_name, ci.date_of_birth, ci.district,
                    ci.municipality, ci.ward_no, ci.citizenship_no,
                    co.name AS constituency_name
             FROM   users u
             JOIN   citizens ci ON u.nid = ci.nid
             LEFT JOIN constituencies co ON u.constituency_id = co.id
             WHERE  u.id = ?",
            [$id]
        )->fetch();

        if (!$voter) {
            http_response_code(404);
            die('Voter not found.');
        }

        $this->log(
            ActivityLog::READ,
            'Voter',
            "Viewed voter profile: \"{$voter['full_name']}\" (voter ID: {$voter['voter_id']})",
            $id
        );

        $this->view('admin/voters/show', [
            'title' => 'Voter Detail',
            'voter' => $voter,
        ]);
    }

    // ── Block a voter account ─────────────────────────────────────────
    public function block(): void
    {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $voter = $db->query(
            "SELECT u.id, u.voter_id, ci.full_name
             FROM   users u
             JOIN   citizens ci ON u.nid = ci.nid
             WHERE  u.id = ?",
            [$id]
        )->fetch();

        if (!$voter) {
            $this->redirect(BASE_URL . '/admin/voters');
        }

        // Block for 24 hours
        $db->query(
            "UPDATE users SET blocked_until = DATE_ADD(NOW(), INTERVAL 24 HOUR) WHERE id = ?",
            [$id]
        );

        $this->log(
            ActivityLog::UPDATE,
            'Voter',
            "Blocked voter account: \"{$voter['full_name']}\" (voter ID: {$voter['voter_id']}) for 24 hours",
            $id
        );

        $this->redirect(BASE_URL . '/admin/voters');
    }

    // ── Unblock a voter account ───────────────────────────────────────
    public function unblock(): void
    {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $voter = $db->query(
            "SELECT u.id, u.voter_id, ci.full_name
             FROM   users u
             JOIN   citizens ci ON u.nid = ci.nid
             WHERE  u.id = ?",
            [$id]
        )->fetch();

        if (!$voter) {
            $this->redirect(BASE_URL . '/admin/voters');
        }

        $db->query(
            "UPDATE users SET blocked_until = NULL, failed_attempts = 0 WHERE id = ?",
            [$id]
        );

        $this->log(
            ActivityLog::UPDATE,
            'Voter',
            "Unblocked voter account: \"{$voter['full_name']}\" (voter ID: {$voter['voter_id']})",
            $id
        );

        $this->redirect(BASE_URL . '/admin/voters');
    }

    // ── Delete (deregister) a voter ───────────────────────────────────────
    public function delete(): void
    {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $voter = $db->query(
            "SELECT u.id, u.voter_id, ci.full_name
         FROM   users u
         JOIN   citizens ci ON u.nid = ci.nid
         WHERE  u.id = ?",
            [$id]
        )->fetch();

        if (!$voter) {
            $this->redirect(BASE_URL . '/admin/voters');
        }

        // Block deletion if user is a registered candidate
        $isCandidate = $db->query(
            "SELECT id FROM candidates WHERE user_id = ? LIMIT 1",
            [$id]
        )->fetch();

        if ($isCandidate) {
            $this->redirect(
                BASE_URL . '/admin/voters?error=is_candidate&name=' . urlencode($voter['full_name'])
            );
            return;
        }

        // Block deletion if user has cast any votes (data integrity)
        $hasVoted = $db->query(
            "SELECT id FROM votes WHERE voter_hash LIKE ? LIMIT 1",
            ['%'] // voter_hash is anonymised; skip this check — votes table has no direct user_id
        );
        // Note: votes are already anonymised via voter_hash, so no FK from votes→users exists.
        // Safe to delete directly.

        try {
            $db->query("DELETE FROM users WHERE id = ?", [$id]);
        } catch (\PDOException $e) {
            // Catch any unexpected FK constraint violations gracefully
            $this->redirect(
                BASE_URL . '/admin/voters?error=fk_constraint&name=' . urlencode($voter['full_name'])
            );
            return;
        }

        $this->log(
            ActivityLog::DELETE,
            'Voter',
            "Deleted (deregistered) voter: \"{$voter['full_name']}\" (voter ID: {$voter['voter_id']})",
            $id
        );

        $this->redirect(BASE_URL . '/admin/voters?success=deleted');
    }

    // ── Change/Reset a voter password ────────────────────────────────────────
    public function resetPassword(): void
    {
        Auth::requireAdmin();
        $id = (int) ($_POST['id'] ?? 0);
        $customPassword = trim($_POST['new_password'] ?? '');
        $db = Database::getInstance();

        $voter = $db->query(
            "SELECT u.id, u.nid, ci.full_name
             FROM   users u
             JOIN   citizens ci ON u.nid = ci.nid
             WHERE  u.id = ?",
            [$id]
        )->fetch();

        if (!$voter) {
            $this->redirect(BASE_URL . '/admin/voters');
        }

        $isCustom = !empty($customPassword);
        $newPassword = $isCustom ? $customPassword : 'pwd' . $voter['nid'];
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);

        $db->query("UPDATE users SET password = ? WHERE id = ?", [$hashed, $id]);

        $logMsg = $isCustom
            ? "Changed password for voter: \"{$voter['full_name']}\" to a custom password"
            : "Reset password for voter: \"{$voter['full_name']}\" (Default set to pwd + NID)";

        $this->log(ActivityLog::UPDATE, 'Voter', $logMsg, $id);
        $this->redirect(BASE_URL . '/admin/voters/show?id=' . $id . '&success=password_reset');
    }

    // ── Voter Activity & Login Logs ──────────────────────────────────
    public function activity(): void
    {
        Auth::requireAdmin();
        $db = Database::getInstance();
        $secret = VOTE_SECRET;

        $search = trim($_GET['search'] ?? '');
        $page   = (int) ($_GET['page'] ?? 1);
        $limit  = 15;
        $offset = ($page - 1) * $limit;

        $where  = "WHERE 1=1";
        $params = [];

        if ($search) {
            $where .= " AND (ci.full_name LIKE ? OR u.voter_id LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        // 1. Get total rows for pagination
        $countQuery = "SELECT COUNT(*) FROM users u JOIN citizens ci ON u.nid = ci.nid $where";
        $totalRows = $db->query($countQuery, $params)->fetchColumn();
        $totalPages = ceil($totalRows / $limit);
        if ($page > $totalPages && $totalPages > 0) $page = $totalPages;

        // 2. Fetch voters with their login and voting status
        // We use EXISTS with SHA2 to check if they have at least one vote in any pool
        $voters = $db->query(
            "SELECT u.id, u.voter_id, u.last_login, ci.full_name, ci.district,
                    EXISTS (
                        SELECT 1 FROM votes v 
                        JOIN pools p ON v.pool_id = p.id
                        WHERE v.voter_hash = SHA2(CONCAT(u.id, p.id, ?), 256)
                    ) as has_voted
             FROM   users u
             JOIN   citizens ci ON u.nid = ci.nid
             $where
             ORDER BY u.last_login DESC, u.created_at DESC
             LIMIT $limit OFFSET $offset",
            array_merge([$secret], $params)
        )->fetchAll();

        $this->log(ActivityLog::READ, 'Voter', 'Viewed voter activity logs');

        $this->view('admin/voters/activity', [
            'title'      => 'Voter Activity Logs',
            'voters'     => $voters,
            'search'     => $search,
            'page'       => $page,
            'totalPages' => $totalPages,
            'totalRows'  => $totalRows
        ]);
    }
}
