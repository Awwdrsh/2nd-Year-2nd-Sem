<?php

class PoolController extends Controller {

    // ── List all pools ────────────────────────────────────────────────
    public function index(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $search = trim($_GET['search'] ?? '');
        $status = trim($_GET['status'] ?? '');
        $sort   = trim($_GET['sort'] ?? 'newest');
        $page   = (int) ($_GET['page'] ?? 1);
        $limit  = 10;
        $offset = ($page - 1) * $limit;

        $where  = "WHERE 1=1";
        $params = [];

        if ($search) {
            $where .= " AND (p.title LIKE ? OR e.title LIKE ? OR co.name LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        if ($status) {
            $where .= " AND p.status = ?";
            $params[] = $status;
        }

        $orderBy = "p.created_at DESC";
        if ($sort === 'oldest') $orderBy = "p.created_at ASC";
        elseif ($sort === 'title_asc') $orderBy = "p.title ASC";
        elseif ($sort === 'title_desc') $orderBy = "p.title DESC";

        // 1. Get total rows
        $countQuery = "SELECT COUNT(*) FROM pools p 
                       JOIN elections e ON p.election_id = e.id 
                       JOIN constituencies co ON p.constituency_id = co.id $where";
        $totalRows = $db->query($countQuery, $params)->fetchColumn();
        $totalPages = ceil($totalRows / $limit);
        if ($page > $totalPages && $totalPages > 0) $page = $totalPages;

        // 2. Fetch paginated data
        $pools = $db->query(
            "SELECT p.*, e.title AS election_title, co.name AS constituency_name,
                    a.full_name AS created_by_name,
                    (SELECT GROUP_CONCAT(CONCAT(ci.full_name, ':', pc.id) SEPARATOR '|') 
                     FROM pool_candidates pc 
                     JOIN candidates c ON pc.candidate_id = c.id
                     JOIN users u ON c.user_id = u.id
                     JOIN citizens ci ON u.nid = ci.nid
                     WHERE pc.pool_id = p.id) AS assigned_candidates_list,
                    (SELECT COUNT(*) FROM pool_candidates pc WHERE pc.pool_id = p.id) AS candidate_count,
                    (SELECT GROUP_CONCAT(CONCAT(pa.name, ':', pp.id) SEPARATOR '|') 
                     FROM pool_parties pp 
                     JOIN parties pa ON pp.party_id = pa.id
                     WHERE pp.pool_id = p.id) AS assigned_parties_list,
                    (SELECT COUNT(*) FROM pool_parties pp WHERE pp.pool_id = p.id) AS party_count
             FROM   pools p
             JOIN   elections e       ON p.election_id     = e.id
             JOIN   constituencies co ON p.constituency_id = co.id
             JOIN   admins a          ON p.created_by      = a.id
             $where
             ORDER BY $orderBy
             LIMIT $limit OFFSET $offset",
            $params
        )->fetchAll();

        // Fetch all eligible candidates grouped by constituency for the inline dropdown
        $eligibleData = $db->query(
            "SELECT c.id, ci.full_name, c.constituency_id, c.election_type
             FROM candidates c
             JOIN users u ON c.user_id = u.id
             JOIN citizens ci ON u.nid = ci.nid
             WHERE c.nomination_status = 'approved' AND c.is_active = 1
             ORDER BY ci.full_name"
        )->fetchAll();

        $eligibleByConst = [];
        foreach ($eligibleData as $cand) {
            $eligibleByConst[$cand['constituency_id']][] = $cand;
        }

        $this->log(ActivityLog::READ, 'Pool', "Viewed voting pools (Search: \"$search\", Page: $page)");

        $allParties = $db->query("SELECT id, name FROM parties WHERE is_active = 1 ORDER BY name")->fetchAll();

        $this->view('admin/pools/index', [
            'title'           => 'Voting Pools',
            'pools'           => $pools,
            'eligibleByConst' => $eligibleByConst,
            'allParties'      => $allParties,
            'search'          => $search,
            'status'          => $status,
            'sort'            => $sort,
            'page'            => $page,
            'totalPages'      => $totalPages,
            'totalRows'       => $totalRows
        ]);
    }

    // ── Show create form ──────────────────────────────────────────────
    public function create(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();

        $elections      = $db->query("SELECT id, title, voting_start, voting_end FROM elections ORDER BY title")->fetchAll();

        $constituencies = $db->query("SELECT id, name FROM constituencies ORDER BY name")->fetchAll();

        $this->log(ActivityLog::READ, 'Pool', 'Opened create voting pool form');

        $this->view('admin/pools/create', [
            'title'          => 'Create Voting Pool',
            'elections'      => $elections,
            'constituencies' => $constituencies,
        ]);
    }

    // ── Handle create submission ──────────────────────────────────────
    public function store(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/pools/create');
        }

        $electionId     = (int)   ($_POST['election_id']     ?? 0);
        $constituencyId = (int)   ($_POST['constituency_id'] ?? 0);
        $title          = trim(   $_POST['title']            ?? '');
        $poolType       = trim(   $_POST['pool_type']        ?? 'fptp');
        $electionType   = trim(   $_POST['election_type']    ?? 'national');
        $votingStart    = trim(   $_POST['voting_start']     ?? '');
        $votingEnd      = trim(   $_POST['voting_end']       ?? '');
        $description    = trim(   $_POST['description']      ?? '');
        $adminId        = (int)   ($_SESSION['admin_id']     ?? 0);

        if (!$electionId || !$constituencyId || !$title || !$votingStart || !$votingEnd) {
            $this->redirect(BASE_URL . '/admin/pools/create?error=missing_fields');
        }

        if (strtotime($votingEnd) <= strtotime($votingStart)) {
            $this->redirect(BASE_URL . '/admin/pools/create?error=invalid_dates');
        }

        $db = Database::getInstance();
        $db->query(
            "INSERT INTO pools
                (election_id, constituency_id, title, pool_type, election_type,
                 status, description, voting_start, voting_end, created_by)
             VALUES (?, ?, ?, ?, ?, 'upcoming', ?, ?, ?, ?)",
            [$electionId, $constituencyId, $title, $poolType, $electionType,
             $description, $votingStart, $votingEnd, $adminId]
        );
        $newId = (int) $db->query("SELECT LAST_INSERT_ID() AS id")->fetch()['id'];

        // Auto-assign candidates from the selected constituency
        $this->autoAssignCandidates($newId, $constituencyId);

        $this->log(
            ActivityLog::CREATE,
            'Pool',
            "Created voting pool: \"{$title}\" (constituency_id: {$constituencyId}, election_id: {$electionId})",
            $newId
        );

        $this->redirect(BASE_URL . '/admin/pools/' . $newId . '/candidates?success=created');
    }

    // ── Show edit form ────────────────────────────────────────────────
    public function edit(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? 0);
        $db = Database::getInstance();

        $pool = $db->query("SELECT * FROM pools WHERE id = ?", [$id])->fetch();
        if (!$pool) {
            http_response_code(404);
            die('Pool not found.');
        }

        $elections      = $db->query("SELECT id, title FROM elections ORDER BY title")->fetchAll();
        $constituencies = $db->query("SELECT id, name FROM constituencies ORDER BY name")->fetchAll();

        $this->log(ActivityLog::READ, 'Pool', "Viewed edit form for pool #{$id}: \"{$pool['title']}\"", $id);

        $this->view('admin/pools/edit', [
            'title'          => 'Edit Pool',
            'pool'           => $pool,
            'elections'      => $elections,
            'constituencies' => $constituencies,
        ]);
    }

    // ── Handle update submission ──────────────────────────────────────
    public function update(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/pools');
        }

        $id          = (int)  ($_POST['id']           ?? 0);
        $title       = trim(  $_POST['title']         ?? '');
        $status      = trim(  $_POST['status']        ?? 'upcoming');
        $start       = trim(  $_POST['voting_start']  ?? '');
        $end         = trim(  $_POST['voting_end']    ?? '');
        $description = trim(  $_POST['description']   ?? '');

        $db     = Database::getInstance();
        $before = $db->query("SELECT title, status FROM pools WHERE id = ?", [$id])->fetch();

        $db->query(
            "UPDATE pools SET title = ?, status = ?, voting_start = ?, voting_end = ?,
                    description = ?, updated_at = NOW()
             WHERE id = ?",
            [$title, $status, $start, $end, $description, $id]
        );

        $changes = [];
        if ($before['title']  !== $title)  $changes[] = "title → \"{$title}\"";
        if ($before['status'] !== $status) $changes[] = "status → {$status}";
        $desc = $changes
            ? "Updated pool #{$id}: " . implode(', ', $changes)
            : "Updated pool #{$id} (no field changes)";

        $this->log(ActivityLog::UPDATE, 'Pool', $desc, $id);

        $this->redirect(BASE_URL . '/admin/pools');
    }

    // ── Delete a pool ─────────────────────────────────────────────────
    public function delete(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));
        $db = Database::getInstance();

        $pool = $db->query("SELECT title FROM pools WHERE id = ?", [$id])->fetch();
        if (!$pool) {
            $this->redirect(BASE_URL . '/admin/pools');
        }

        // Check for votes cast in this pool
        $voteCount = (int) $db->query("SELECT COUNT(*) AS c FROM votes WHERE pool_id = ?", [$id])->fetch()['c'];
        if ($voteCount > 0) {
            $this->redirect(BASE_URL . '/admin/pools?error=has_votes');
            return;
        }

        $db->query("DELETE FROM pool_candidates WHERE pool_id = ?", [$id]);
        $db->query("DELETE FROM pool_parties WHERE pool_id = ?", [$id]);
        $db->query("DELETE FROM pools WHERE id = ?", [$id]);

        $this->log(ActivityLog::DELETE, 'Pool', "Deleted voting pool #{$id}: \"{$pool['title']}\"", $id);

        $this->redirect(BASE_URL . '/admin/pools?success=deleted');
    }

    // ── Handle Bulk Actions (Bulk Deletion) ───────────────────────────
    public function bulkAction(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/pools');
        }

        $poolIds = $_POST['pool_ids'] ?? [];
        $action  = $_POST['action']   ?? '';

        if (empty($poolIds) || $action !== 'delete') {
            $this->redirect(BASE_URL . '/admin/pools?error=no_selection');
        }

        $db = Database::getInstance();
        $deletedCount = 0;
        $failedCount  = 0;

        foreach ($poolIds as $id) {
            $id = (int)$id;
            // Check for votes
            $voteCount = (int) $db->query("SELECT COUNT(*) AS c FROM votes WHERE pool_id = ?", [$id])->fetch()['c'];
            if ($voteCount > 0) {
                $failedCount++;
                continue;
            }

            $db->query("DELETE FROM pool_candidates WHERE pool_id = ?", [$id]);
            $db->query("DELETE FROM pool_parties WHERE pool_id = ?", [$id]);
            $db->query("DELETE FROM pools WHERE id = ?", [$id]);
            $deletedCount++;
        }

        $msg = "Successfully deleted {$deletedCount} pools.";
        if ($failedCount > 0) {
            $msg .= " {$failedCount} pools could not be deleted because they have votes cast.";
        }

        $this->log(ActivityLog::DELETE, 'Pool', "Bulk deletion performed: {$deletedCount} removed, {$failedCount} skipped.");
        $this->redirect(BASE_URL . '/admin/pools?success=bulk_deleted&count=' . $deletedCount . '&failed=' . $failedCount);
    }

    // ── Bulk Auto-Assign Candidates ───────────────────────────────────
    public function bulkAssignCandidates(): void {
        Auth::requireAdmin();
        $db = Database::getInstance();
        
        $addedCount = 0;
        $pools = $db->query("SELECT id, constituency_id, pool_type FROM pools WHERE status IN ('upcoming', 'active')")->fetchAll();
        
        foreach ($pools as $pool) {
            $poolId = $pool['id'];
            $constId = $pool['constituency_id'];
            
            if ($pool['pool_type'] === 'pr') {
                // Assign ALL active parties to PR pools
                $eligibleParties = $db->query(
                    "SELECT id AS party_id FROM parties 
                     WHERE is_active = 1
                       AND id NOT IN (SELECT party_id FROM pool_parties WHERE pool_id = ?)",
                    [$poolId]
                )->fetchAll();
                
                foreach ($eligibleParties as $p) {
                    $maxOrderRow = $db->query("SELECT MAX(ballot_order) AS max_order FROM pool_parties WHERE pool_id = ?", [$poolId])->fetch();
                    $nextOrder = ($maxOrderRow['max_order'] ?? 0) + 1;
                    $db->query("INSERT IGNORE INTO pool_parties (pool_id, party_id, ballot_order) VALUES (?, ?, ?)", [$poolId, $p['party_id'], $nextOrder]);
                    $addedCount++;
                }
            } else {
                $eligible = $db->query(
                    "SELECT c.id FROM candidates c
                     WHERE c.constituency_id = ? AND c.nomination_status = 'approved' AND c.is_active = 1
                       AND c.election_type = 'fptp'
                       AND c.id NOT IN (SELECT candidate_id FROM pool_candidates)",
                    [$constId]
                )->fetchAll();
                
                foreach ($eligible as $cand) {
                    $maxOrderRow = $db->query("SELECT MAX(ballot_order) AS max_order FROM pool_candidates WHERE pool_id = ?", [$poolId])->fetch();
                    $nextOrder = ($maxOrderRow['max_order'] ?? 0) + 1;
                    $db->query("INSERT IGNORE INTO pool_candidates (pool_id, candidate_id, ballot_order) VALUES (?, ?, ?)", [$poolId, $cand['id'], $nextOrder]);
                    $addedCount++;
                }
            }
        }
        
        $this->log(ActivityLog::CREATE, 'Pool', "Bulk assigned {$addedCount} eligible entities to pools automatically.");
        $this->redirect(BASE_URL . '/admin/pools?success=auto_assigned&count=' . $addedCount);
    }

    // ── Manage candidates in a pool ───────────────────────────────────
    public function candidates(): void {
        Auth::requireAdmin();
        $id = (int) ($_GET['id'] ?? 0);
        $db = Database::getInstance();

        $pool = $db->query(
            "SELECT p.*, e.title AS election_title, co.name AS constituency_name
             FROM pools p
             JOIN elections e ON p.election_id = e.id
             JOIN constituencies co ON p.constituency_id = co.id
             WHERE p.id = ?",
            [$id]
        )->fetch();

        if (!$pool) {
            $this->redirect(BASE_URL . '/admin/pools?error=not_found');
        }

        // Candidates or Parties already in this pool
        $poolCandidates = [];
        $poolParties = [];

        if ($pool['pool_type'] === 'pr') {
            $poolParties = $db->query(
                "SELECT pp.id AS pp_id, pp.ballot_order, p.id AS party_id,
                        p.name AS party_name, p.abbreviation, p.symbol_url
                 FROM pool_parties pp
                 JOIN parties p ON pp.party_id = p.id
                 WHERE pp.pool_id = ?
                 ORDER BY pp.ballot_order ASC, p.name ASC",
                [$id]
            )->fetchAll();
        } else {
            $poolCandidates = $db->query(
                "SELECT pc.id AS pc_id, pc.ballot_order, c.id AS candidate_id,
                        ci.full_name, p.name AS party_name, p.symbol_url
                 FROM pool_candidates pc
                 JOIN candidates c ON pc.candidate_id = c.id
                 JOIN users u ON c.user_id = u.id
                 JOIN citizens ci ON u.nid = ci.nid
                 LEFT JOIN parties p ON c.party_id = p.id
                 WHERE pc.pool_id = ?
                 ORDER BY pc.ballot_order ASC, ci.full_name ASC",
                [$id]
            )->fetchAll();
        }

        // Eligible entities NOT yet in this pool
        $eligibleCandidates = [];
        $eligibleParties = [];

        if ($pool['pool_type'] === 'pr') {
            $poolPartyIds = array_map('intval', array_column($poolParties, 'party_id'));
            $eligibleParties = $db->query(
                "SELECT id, name, abbreviation, symbol_url FROM parties WHERE is_active = 1 ORDER BY name"
            )->fetchAll();
            if (!empty($poolPartyIds)) {
                $eligibleParties = array_filter($eligibleParties, function($p) use ($poolPartyIds) {
                    return !in_array((int)$p['id'], $poolPartyIds);
                });
            }
        } else {
            $poolCandidateIds = array_map('intval', array_column($poolCandidates, 'candidate_id'));
            $eligibleCandidates = $this->getEligibleCandidates($id, $pool['constituency_id'], $poolCandidateIds);
        }

        $this->log(ActivityLog::READ, 'Pool', "Viewed assignment management for pool #{$id}", $id);

        $this->view('admin/pools/candidates', [
            'title'              => $pool['pool_type'] === 'pr' ? 'Manage Pool Parties' : 'Manage Pool Candidates',
            'pool'               => $pool,
            'poolCandidates'     => $poolCandidates,
            'poolParties'        => $poolParties,
            'eligibleCandidates' => $eligibleCandidates,
            'eligibleParties'    => $eligibleParties,
            'success'            => $_GET['success'] ?? '',
            'error'              => $_GET['error'] ?? '',
        ]);
    }

    // ── Add candidate to pool (POST) ──────────────────────────────────
    public function addCandidate(): void {
        Auth::requireAdmin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect(BASE_URL . '/admin/pools');
        }

        $poolId      = (int) ($_POST['pool_id']      ?? 0);
        $candidateId = (int) ($_POST['candidate_id'] ?? 0);
        $partyId     = (int) ($_POST['party_id']     ?? 0);

        if (!$poolId || (!$candidateId && !$partyId)) {
            $this->redirect(BASE_URL . '/admin/pools/' . $poolId . '/candidates?error=missing_fields');
        }

        $db = Database::getInstance();
        $pool = $db->query("SELECT id, title, pool_type FROM pools WHERE id = ?", [$poolId])->fetch();
        if (!$pool) {
            $this->redirect(BASE_URL . '/admin/pools?error=not_found');
        }

        if ($pool['pool_type'] === 'pr') {
            // Add Party
            $exists = $db->query("SELECT id FROM pool_parties WHERE pool_id = ? AND party_id = ?", [$poolId, $partyId])->fetch();
            if ($exists) {
                $this->redirect(BASE_URL . '/admin/pools/' . $poolId . '/candidates?error=already_assigned');
            }
            $maxOrder = (int) $db->query("SELECT COALESCE(MAX(ballot_order), 0) AS m FROM pool_parties WHERE pool_id = ?", [$poolId])->fetch()['m'];
            $db->query("INSERT INTO pool_parties (pool_id, party_id, ballot_order) VALUES (?, ?, ?)", [$poolId, $partyId, $maxOrder + 1]);
        } else {
            // Add Candidate
            $candidate = $db->query("SELECT id FROM candidates WHERE id = ? AND nomination_status = 'approved' AND is_active = 1", [$candidateId])->fetch();
            if (!$candidate) {
                $this->redirect(BASE_URL . '/admin/pools/' . $poolId . '/candidates?error=invalid_candidate');
            }
            // This candidate is already assigned to an active election pool.
            $exists = $db->query("SELECT p.title FROM pool_candidates pc JOIN pools p ON pc.pool_id = p.id WHERE pc.candidate_id = ?", [$candidateId])->fetch();
            if ($exists) {
                $this->redirect(BASE_URL . '/admin/pools/' . $poolId . '/candidates?error=already_assigned');
            }
            $maxOrder = (int) $db->query("SELECT COALESCE(MAX(ballot_order), 0) AS m FROM pool_candidates WHERE pool_id = ?", [$poolId])->fetch()['m'];
            $db->query("INSERT INTO pool_candidates (pool_id, candidate_id, ballot_order) VALUES (?, ?, ?)", [$poolId, $candidateId, $maxOrder + 1]);
        }

        $this->log(ActivityLog::CREATE, 'Pool', "Added assignment to pool #{$poolId}", $poolId);
        $this->redirect(BASE_URL . '/admin/pools/' . $poolId . '/candidates?success=added');
    }

    // ── Remove candidate from pool (POST or GET) ──────────────────────
    public function removeCandidate(): void {
        Auth::requireAdmin();
        $poolId = (int) ($_POST['pool_id'] ?? ($_GET['pool_id'] ?? 0));
        $pcId   = (int) ($_POST['pc_id']   ?? ($_GET['pc_id']   ?? 0));
        $ppId   = (int) ($_POST['pp_id']   ?? ($_GET['pp_id']   ?? 0));

        if (!$poolId || (!$pcId && !$ppId)) {
            $this->redirect(BASE_URL . '/admin/pools');
        }

        $db = Database::getInstance();

        if ($ppId) {
            // Check for votes
            $party = $db->query("SELECT party_id FROM pool_parties WHERE id = ?", [$ppId])->fetch();
            if ($party) {
                $voteCount = (int) $db->query("SELECT COUNT(*) AS c FROM votes WHERE pool_id = ? AND party_id = ?", [$poolId, $party['party_id']])->fetch()['c'];
                if ($voteCount > 0) {
                    $this->redirect(BASE_URL . '/admin/pools/' . $poolId . '/candidates?error=has_votes');
                    return;
                }
            }
            $db->query("DELETE FROM pool_parties WHERE id = ? AND pool_id = ?", [$ppId, $poolId]);
        } else {
            // Check for votes
            $voteCount = (int) $db->query("SELECT COUNT(*) AS c FROM votes WHERE pool_candidate_id = ?", [$pcId])->fetch()['c'];
            if ($voteCount > 0) {
                $this->redirect(BASE_URL . '/admin/pools/' . $poolId . '/candidates?error=has_votes');
                return;
            }
            $db->query("DELETE FROM pool_candidates WHERE id = ? AND pool_id = ?", [$pcId, $poolId]);
        }

        $this->log(ActivityLog::DELETE, 'Pool', "Removed assignment from pool #{$poolId}", $poolId);
        $this->redirect(BASE_URL . '/admin/pools/' . $poolId . '/candidates?success=removed');
    }

    // ── AJAX: get candidates by constituency ──────────────────────────
    public function getCandidatesByConstituency(): void {
        Auth::requireAdmin();
        $constituencyId = (int) ($_GET['constituency_id'] ?? 0);
        $poolId         = (int) ($_GET['pool_id'] ?? 0);
        $db = Database::getInstance();

        $poolType = 'fptp';
        if ($poolId) {
            $pool = $db->query("SELECT pool_type FROM pools WHERE id = ?", [$poolId])->fetch();
            $poolType = $pool['pool_type'] ?? 'fptp';
        }

        $candidates = $db->query(
            "SELECT c.id, ci.full_name, p.name AS party_name
             FROM candidates c
             JOIN users u ON c.user_id = u.id
             JOIN citizens ci ON u.nid = ci.nid
             LEFT JOIN parties p ON c.party_id = p.id
             WHERE c.constituency_id = ? AND c.nomination_status = 'approved' AND c.is_active = 1
               AND c.election_type = ?
             ORDER BY ci.full_name",
            [$constituencyId, $poolType]
        )->fetchAll();

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'candidates' => $candidates]);
        exit;
    }

    // ── Private helper: auto-assign approved candidates ───────────────
    private function autoAssignCandidates(int $poolId, int $constituencyId): void {
        $db = Database::getInstance();
        
        // Fetch pool type first
        $pool = $db->query("SELECT pool_type FROM pools WHERE id = ?", [$poolId])->fetch();
        $poolType = $pool['pool_type'] ?? 'fptp';

        if ($poolType === 'pr') {
            // For PR, auto-assign ALL active parties
            $parties = $db->query("SELECT id AS party_id FROM parties WHERE is_active = 1")->fetchAll();

            $order = 1;
            foreach ($parties as $p) {
                try {
                    $db->query(
                        "INSERT IGNORE INTO pool_parties (pool_id, party_id, ballot_order) VALUES (?, ?, ?)",
                        [$poolId, $p['party_id'], $order++]
                    );
                } catch (Exception $e) { }
            }
        } else {
            // For FPTP, auto-assign the individual CANDIDATES
            $candidates = $db->query(
                "SELECT id FROM candidates 
                 WHERE constituency_id = ? AND nomination_status = 'approved' AND is_active = 1
                   AND election_type = 'fptp'
                   AND id NOT IN (SELECT candidate_id FROM pool_candidates)",
                [$constituencyId]
            )->fetchAll();

            $order = 1;
            foreach ($candidates as $c) {
                try {
                    $db->query(
                        "INSERT IGNORE INTO pool_candidates (pool_id, candidate_id, ballot_order) VALUES (?, ?, ?)",
                        [$poolId, $c['id'], $order++]
                    );
                } catch (Exception $e) { }
            }
        }
    }

    // ── Private helper: candidates eligible for assignment ───────────
    private function getEligibleCandidates(int $poolId, int $constituencyId, array $excludeIds): array {
        $db = Database::getInstance();

        // Fetch pool type first
        $pool = $db->query("SELECT pool_type FROM pools WHERE id = ?", [$poolId])->fetch();
        $poolType = $pool['pool_type'] ?? 'fptp';

        $candidates = $db->query(
            "SELECT c.id, ci.full_name, p.name AS party_name
             FROM candidates c
             JOIN users u ON c.user_id = u.id
             JOIN citizens ci ON u.nid = ci.nid
             LEFT JOIN parties p ON c.party_id = p.id
             WHERE c.constituency_id = ? AND c.nomination_status = 'approved' AND c.is_active = 1
               AND c.election_type = ?
               AND c.id NOT IN (SELECT candidate_id FROM pool_candidates)
             ORDER BY ci.full_name",
            [$constituencyId, $poolType]
        )->fetchAll();

        return $candidates;
    }
}
