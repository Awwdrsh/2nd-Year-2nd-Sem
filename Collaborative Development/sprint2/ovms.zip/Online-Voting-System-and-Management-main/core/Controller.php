<?php

class Controller {

    protected function view(string $view, array $data = []): void {
        extract($data);
        $view_path = BASE_PATH . "/app/views/{$view}.php";

        if (!file_exists($view_path)) {
            http_response_code(500);
            die("View not found: {$view}");
        }

        // Make $view available inside the layout for things like page-specific CSS
        $view = $view;

        if (strpos($view, 'admin/') === 0) {
            require BASE_PATH . '/app/views/layouts/admin_layout.php';
        } elseif (strpos($view, 'voter/') === 0) {
            // Keep the voter layout logic!
            require BASE_PATH . '/app/views/layouts/voter_layout.php';
        } else {
            require $view_path;
        }
    }

    protected function redirect(string $path): void {
        header("Location: {$path}");
        exit;
    }

    protected function json(array $data, int $status = 200): void {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    /**
     * Shorthand for logging from any controller.
     * Usage: $this->log(ActivityLog::CREATE, 'Election', 'Created election: General 2025', $id);
     */
    protected function log(
        string $action,
        string $module,
        string $description,
        ?int $recordId = null
    ): void {
        // Use null instead of 0 to match your ActivityLog `?int` and avoid SQL Foreign Key errors
        $adminId = $_SESSION['admin_id'] ?? null; 
        ActivityLog::write($adminId, $action, $module, $description, $recordId);
    }
}