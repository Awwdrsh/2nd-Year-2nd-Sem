<?php
/**
 * Session Helper
 * Manages session operations with security best practices.
 */
class Session {

    private static $started = false;

    public static function start(): void {
        if (!self::$started) {
            if (session_status() === PHP_SESSION_NONE) {
                // Set session lifetime to 1 hour (3600 seconds) or more to avoid GC cleanup
                $timeout = 3600; 
                ini_set('session.gc_maxlifetime', $timeout);
                
                $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
                         || ($_SERVER['SERVER_PORT'] == 443) 
                         || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
                         || isset($_SERVER['HTTP_X_ARR_SSL']);
                $options = [
                    'cookie_httponly' => true,
                    'cookie_secure'   => $isSecure,
                    'cookie_samesite' => 'Lax',
                    'use_strict_mode' => true,
                    'cookie_lifetime' => 0, // Session cookie expires when browser closes
                ];
                session_start($options);
            }
            self::$started = true;
        }
    }

    public static function set(string $key, $value): void {
        self::start();
        $_SESSION[$key] = $value;
    }

    public static function get(string $key, $default = null) {
        self::start();
        return $_SESSION[$key] ?? $default;
    }

    public static function has(string $key): bool {
        self::start();
        return isset($_SESSION[$key]) && !empty($_SESSION[$key]);
    }

    public static function remove(string $key): void {
        self::start();
        unset($_SESSION[$key]);
    }

    public static function destroy(): void {
        self::start();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }
        session_destroy();
        self::$started = false;
    }

    public static function regenerate(): void {
        self::start();
        session_regenerate_id(true);
    }

    private static function isLocalhost(): bool {
        $host = $_SERVER['HTTP_HOST'] ?? '';
        return in_array($host, ['localhost', '127.0.0.1', '::1'], true);
    }
}
