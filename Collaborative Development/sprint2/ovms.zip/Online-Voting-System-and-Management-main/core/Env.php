<?php
/**
 * Environment Variable Handler
 * Loads .env file and provides easy access to environment variables
 */
class Env
{

    private static array $config = [];
    private static bool $loaded = false;

    public static function load(string $path = ''): void
    {
        if (self::$loaded) {
            return;
        }

        $envPath = $path ?: (
            defined('BASE_PATH')
            ? BASE_PATH
            : __DIR__
        ) . '/.env';

        if (file_exists($envPath)) {
            $lines = @file(
                $envPath,
                FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
            );

            if ($lines !== false) {
                foreach ($lines as $line) {
                    $line = trim($line);

                    // Skip blank lines and comments
                    if (empty($line) || strpos($line, '#') === 0) {
                        continue;
                    }

                    // Skip invalid lines
                    if (strpos($line, '=') === false) {
                        continue;
                    }

                    [$key, $value] = explode('=', $line, 2);

                    $key = trim($key);
                    $value = trim($value, " \t\n\r\0\x0B\"'");

                    if ($key === '') {
                        continue;
                    }

                    self::$config[$key] = $value;

                    // Make available to getenv()
                    putenv("$key=$value");

                    // Optional: also populate PHP globals
                    $_ENV[$key] = $value;
                    $_SERVER[$key] = $value;
                }
            }
        }

        self::$loaded = true;
    }

    /**
     * Get environment variable safely.
     * Priority:
     * 1. System environment variables
     * 2. $_ENV
     * 3. $_SERVER
     * 4. Loaded .env values
     * 5. Default value
     */
    public static function get(string $key, $default = ''): string
    {
        self::load();

        // 1. System environment variables
        $value = getenv($key);
        if ($value !== false && $value !== null) {
            return (string) $value;
        }

        // 2. PHP environment array
        if (array_key_exists($key, $_ENV) && $_ENV[$key] !== null) {
            return (string) $_ENV[$key];
        }

        // 3. PHP server array
        if (array_key_exists($key, $_SERVER) && $_SERVER[$key] !== null) {
            return (string) $_SERVER[$key];
        }

        // 4. Locally loaded .env values
        if (array_key_exists($key, self::$config) && self::$config[$key] !== null) {
            return (string) self::$config[$key];
        }

        // 5. Default fallback
        return (string) $default;
    }

    /**
     * Check if an environment variable exists
     */
    public static function has(string $key): bool
    {
        return self::get($key, '__NOT_FOUND__') !== '__NOT_FOUND__';
    }
}