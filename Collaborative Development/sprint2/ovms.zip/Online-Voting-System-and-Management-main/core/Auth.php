<?php
/**
 * Auth Helper
 * Guards routes — call Auth::requireAdmin() or Auth::requireVoter()
 * at the top of any controller method that needs authentication.
 */
class Auth {

    public const ADMIN_TIMEOUT = 1800; // 30 minutes
    public const VOTER_TIMEOUT = 600;  // 10 minutes

    public static function requireAdmin(): void {
        if (!Session::has('admin_id')) {
            header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . '/admin/login');
            exit;
        }
        self::checkSession('admin');
    }

    public static function requireVoter(): void {
        if (!Session::has('user')) {
            header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . '/voter/login');
            exit;
        }
        self::checkSession('voter');
    }

    public static function isAdmin(): bool {
        return Session::has('admin_id');
    }

    public static function isVoter(): bool {
        return Session::has('user');
    }

    public static function isAuthenticated(): bool {
        return self::isAdmin() || self::isVoter();
    }

    public static function getAdminId(): ?int {
        $id = Session::get('admin_id');
        return $id ? (int) $id : null;
    }

    public static function getVoterId(): ?int {
        $user = Session::get('user');
        return $user['id'] ?? null;
    }

    public static function logout(): void {
        Session::destroy();
    }

    private static function checkSession(string $role): void {
        $timeout = ($role === 'admin') ? self::ADMIN_TIMEOUT : self::VOTER_TIMEOUT;
        $lastActivity = Session::get('last_activity');
        
        // 1. Check Inactivity Timeout
        if ($lastActivity && (time() - $lastActivity) > $timeout) {
            self::logout();
            $redirect = ($role === 'admin') ? '/admin/login?error=timeout' : '/voter/login?error=timeout';
            header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . $redirect);
            exit;
        }
        
        // 2. Check Concurrent Login (Strict Single-Session)
        // Only check if database connection is available
        try {
            $db = Database::getInstance();
            $sessionId = session_id();
            
            if ($role === 'admin') {
                $adminId = self::getAdminId();
                $stmt = $db->query("SELECT session_id FROM admins WHERE id = ?", [$adminId]);
                $storedSession = $stmt->fetchColumn();
                if ($storedSession && $storedSession !== $sessionId) {
                    self::logout();
                    header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . '/admin/login?error=concurrent');
                    exit;
                }
            } else {
                $voterId = self::getVoterId();
                $stmt = $db->query("SELECT session_id FROM users WHERE id = ?", [$voterId]);
                $storedSession = $stmt->fetchColumn();
                if ($storedSession && $storedSession !== $sessionId) {
                    self::logout();
                    header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . '/voter/login?error=concurrent');
                    exit;
                }
            }
        } catch (Exception $e) {
            // Silently fail if DB has issues (e.g. column not added yet)
        }
        
        Session::set('last_activity', time());
    }
}
