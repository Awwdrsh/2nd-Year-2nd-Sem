<?php

/**
 * OTP Service
 * Shared, procedural module for generating, storing, verifying, and emailing OTPs.
 * Designed to be used by both admin and voter login flows without modification.
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function otp_generate(): string {
    return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

function otp_store(string $otp, int $ttl = 600): void {
    $_SESSION['otp_code']     = password_hash($otp, PASSWORD_DEFAULT);
    $_SESSION['otp_expires']  = time() + $ttl;
    $_SESSION['otp_attempts'] = 0;
    $_SESSION['otp_sent_at']  = time();
}

function otp_verify(string $submitted): bool {
    if (empty($_SESSION['otp_code']) || empty($_SESSION['otp_expires'])) {
        return false;
    }
    if (time() > (int) $_SESSION['otp_expires']) {
        otp_clear();
        return false;
    }
    $_SESSION['otp_attempts'] = ((int) ($_SESSION['otp_attempts'] ?? 0)) + 1;
    if ((int) $_SESSION['otp_attempts'] > 5) {
        otp_clear();
        return false;
    }
    return password_verify($submitted, $_SESSION['otp_code']);
}

function otp_clear(): void {
    unset($_SESSION['otp_code'], $_SESSION['otp_expires'], $_SESSION['otp_attempts'], $_SESSION['otp_sent_at']);
}

function otp_mask_email(string $email): string {
    $parts = explode('@', $email);
    if (count($parts) !== 2) return '***@***';
    $local  = $parts[0];
    $domain = $parts[1];
    $visible = substr($local, 0, 2);
    $masked  = $visible . str_repeat('*', max(2, strlen($local) - 2));
    return $masked . '@' . $domain;
}

function otp_send(string $recipient_name, string $recipient_email, string $otp, string $context = 'admin'): bool {
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        error_log('OTP Service: PHPMailer not found. Run `composer require phpmailer/phpmailer`.');
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = Env::get('MAIL_HOST', 'smtp-relay.brevo.com');
        $mail->SMTPAuth   = true;
        $mail->Username   = Env::get('MAIL_USER', '');
        $mail->Password   = Env::get('MAIL_PASS', '');
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int) Env::get('MAIL_PORT', '587');
        $mail->Timeout    = 15;
        $mail->CharSet    = 'UTF-8';

        // SSL options — ensures compatibility with XAMPP's OpenSSL on localhost
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true
            ]
        ];

        $fromEmail = Env::get('MAIL_FROM', 'noreply@ovms.gov.np');
        $fromName  = Env::get('MAIL_FROM_NAME', 'Nepal E-Voting OVMS');
        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($recipient_email, $recipient_name);

        $mail->isHTML(true);
        $mail->Subject = 'OVMS Login Verification Code';
        $mail->Body    = _otp_build_html($recipient_name, $otp, $context);
        $mail->AltBody = "Hello {$recipient_name},\n\nYour OVMS login code is: {$otp}\n\nThis code expires in 10 minutes. Do not share it with anyone.\n\n- Nepal E-Voting OVMS";

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log('OTP mail error: ' . $e->getMessage());
        error_log('OTP mail ErrorInfo: ' . $mail->ErrorInfo);
        return false;
    }
}

function _otp_build_html(string $name, string $otp, string $context): string {
    $portal = ($context === 'admin') ? 'Administrative Portal' : 'Voter Portal';
    $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');

    return "
    <div style='font-family:Inter,Arial,sans-serif;max-width:520px;margin:0 auto;background:#ffffff;
                border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;'>
        <div style='background:#1c2b3a;padding:24px 32px;'>
            <div style='color:#ffffff;font-size:17px;font-weight:700;'>Nepal E-Voting &mdash; OVMS</div>
            <div style='color:#94a3b8;font-size:12px;margin-top:4px;'>{$portal} Authentication</div>
        </div>
        <div style='padding:32px;'>
            <p style='color:#334155;font-size:14px;margin:0 0 8px;'>Hello <strong>{$safeName}</strong>,</p>
            <p style='color:#64748b;font-size:13px;margin:0 0 24px;'>
                A login attempt was made on the OVMS {$portal}. Use the verification code below to
                complete your sign-in. This code is valid for <strong>10 minutes</strong>.
            </p>
            <div style='background:#f1f5f9;border:2px dashed #cbd5e1;border-radius:10px;
                        text-align:center;padding:24px 20px;margin-bottom:24px;'>
                <div style='font-size:11px;color:#94a3b8;margin-bottom:8px;
                            letter-spacing:2px;text-transform:uppercase;'>Your Verification Code</div>
                <span style='font-size:42px;font-weight:800;letter-spacing:12px;color:#1c2b3a;'>
                    {$otp}
                </span>
            </div>
            <p style='color:#94a3b8;font-size:12px;margin:0;'>
                If you did not request this code, please ignore this email. Your account remains secure.
            </p>
        </div>
        <div style='background:#f8fafc;border-top:1px solid #e2e8f0;padding:16px 32px;
                    font-size:11px;color:#94a3b8;'>
            Election Commission of Nepal &mdash; Secure E-Voting Platform
        </div>
    </div>";
}
