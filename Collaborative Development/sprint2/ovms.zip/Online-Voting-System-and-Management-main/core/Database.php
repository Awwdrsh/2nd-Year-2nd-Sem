<?php

class Database {

    private static $instance = null;
    private $pdo;

    private function __construct() {
        $config = require BASE_PATH . '/config/config.php';
        $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4";
        try {
            $this->pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            
            // Sync MySQL session timezone with PHP timezone
            $tz = date('P'); // Get offset like +05:45
            $this->pdo->exec("SET time_zone = '{$tz}'");
        } catch (PDOException $e) {
            // Rethrow with a cleaner message or let the global handler catch it
            throw new PDOException("Database Connection Failed: " . $e->getMessage());
        }
    }

    public static function getInstance(): self {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function query(string $sql, array $params = []): \PDOStatement {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function prepare(string $sql): \PDOStatement {
        return $this->pdo->prepare($sql);
    }
}
