<?php
/**
 * Validation Helper
 * Provides common validation methods for forms and API input
 */
class Validator {

    private static $errors = [];

    public static function validate(array $data, array $rules): bool {
        self::$errors = [];

        foreach ($rules as $field => $fieldRules) {
            $value = $data[$field] ?? null;
            $rules_array = explode('|', $fieldRules);

            foreach ($rules_array as $rule) {
                self::applyRule($field, $value, $rule, $data);
            }
        }

        return empty(self::$errors);
    }

    private static function applyRule(string $field, $value, string $rule, array $data): void {
        if (strpos($rule, ':') !== false) {
            [$rule, $param] = explode(':', $rule, 2);
        }

        switch ($rule) {
            case 'required':
                if (empty($value)) {
                    self::$errors[$field] = ucfirst($field) . ' is required.';
                }
                break;

            case 'email':
                if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    self::$errors[$field] = ucfirst($field) . ' must be a valid email.';
                }
                break;

            case 'min':
                if (!empty($value) && strlen($value) < $param) {
                    self::$errors[$field] = ucfirst($field) . ' must be at least ' . $param . ' characters.';
                }
                break;

            case 'max':
                if (!empty($value) && strlen($value) > $param) {
                    self::$errors[$field] = ucfirst($field) . ' must not exceed ' . $param . ' characters.';
                }
                break;

            case 'unique':
                // Format: unique:table,column
                if (!empty($value)) {
                    [$table, $column] = explode(',', $param);
                    $db = Database::getInstance();
                    $result = $db->query("SELECT id FROM $table WHERE $column = ?", [$value])->fetch();
                    if ($result) {
                        self::$errors[$field] = ucfirst($field) . ' is already taken.';
                    }
                }
                break;

            case 'numeric':
                if (!empty($value) && !is_numeric($value)) {
                    self::$errors[$field] = ucfirst($field) . ' must be a number.';
                }
                break;

            case 'date':
                if (!empty($value) && !strtotime($value)) {
                    self::$errors[$field] = ucfirst($field) . ' must be a valid date.';
                }
                break;

            case 'confirmed':
                $confirmField = $field . '_confirmation';
                if ($value !== ($data[$confirmField] ?? null)) {
                    self::$errors[$field] = ucfirst($field) . ' does not match.';
                }
                break;
        }
    }

    public static function errors(): array {
        return self::$errors;
    }

    public static function error(string $field): string {
        return self::$errors[$field] ?? '';
    }

    public static function hasError(string $field): bool {
        return isset(self::$errors[$field]);
    }
}

/**
 * Input Sanitizer
 * Sanitizes user input to prevent XSS and other attacks
 */
class Sanitizer {

    public static function html(string $input): string {
        return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    }

    public static function email(string $input): string {
        return filter_var(trim($input), FILTER_SANITIZE_EMAIL);
    }

    public static function text(string $input): string {
        return trim(filter_var($input, FILTER_SANITIZE_STRING));
    }

    public static function sql(string $input): string {
        // Warning: This is a basic sanitizer. Always use prepared statements!
        return addslashes($input);
    }

    public static function url(string $input): string {
        return filter_var($input, FILTER_SANITIZE_URL);
    }
}

/**
 * Hashing Helper
 * Password and data hashing utilities
 */
class Hash {

    public static function password(string $password): string {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    public static function verify(string $password, string $hash): bool {
        return password_verify($password, $hash);
    }

    public static function sha256(string $data): string {
        return hash('sha256', $data);
    }

    public static function otp(int $length = 6): string {
        return str_pad((string) random_int(0, 10 ** $length - 1), $length, '0', STR_PAD_LEFT);
    }
}
