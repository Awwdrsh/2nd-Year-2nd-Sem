<?php

class ActivityLog {

    // Action constants — use these everywhere instead of raw strings
    const CREATE = 'CREATE';
    const READ   = 'READ';
    const UPDATE = 'UPDATE';
    const DELETE = 'DELETE';
    const LOGIN  = 'LOGIN';
    const LOGOUT = 'LOGOUT';

    /**
     * Write a single log entry.
     *
     * @param int         $adminId     Admin performing the action
     * @param string      $action      One of the constants above
     * @param string      $module      Which part of the system (Election, Candidate, etc.)
     * @param string      $description Human-readable summary of what happened
     * @param int|null    $recordId    ID of the affected record, if applicable
     */
    public static function write(
        ?int   $adminId,
        string $action,
        string $module,
        string $description,
        ?int   $recordId = null
    ): void {
        try {
            $db = Database::getInstance();
            $db->query(
                "INSERT INTO admin_activity_log
                    (admin_id, action, module, description, record_id, ip_address)
                 VALUES
                    (?, ?, ?, ?, ?, ?)",
                [
                    $adminId,
                    $action,
                    $module,
                    $description,
                    $recordId,
                    self::getIp(),
                ]
            );
        } catch (Exception $e) {
            // Logging must never crash the application — fail silently
            error_log('ActivityLog::write failed: ' . $e->getMessage());
        }
    }

    /**
     * Fetch log entries, with optional filtering.
     *
     * @param int    $limit        Rows per page
     * @param int    $offset       Pagination offset
     * @param string $filterAction Filter by action type (empty = all)
     * @param string $filterModule Filter by module name  (empty = all)
     * @param string $search       Free-text search in description or admin name
     */
    public static function fetch(
        int    $limit        = 50,
        int    $offset       = 0,
        string $filterAction = '',
        string $filterModule = '',
        string $search       = ''
    ): array {
        $db     = Database::getInstance();
        $where  = [];
        $params = [];

        if ($filterAction !== '') {
            $where[]  = 'l.action = ?';
            $params[] = $filterAction;
        }
        if ($filterModule !== '') {
            $where[]  = 'l.module = ?';
            $params[] = $filterModule;
        }
        if ($search !== '') {
            $where[]  = '(l.description LIKE ? OR a.full_name LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }

        $whereClause = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $limit  = (int) $limit;
        $offset = (int) $offset;

        return $db->query(
            "SELECT l.*, a.full_name AS admin_name
             FROM   admin_activity_log l
             LEFT JOIN admins a ON l.admin_id = a.id
             {$whereClause}
             ORDER BY l.created_at DESC
             LIMIT {$limit} OFFSET {$offset}",
            $params
        )->fetchAll();
    }

    /**
     * Count total matching log entries (for pagination).
     */
    public static function count(
        string $filterAction = '',
        string $filterModule = '',
        string $search       = ''
    ): int {
        $db     = Database::getInstance();
        $where  = [];
        $params = [];

        if ($filterAction !== '') {
            $where[]  = 'l.action = ?';
            $params[] = $filterAction;
        }
        if ($filterModule !== '') {
            $where[]  = 'l.module = ?';
            $params[] = $filterModule;
        }
        if ($search !== '') {
            $where[]  = '(l.description LIKE ? OR a.full_name LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }

        $whereClause = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

        return (int) $db->query(
            "SELECT COUNT(*) AS total
             FROM   admin_activity_log l
             LEFT JOIN admins a ON l.admin_id = a.id
             {$whereClause}",
            $params
        )->fetch()['total'];
    }

    /**
     * Return all distinct modules that have been logged.
     * Useful for populating the filter dropdown.
     */
    public static function modules(): array {
        $db = Database::getInstance();
        return $db->query(
            "SELECT DISTINCT module FROM admin_activity_log ORDER BY module"
        )->fetchAll(\PDO::FETCH_COLUMN);
    }

    /**
     * Resolve the real client IP, accounting for common proxy headers.
     */
    private static function getIp(): string {
        foreach (['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                // X-Forwarded-For can be a comma-separated chain; take the first
                $ip = trim(explode(',', $_SERVER[$key])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }
}
