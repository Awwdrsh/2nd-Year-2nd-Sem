<?php
/**
 * Seed Candidates Script
 * Re-inserts sample candidates and updates user flags.
 */
// 1. Initialize environment
define('BASE_PATH', __DIR__);
require_once BASE_PATH . '/core/Env.php';

// Check if .env exists and is readable
if (!file_exists(BASE_PATH . '/.env')) {
    die("❌ ERROR: .env file not found at " . BASE_PATH . "/.env\n");
}

if (!is_readable(BASE_PATH . '/.env')) {
    $owner = function_exists('posix_getpwuid') ? posix_getpwuid(fileowner(BASE_PATH . '/.env'))['name'] : fileowner(BASE_PATH . '/.env');
    $perms = substr(sprintf('%o', fileperms(BASE_PATH . '/.env')), -4);
    die("❌ ERROR: .env file is NOT readable by the current user (" . get_current_user() . ").
   File Owner: $owner
   Permissions: $perms
   Fix: Run 'sudo chmod 644 .env' or use 'sudo php seed_candidates.php'.\n");
}

// Load .env
Env::load(BASE_PATH . '/.env');

// 2. Attempt Database Connection
require_once BASE_PATH . '/core/Database.php';

try {
    $db = Database::getInstance();
    echo "✅ Database connection successful.\n\n";
} catch (PDOException $e) {
    die("❌ ERROR: Database Connection Failed: " . $e->getMessage() . "\n");
}

try {
    echo "🌱 Seeding sample candidates...\n";
    
    $candidates = [
        [7,  1, 7,  'both', 1, 'Road infrastructure, clean water supply, and youth employment in Kaski district.',        'approved'],
        [9,  2, 7,  'fptp', 2, 'Education and healthcare are the pillars of development. Three new health posts.',        'approved'],
        [11, 3, 9,  'fptp', 1, 'Chitwan flood control, farmer subsidies, and improving the Bharatpur-Kathmandu highway.', 'approved'],
        [13, 1, 10, 'pr',   1, 'Madhesh proportional representation and equal rights under federalism.',                  'approved'],
        [15, 4, 3,  'fptp', 1, 'Anti-corruption, digital governance, and startup ecosystem for the new generation.',      'approved']
    ];
    
    foreach ($candidates as $c) {
        $db->query(
            "INSERT INTO candidates (user_id, party_id, constituency_id, election_type, ballot_number, manifesto, nomination_status)
             VALUES (?, ?, ?, ?, ?, ?, ?)",
            $c
        );
        
        // Mark the user as a candidate
        $db->query("UPDATE users SET is_candidate = 1 WHERE id = ?", [$c[0]]);
        echo "✅ Candidate for User ID {$c[0]} inserted.\n";
    }
    
    echo "\n🚀 Candidates seeded successfully!\n";

} catch (Exception $e) {
    die("❌ ERROR: " . $e->getMessage() . "\n");
}
